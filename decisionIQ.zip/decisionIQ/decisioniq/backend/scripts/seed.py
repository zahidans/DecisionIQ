"""
Populates a local dev database with a demo account and a couple of
finished-looking decisions, so the UI has something to show without
needing real AI/search API keys or waiting on the live pipeline.

Never seeds real users, real passwords, or API keys — the demo password
below is intentionally plain-text-obvious and documented as such.

Usage:
    cd backend
    python scripts/seed.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.database import Base, engine, SessionLocal  # noqa: E402
from app import models  # noqa: E402
from app.auth import hash_password  # noqa: E402

DEMO_EMAIL = "demo@decisioniq.local"
DEMO_PASSWORD = "demo-password-123"  # local dev only — not a real credential


def run():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        user = db.query(models.User).filter(models.User.email == DEMO_EMAIL).first()
        if not user:
            user = models.User(
                full_name="Demo User",
                email=DEMO_EMAIL,
                hashed_password=hash_password(DEMO_PASSWORD),
            )
            db.add(user)
            db.commit()
            db.refresh(user)
            print(f"Created demo user: {DEMO_EMAIL} / {DEMO_PASSWORD}")
        else:
            print(f"Demo user already exists: {DEMO_EMAIL}")

        existing = db.query(models.Decision).filter(models.Decision.user_id == user.id).count()
        if existing > 0:
            print(f"Demo user already has {existing} decision(s) — skipping seed decisions.")
            return

        decision = models.Decision(
            user_id=user.id,
            title="Which laptop for AI development?",
            category="technology",
            question="Which laptop under 80000 rupees is best for AI development and programming?",
            priorities={"performance": 0.6, "price": 0.4},
            status=models.DecisionStatus.ready,
            result_summary=(
                "Based on the sample evidence below, Option A comes out ahead on raw performance "
                "for AI workloads, while Option B is the better pick if price is the deciding factor. "
                "This is demo data seeded for local development — real decisions run through the "
                "actual research pipeline once AI_API_KEY and SEARCH_API_KEY are configured."
            ),
        )
        db.add(decision)
        db.flush()

        option_a = models.Option(
            decision_id=decision.id,
            name="Laptop A (demo)",
            score="8.2/10",
            score_value=8.2,
            score_breakdown=[
                {"criterion": "performance", "weight": 0.6, "score": 9.0, "note": "Strong GPU for local model work"},
                {"criterion": "price", "weight": 0.4, "score": 7.0, "note": "Above budget but justified by specs"},
            ],
            pros="Excellent GPU for local AI workloads\nGreat build quality",
            cons="Pricier than alternatives\nHeavier to carry around",
        )
        option_b = models.Option(
            decision_id=decision.id,
            name="Laptop B (demo)",
            score="7.1/10",
            score_value=7.1,
            score_breakdown=[
                {"criterion": "performance", "weight": 0.6, "score": 6.5, "note": "Adequate for lighter workloads"},
                {"criterion": "price", "weight": 0.4, "score": 8.5, "note": "Comfortably within budget"},
            ],
            pros="Well within budget\nLightweight and portable",
            cons="Slower for larger model training",
        )
        db.add_all([option_a, option_b])
        db.flush()

        db.add_all(
            [
                models.Evidence(
                    decision_id=decision.id,
                    option_id=option_a.id,
                    source_name="Example Tech Review (demo)",
                    source_url="https://example.com/laptop-a-review",
                    snippet="In our benchmarks, Laptop A handled local model fine-tuning noticeably faster than similarly priced competitors.",
                    stance=models.EvidenceStance.supports,
                ),
                models.Evidence(
                    decision_id=decision.id,
                    option_id=option_b.id,
                    source_name="Example Budget Guide (demo)",
                    source_url="https://example.com/laptop-b-review",
                    snippet="Laptop B remains one of the best value picks under 80,000 rupees, though it will struggle with heavier AI workloads.",
                    stance=models.EvidenceStance.neutral,
                ),
            ]
        )
        db.commit()
        print("Seeded 1 demo decision with 2 options and 2 evidence rows.")

    finally:
        db.close()


if __name__ == "__main__":
    run()
