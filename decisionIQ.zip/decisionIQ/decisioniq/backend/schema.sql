-- DecisionIQ database schema (PostgreSQL)
-- This mirrors the SQLAlchemy models in app/models.py and the Alembic
-- migration in alembic/versions/0001_initial.py. Prefer running
-- `alembic upgrade head` for real deployments; this file is here for
-- anyone who wants to inspect or apply the schema by hand.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TYPE plan_tier AS ENUM ('free', 'plus', 'pro', 'enterprise');
CREATE TYPE decision_status AS ENUM ('created', 'researching', 'comparing', 'ready', 'failed');
CREATE TYPE evidence_stance AS ENUM ('supports', 'against', 'neutral');

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    plan plan_tier NOT NULL DEFAULT 'free',
    created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE decisions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    question TEXT NOT NULL,
    priorities JSONB,
    status decision_status NOT NULL DEFAULT 'created',
    progress_message VARCHAR(300),
    error_message VARCHAR(500),
    result_summary TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    updated_at TIMESTAMP NOT NULL DEFAULT now()
);

-- Options being compared for a decision (e.g. a specific laptop, job offer,
-- or college). Populated by the option-extraction/comparison/scoring
-- agents in the research pipeline.
CREATE TABLE options (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    score VARCHAR(10),                 -- human-readable label, e.g. "8.4/10"
    score_value FLOAT,                 -- numeric, for sorting/comparison
    score_breakdown JSONB,             -- [{criterion, weight, score, note}, ...]
    pros TEXT,
    cons TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT now()
);

-- A single piece of supporting evidence: a real source, a quote/paraphrase,
-- and whether it supports, argues against, or is neutral toward an option
-- or the decision overall (option_id NULL = decision-level evidence).
CREATE TABLE evidence (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
    option_id UUID REFERENCES options(id) ON DELETE CASCADE,
    source_name VARCHAR(200) NOT NULL,
    source_url VARCHAR(500),
    snippet TEXT NOT NULL,
    stance evidence_stance NOT NULL DEFAULT 'neutral',
    created_at TIMESTAMP NOT NULL DEFAULT now()
);

-- A user bookmarking one of their own decisions.
CREATE TABLE saved_decisions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    UNIQUE (user_id, decision_id)
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_decisions_user_id ON decisions(user_id);
CREATE INDEX idx_decisions_category ON decisions(category);
CREATE INDEX idx_decisions_status ON decisions(status);
CREATE INDEX idx_options_decision_id ON options(decision_id);
CREATE INDEX idx_evidence_decision_id ON evidence(decision_id);
CREATE INDEX idx_evidence_option_id ON evidence(option_id);
CREATE INDEX idx_saved_user_id ON saved_decisions(user_id);
CREATE INDEX idx_saved_decision_id ON saved_decisions(decision_id);
