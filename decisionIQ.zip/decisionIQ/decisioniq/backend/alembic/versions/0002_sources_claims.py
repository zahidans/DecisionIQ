"""sources and claims tables

Revision ID: 0002
Revises: 0001
Create Date: 2026-09-10

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "sources",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "decision_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("decisions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("title", sa.String(500), nullable=False),
        sa.Column("url", sa.String(1000), nullable=False),
        sa.Column("publisher", sa.String(200), nullable=True),
        sa.Column("source_type", sa.String(50), server_default="web", nullable=True),
        sa.Column("published_at", sa.DateTime(), nullable=True),
        sa.Column("retrieved_at", sa.DateTime(), nullable=True),
        sa.Column("quality_score", sa.Float(), nullable=True),
        sa.Column("freshness_score", sa.Float(), nullable=True),
        sa.Column("metadata", sa.JSON(), nullable=True),
    )
    op.create_index("idx_sources_decision_id", "sources", ["decision_id"])

    op.create_table(
        "claims",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "source_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("sources.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("claim_text", sa.Text(), nullable=False),
        sa.Column("claim_type", sa.String(50), nullable=True),
        sa.Column(
            "option_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("options.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("idx_claims_source_id", "claims", ["source_id"])
    op.create_index("idx_claims_option_id", "claims", ["option_id"])

    # Evidence now links to sources/claims for traceability.
    op.add_column(
        "evidence",
        sa.Column("source_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("sources.id", ondelete="SET NULL"), nullable=True),
    )
    op.add_column(
        "evidence",
        sa.Column("claim_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("claims.id", ondelete="SET NULL"), nullable=True),
    )
    op.create_index("idx_evidence_source_id", "evidence", ["source_id"])
    op.create_index("idx_evidence_claim_id", "evidence", ["claim_id"])


def downgrade() -> None:
    op.drop_index("idx_evidence_claim_id", table_name="evidence")
    op.drop_index("idx_evidence_source_id", table_name="evidence")
    op.drop_column("evidence", "claim_id")
    op.drop_column("evidence", "source_id")

    op.drop_index("idx_claims_option_id", table_name="claims")
    op.drop_index("idx_claims_source_id", table_name="claims")
    op.drop_table("claims")

    op.drop_index("idx_sources_decision_id", table_name="sources")
    op.drop_table("sources")