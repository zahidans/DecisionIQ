"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-09-08

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    plan_tier = postgresql.ENUM("free", "plus", "pro", "enterprise", name="plan_tier")
    decision_status = postgresql.ENUM(
        "created", "researching", "comparing", "ready", "failed", name="decision_status"
    )
    evidence_stance = postgresql.ENUM("supports", "against", "neutral", name="evidence_stance")


    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("full_name", sa.String(120), nullable=False),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("plan", plan_tier, nullable=False, server_default="free"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("idx_users_email", "users", ["email"])

    op.create_table(
        "decisions",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("category", sa.String(50), nullable=False),
        sa.Column("question", sa.Text(), nullable=False),
        sa.Column("priorities", sa.JSON(), nullable=True),
        sa.Column("status", decision_status, nullable=False, server_default="created"),
        sa.Column("progress_message", sa.String(300), nullable=True),
        sa.Column("error_message", sa.String(500), nullable=True),
        sa.Column("result_summary", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )
    op.create_index("idx_decisions_user_id", "decisions", ["user_id"])
    op.create_index("idx_decisions_category", "decisions", ["category"])
    op.create_index("idx_decisions_status", "decisions", ["status"])

    op.create_table(
        "options",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("decision_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("decisions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("score", sa.String(10), nullable=True),
        sa.Column("score_value", sa.Float(), nullable=True),
        sa.Column("score_breakdown", sa.JSON(), nullable=True),
        sa.Column("pros", sa.Text(), nullable=True),
        sa.Column("cons", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("idx_options_decision_id", "options", ["decision_id"])

    op.create_table(
        "evidence",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("decision_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("decisions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("option_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("options.id", ondelete="CASCADE"), nullable=True),
        sa.Column("source_name", sa.String(200), nullable=False),
        sa.Column("source_url", sa.String(500), nullable=True),
        sa.Column("snippet", sa.Text(), nullable=False),
        sa.Column("stance", evidence_stance, nullable=False, server_default="neutral"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_index("idx_evidence_decision_id", "evidence", ["decision_id"])
    op.create_index("idx_evidence_option_id", "evidence", ["option_id"])

    op.create_table(
        "saved_decisions",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("decision_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("decisions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.UniqueConstraint("user_id", "decision_id", name="uq_saved_user_decision"),
    )
    op.create_index("idx_saved_user_id", "saved_decisions", ["user_id"])
    op.create_index("idx_saved_decision_id", "saved_decisions", ["decision_id"])


def downgrade() -> None:
    op.drop_table("saved_decisions")
    op.drop_table("evidence")
    op.drop_table("options")
    op.drop_table("decisions")
    op.drop_table("users")

    bind = op.get_bind()
    postgresql.ENUM(name="evidence_stance").drop(bind, checkfirst=True)
    postgresql.ENUM(name="decision_status").drop(bind, checkfirst=True)
    postgresql.ENUM(name="plan_tier").drop(bind, checkfirst=True)
