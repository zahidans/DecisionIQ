"""
Fixtures assume DATABASE_URL points at a real, disposable PostgreSQL
database (see .github/workflows/ci.yml, or run one locally via
`docker compose up postgres` and point DATABASE_URL at it). Models use
SQLAlchemy's PostgreSQL-specific UUID type, so SQLite can't stand in here.
"""

import pytest
from fastapi.testclient import TestClient

from app.database import Base, engine, SessionLocal
from app.main import app


@pytest.fixture(scope="session", autouse=True)
def _create_schema():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def db_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def client():
    return TestClient(app)


@pytest.fixture()
def registered_user(client):
    payload = {"full_name": "Test User", "email": "test@example.com", "password": "password123"}
    client.post("/auth/register", json=payload)
    login = client.post("/auth/login", json={"email": payload["email"], "password": payload["password"]})
    token = login.json()["access_token"]
    return {"payload": payload, "token": token, "headers": {"Authorization": f"Bearer {token}"}}
