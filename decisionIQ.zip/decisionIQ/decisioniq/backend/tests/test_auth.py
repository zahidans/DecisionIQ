def test_health(client):
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json() == {"status": "ok"}


def test_register_and_login(client):
    payload = {"full_name": "Alice Example", "email": "alice@example.com", "password": "supersecret1"}
    res = client.post("/auth/register", json=payload)
    assert res.status_code == 201
    body = res.json()
    assert body["email"] == payload["email"]
    assert "hashed_password" not in body  # never leak the hash

    res = client.post("/auth/login", json={"email": payload["email"], "password": payload["password"]})
    assert res.status_code == 200
    assert "access_token" in res.json()


def test_login_wrong_password_rejected(client):
    payload = {"full_name": "Bob Example", "email": "bob@example.com", "password": "correct-password"}
    client.post("/auth/register", json=payload)

    res = client.post("/auth/login", json={"email": payload["email"], "password": "wrong-password"})
    assert res.status_code == 401


def test_duplicate_email_rejected(client):
    payload = {"full_name": "Carol Example", "email": "carol@example.com", "password": "password123"}
    first = client.post("/auth/register", json=payload)
    assert first.status_code == 201

    second = client.post("/auth/register", json=payload)
    assert second.status_code == 400


def test_me_requires_auth(client):
    res = client.get("/auth/me")
    assert res.status_code == 401


def test_me_returns_current_user(client, registered_user):
    res = client.get("/auth/me", headers=registered_user["headers"])
    assert res.status_code == 200
    assert res.json()["email"] == registered_user["payload"]["email"]
