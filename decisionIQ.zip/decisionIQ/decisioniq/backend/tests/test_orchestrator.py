"""
Exercises services/orchestrator.py end to end by faking every agent's
return value (so no real AI_API_KEY/SEARCH_API_KEY is needed), and asserts
the resulting Decision/Option/Evidence rows are what the pipeline should
have produced. This is what actually proves the orchestration logic works,
independent of whether a real provider is configured.
"""

from app import models
from app.database import SessionLocal
from app.services import orchestrator
from app.services.search_service import SearchResult


def test_pipeline_happy_path(client, registered_user, monkeypatch):
    # Create the decision with the real pipeline disabled (see test_decisions.py).
    import app.routers.decisions as decisions_router

    monkeypatch.setattr(decisions_router, "run_decision_pipeline", lambda *a, **k: None)
    created = client.post(
        "/decisions",
        json={
            "title": "Laptop for AI dev",
            "category": "technology",
            "question": "Which laptop under 80000 rupees for AI development?",
            "priorities": {"performance": 0.6, "price": 0.4},
        },
        headers=registered_user["headers"],
    )
    decision_id = created.json()["id"]

    fake_sources = [
        SearchResult(title="Laptop A review", url="https://example.com/a", snippet="Laptop A has a great GPU."),
        SearchResult(title="Laptop B review", url="https://example.com/b", snippet="Laptop B is cheaper but slower."),
    ]

    monkeypatch.setattr(
        orchestrator.question_analyzer,
        "analyze",
        lambda *a, **k: {
            "normalized_query": "best laptop under 80000 for AI dev",
            "constraints": ["budget 80000"],
            "criteria": ["performance", "price"],
            "option_type": "laptop",
        },
    )
    monkeypatch.setattr(orchestrator.research_planner, "plan", lambda *a, **k: ["best laptop for AI under 80000"])
    monkeypatch.setattr(orchestrator.research_agent, "gather", lambda *a, **k: fake_sources)
    monkeypatch.setattr(
        orchestrator.option_extractor,
        "extract",
        lambda *a, **k: [
            {"name": "Laptop A", "source_indices": [0]},
            {"name": "Laptop B", "source_indices": [1]},
        ],
    )
    monkeypatch.setattr(
        orchestrator.evidence_verifier,
        "verify",
        lambda option_name, source_indices, sources: [
            {
                "source_name": sources[i].title,
                "source_url": sources[i].url,
                "snippet": sources[i].snippet,
                "stance": "supports",
            }
            for i in source_indices
        ],
    )
    monkeypatch.setattr(
        orchestrator.comparator,
        "compare",
        lambda name, evidence: {"pros": [f"{name} pro 1"], "cons": [f"{name} con 1"]},
    )
    monkeypatch.setattr(
        orchestrator.scorer,
        "score",
        lambda name, pros, cons, evidence, criteria, priorities: {
            "score_value": 8.0 if "A" in name else 6.5,
            "score_label": "8.0/10" if "A" in name else "6.5/10",
            "breakdown": [{"criterion": "performance", "weight": 0.6, "score": 8.0, "note": "fast"}],
        },
    )
    monkeypatch.setattr(orchestrator.recommender, "recommend", lambda question, options: "Laptop A is the better pick.")

    orchestrator.run_decision_pipeline(decision_id, SessionLocal)

    res = client.get(f"/decisions/{decision_id}", headers=registered_user["headers"])
    body = res.json()

    assert body["status"] == "ready"
    assert body["result_summary"] == "Laptop A is the better pick."
    assert len(body["options"]) == 2
    # Options come back sorted by score_value descending.
    assert body["options"][0]["name"] == "Laptop A"
    assert body["options"][0]["score_value"] == 8.0
    assert body["options"][0]["pros"] == "Laptop A pro 1"
    assert len(body["options"][0]["evidence"]) == 1
    assert body["options"][0]["evidence"][0]["source_url"] == "https://example.com/a"
    assert body["options"][0]["evidence"][0]["stance"] == "supports"


def test_pipeline_fails_cleanly_without_search_provider(client, registered_user, monkeypatch):
    """With no SEARCH_API_KEY configured (the default in tests), the real
    (unpatched) pipeline must mark the decision failed with a specific
    message — never fabricate options or evidence."""
    import app.routers.decisions as decisions_router

    monkeypatch.setattr(decisions_router, "run_decision_pipeline", lambda *a, **k: None)
    created = client.post(
        "/decisions",
        json={"title": "Unconfigured pipeline test", "category": "finance", "question": "Where to invest?"},
        headers=registered_user["headers"],
    )
    decision_id = created.json()["id"]

    orchestrator.run_decision_pipeline(decision_id, SessionLocal)

    res = client.get(f"/decisions/{decision_id}", headers=registered_user["headers"])
    body = res.json()
    assert body["status"] == "failed"
    assert body["options"] == []
    assert body["evidence"] == []
    assert "AI_API_KEY" in body["error_message"] or "SEARCH_API_KEY" in body["error_message"]
