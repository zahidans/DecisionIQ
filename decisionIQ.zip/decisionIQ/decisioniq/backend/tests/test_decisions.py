"""
These tests monkeypatch the background pipeline to a deterministic no-op so
decision-status assertions don't depend on whether AI_API_KEY/SEARCH_API_KEY
happen to be configured in the environment running the tests. The pipeline
itself (agents, orchestrator) is exercised separately in
test_orchestrator.py against fakes.
"""

import app.routers.decisions as decisions_router


def _register_and_login(client, email):
    payload = {"full_name": "User " + email, "email": email, "password": "password123"}
    client.post("/auth/register", json=payload)
    login = client.post("/auth/login", json={"email": email, "password": payload["password"]})
    token = login.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def _noop_pipeline(decision_id, session_factory):
    """Replaces run_decision_pipeline for tests that only care about the
    HTTP/ownership/status-transition contract, not real research."""
    pass


def test_create_decision_requires_auth(client):
    res = client.post(
        "/decisions",
        json={"title": "Laptop", "category": "technology", "question": "Which laptop?"},
    )
    assert res.status_code == 401


def test_create_decision_starts_in_created_status(client, registered_user, monkeypatch):
    monkeypatch.setattr(decisions_router, "run_decision_pipeline", _noop_pipeline)

    res = client.post(
        "/decisions",
        json={"title": "Laptop choice", "category": "technology", "question": "Which laptop under 80000?"},
        headers=registered_user["headers"],
    )
    assert res.status_code == 201
    body = res.json()
    assert body["status"] == "created"
    assert body["is_saved"] is False
    assert body["options"] == []
    assert body["evidence"] == []


def test_user_cannot_access_another_users_decision(client, monkeypatch):
    monkeypatch.setattr(decisions_router, "run_decision_pipeline", _noop_pipeline)

    headers_a = _register_and_login(client, "owner@example.com")
    headers_b = _register_and_login(client, "intruder@example.com")

    created = client.post(
        "/decisions",
        json={"title": "Private decision", "category": "career", "question": "Which offer?"},
        headers=headers_a,
    )
    decision_id = created.json()["id"]

    own = client.get(f"/decisions/{decision_id}", headers=headers_a)
    assert own.status_code == 200

    # A different authenticated user gets a 404, not a 403 — existence isn't leaked.
    other = client.get(f"/decisions/{decision_id}", headers=headers_b)
    assert other.status_code == 404

    listing = client.get("/decisions", headers=headers_b)
    assert all(d["id"] != decision_id for d in listing.json())


def test_retry_rejected_unless_failed(client, registered_user, monkeypatch):
    monkeypatch.setattr(decisions_router, "run_decision_pipeline", _noop_pipeline)

    created = client.post(
        "/decisions",
        json={"title": "Retry test", "category": "finance", "question": "Where to invest?"},
        headers=registered_user["headers"],
    )
    decision_id = created.json()["id"]
    assert created.json()["status"] == "created"

    # Not failed yet (the no-op pipeline never touched it) — retry must be rejected.
    retry = client.post(f"/decisions/{decision_id}/retry", headers=registered_user["headers"])
    assert retry.status_code == 400


def test_retry_succeeds_once_failed(client, registered_user, db_session, monkeypatch):
    monkeypatch.setattr(decisions_router, "run_decision_pipeline", _noop_pipeline)

    from app import models

    created = client.post(
        "/decisions",
        json={"title": "Retry test 2", "category": "finance", "question": "Where to invest?"},
        headers=registered_user["headers"],
    )
    decision_id = created.json()["id"]

    # Simulate the pipeline having failed, directly at the DB layer.
    decision = db_session.query(models.Decision).filter(models.Decision.id == decision_id).first()
    decision.status = models.DecisionStatus.failed
    decision.error_message = "Simulated failure for testing"
    db_session.commit()

    retry = client.post(f"/decisions/{decision_id}/retry", headers=registered_user["headers"])
    assert retry.status_code == 200
    assert retry.json()["status"] == "created"
    assert retry.json()["error_message"] is None


def test_save_and_unsave_decision(client, registered_user, monkeypatch):
    monkeypatch.setattr(decisions_router, "run_decision_pipeline", _noop_pipeline)

    created = client.post(
        "/decisions",
        json={"title": "Save test", "category": "travel", "question": "Where to go?"},
        headers=registered_user["headers"],
    )
    decision_id = created.json()["id"]

    saved = client.post(f"/saved/{decision_id}", headers=registered_user["headers"])
    assert saved.status_code == 201
    assert saved.json()["is_saved"] is True

    listing = client.get("/saved", headers=registered_user["headers"])
    assert any(d["id"] == decision_id for d in listing.json())

    unsaved = client.delete(f"/saved/{decision_id}", headers=registered_user["headers"])
    assert unsaved.status_code == 204

    listing_after = client.get("/saved", headers=registered_user["headers"])
    assert all(d["id"] != decision_id for d in listing_after.json())


def test_insights_reflect_real_data_only(client, monkeypatch):
    monkeypatch.setattr(decisions_router, "run_decision_pipeline", _noop_pipeline)
    headers = _register_and_login(client, "insights-user@example.com")

    empty = client.get("/insights", headers=headers)
    assert empty.status_code == 200
    assert empty.json()["total_decisions"] == 0
    assert empty.json()["average_top_score"] is None

    client.post(
        "/decisions",
        json={"title": "Insight decision", "category": "education", "question": "Which college?"},
        headers=headers,
    )

    after = client.get("/insights", headers=headers)
    assert after.json()["total_decisions"] == 1
    assert after.json()["decisions_by_category"].get("education") == 1
