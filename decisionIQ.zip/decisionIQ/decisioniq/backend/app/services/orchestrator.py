"""
Coordinates the full decision pipeline end to end:

  question analysis -> research planning -> web search -> option extraction
  -> evidence verification -> comparison -> scoring -> recommendation
  -> persistence -> status = ready

Runs as a FastAPI BackgroundTask (see routers/decisions.py), with its own
DB session since the request's session is closed by the time this executes.
For a real production deployment, swap the BackgroundTasks call in the
router for a proper worker/queue (Celery, RQ, arq, etc) — nothing else in
this file needs to change, since it's already a plain function that takes a
decision_id and a session factory.

On any failure at any stage, the decision is marked `failed` with a safe,
user-facing error_message. Nothing here fabricates options or evidence: if
research/AI genuinely can't be done (e.g. no SEARCH_API_KEY configured),
the pipeline stops and says so instead of inventing a result.

First-class evidence model: every source gathered becomes a Source row, and
any AI-extracted claims from those sources become Claim rows. Evidence
thereafter links back to Source and/or Claim for full traceability.
"""

import logging

from sqlalchemy.orm import Session, sessionmaker

from .. import models
from ..agents import (
    question_analyzer,
    research_planner,
    research_agent,
    option_extractor,
    evidence_verifier,
    verification_agent,
    comparator,
    scorer,
    recommender,
    quality_checker,
    citation_manager,
)
from .ai_service import AIServiceError, AIServiceNotConfigured
from .search_service import SearchServiceError, SearchUnavailableError

logger = logging.getLogger("decisioniq.orchestrator")


def _set_progress(db: Session, decision: models.Decision, status: models.DecisionStatus, message: str):
    decision.status = status
    decision.progress_message = message
    db.commit()


def _fail(db: Session, decision: models.Decision, message: str, exc: Exception | None = None):
    if exc:
        logger.error("Decision %s failed: %s", decision.id, exc, exc_info=True)
    decision.status = models.DecisionStatus.failed
    decision.progress_message = None
    decision.error_message = message
    db.commit()


def run_decision_pipeline(decision_id: str, session_factory: sessionmaker):
    db = session_factory()
    try:
        decision = db.query(models.Decision).filter(models.Decision.id == decision_id).first()
        if decision is None:
            logger.error("Decision %s not found when starting pipeline", decision_id)
            return

        try:
            _set_progress(db, decision, models.DecisionStatus.researching, "Understanding your question...")
            analysis = question_analyzer.analyze(decision.question, decision.category, decision.priorities)

            _set_progress(db, decision, models.DecisionStatus.researching, "Planning research...")
            queries = research_planner.plan(
                analysis["normalized_query"], analysis["criteria"], analysis["constraints"], analysis["option_type"]
            )

            _set_progress(db, decision, models.DecisionStatus.researching, "Finding relevant sources...")
            sources = research_agent.gather(queries)

            # Create Source records for each gathered source, linking to the decision.
            db_source_ids: dict[str, models.Source] = {}
            for s in sources:
                src = models.Source(
                    decision_id=decision.id,
                    title=s.title,
                    url=s.url,
                    publisher=s.metadata.get("publisher") if isinstance(s.metadata, dict) else None,
                    source_type=s.metadata.get("source_type") if isinstance(s.metadata, dict) else "web",
                    quality_score=s.metadata.get("quality_score") if isinstance(s.metadata, dict) else None,
                    freshness_score=s.metadata.get("freshness_score") if isinstance(s.metadata, dict) else None,
                    source_metadata=s.metadata if isinstance(s.metadata, dict) else None,
                )
                db.add(src)
                db.flush()
                db_source_ids[s.url] = src

            _set_progress(db, decision, models.DecisionStatus.comparing, "Identifying options...")
            raw_options = option_extractor.extract(analysis["normalized_query"], analysis["option_type"], sources)

            # Extract claims from sources and create Claim records.
            db_claim_ids: dict[str, models.Claim] = {}
            for s in sources:
                # Use the AI service to extract claims from each source's snippet
                try:
                    claims_result = ai_service.complete_json(
                        """You are extracting verifiable claims from a research source.
Given the source title and snippet, return a JSON array of claims, each being a distinct factual or
specification statement that could be used in a decision comparison. Return ONLY the JSON array —
no prose, no explanation, no markdown fences. If there are no distinct claims, return an empty array [].""",
                        f"Source: {s.title}\nSnippet: {s.snippet[:800]}",
                        max_tokens=400,
                    )
                    for claim_text in (claims_result if isinstance(claims_result, list) else []):
                        claim = models.Claim(
                            source_id=src.id,
                            claim_text=str(claim_text).strip(),
                            claim_type=None,
                        )
                        db.add(claim)
                        db.flush()
                        db_claim_ids[str(claim_text).strip()[:200]] = claim
                except Exception:
                    # If claim extraction fails for a source, skip it — no fabricated claims.
                    pass

            _set_progress(db, decision, models.DecisionStatus.comparing, "Verifying evidence...")
            option_records = []
            for raw in raw_options:
                option = models.Option(decision_id=decision.id, name=raw["name"])
                db.add(option)
                db.flush()  # get option.id without committing yet

                evidence_rows = evidence_verifier.verify(raw["name"], raw["source_indices"], sources)
                for e in evidence_rows:
                    # Find the source record(s) corresponding to this evidence for linking
                    source_obj = db_source_ids.get(e["source_url"])
                    claim_obj = None
                    # Try to find a claim that matches the source (approximate matching by checking claims of this source)
                    if source_obj:
                        for claim_key, claim_obj_candidate in db_claim_ids.items():
                            if claim_obj_candidate.source_id == source_obj.id:
                                claim_obj = claim_obj_candidate
                                break  # Take the first claim for this source - in reality we might want better matching
                    evidence_record = models.Evidence(
                        decision_id=decision.id,
                        option_id=option.id,
                        source_id=source_obj.id if source_obj else None,
                        claim_id=claim_obj.id if claim_obj else None,
                        source_name=e["source_name"],
                        source_url=e["source_url"],
                        snippet=e["snippet"],
                        stance=models.EvidenceStance(e["stance"]),
                    )
                    db.add(evidence_record)
                option_records.append({"option": option, "evidence": evidence_rows})
            db.commit()

            _set_progress(db, decision, models.DecisionStatus.comparing, "Comparing options...")
            for rec in option_records:
                result = comparator.compare(rec["option"].name, rec["evidence"])
                rec["option"].pros = "\n".join(result["pros"])
                rec["option"].cons = "\n".join(result["cons"])
                rec["pros"] = result["pros"]
                rec["cons"] = result["cons"]
            db.commit()

            _set_progress(db, decision, models.DecisionStatus.comparing, "Scoring options...")
            for rec in option_records:
                s = scorer.score(
                    rec["option"].name,
                    rec["pros"],
                    rec["cons"],
                    rec["evidence"],
                    analysis["criteria"],
                    decision.priorities,
                )
                rec["option"].score = s["score_label"]
                rec["option"].score_value = s["score_value"]
                rec["option"].score_breakdown = s["breakdown"]
                rec["score_label"] = s["score_label"]
            db.commit()

            _set_progress(db, decision, models.DecisionStatus.comparing, "Generating recommendation...")
            summary_input = [
                {
                    "name": rec["option"].name,
                    "score_label": rec.get("score_label"),
                    "pros": rec.get("pros", []),
                    "cons": rec.get("cons", []),
                }
                for rec in option_records
            ]
            decision.result_summary = recommender.recommend(decision.question, summary_input)

            decision.status = models.DecisionStatus.ready
            decision.progress_message = None
            db.commit()

        except AIServiceNotConfigured as exc:
            _fail(db, decision, "The AI provider isn't configured yet — add AI_API_KEY in backend/.env.", exc)
        except SearchUnavailableError as exc:
            _fail(db, decision, "Web research isn't configured yet — add SEARCH_API_KEY in backend/.env.", exc)
        except (AIServiceError, SearchServiceError) as exc:
            _fail(db, decision, "Research failed due to a provider error. You can retry.", exc)
        except ValueError as exc:
            _fail(db, decision, f"Research didn't produce a usable result: {exc}", exc)
        except Exception as exc:  # noqa: BLE001 — last-resort guard, never leak internals
            _fail(db, decision, "Something went wrong while researching this decision. You can retry.", exc)

    finally:
        db.close()
