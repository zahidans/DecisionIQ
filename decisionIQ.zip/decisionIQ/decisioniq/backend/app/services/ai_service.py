"""
The only place in the backend allowed to call the AI provider directly.
Every agent goes through this service instead of making its own HTTP calls,
so authentication, retries, timeouts, and error handling live in one place
and the API key never has to be threaded through route handlers.

Nothing here is sent to, or reachable from, the frontend — AI_API_KEY is
read from the server's environment only (see app/config.py).
"""

import json
import logging
import re

import httpx

from ..config import settings

logger = logging.getLogger("decisioniq.ai_service")


class AIServiceError(Exception):
    """Raised when the AI provider can't be reached or returns something
    the pipeline can't use. The orchestrator catches this and fails the
    decision with a safe message — it never falls back to fabricated data."""


class AIServiceNotConfigured(AIServiceError):
    """Raised when AI_API_KEY is empty. Distinct from AIServiceError so
    callers can show a specific "set up your API key" message."""


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


class AIService:
    def __init__(self):
        self.api_key = settings.ai_api_key
        self.base_url = settings.ai_api_base_url.rstrip("/")
        self.model = settings.ai_model
        self.timeout = settings.ai_timeout_seconds
        self.max_retries = max(0, settings.ai_max_retries)

    def _require_configured(self):
        if not self.api_key:
            raise AIServiceNotConfigured(
                "AI_API_KEY is not set on the backend. Add it to backend/.env to enable "
                "the research pipeline."
            )

    def complete(self, system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> str:
        """Send one request to the AI provider and return the raw text of
        its reply. Retries on transient network/5xx errors; raises
        AIServiceError otherwise. Uses the Anthropic Messages API shape by
        default — adjust the payload/headers here if AI_API_BASE_URL points
        at a different provider."""
        self._require_configured()

        url = f"{self.base_url}/v1/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        }

        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=self.timeout) as client:
                    response = client.post(url, headers=headers, json=payload)

                if response.status_code >= 500 and attempt < self.max_retries:
                    last_error = AIServiceError(f"AI provider returned {response.status_code}")
                    continue

                if response.status_code == 401:
                    raise AIServiceError("AI provider rejected the API key (401). Check AI_API_KEY.")

                if response.status_code >= 400:
                    # Log the body server-side for debugging; never surface it to the user.
                    logger.error("AI provider error %s: %s", response.status_code, response.text[:500])
                    raise AIServiceError(f"AI provider returned an error ({response.status_code}).")

                data = response.json()
                blocks = data.get("content", [])
                text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
                if not text:
                    raise AIServiceError("AI provider returned an empty response.")
                return text

            except httpx.TimeoutException as exc:
                last_error = AIServiceError("AI provider request timed out.")
                if attempt >= self.max_retries:
                    raise last_error from exc
            except httpx.HTTPError as exc:
                last_error = AIServiceError(f"Could not reach AI provider: {exc}")
                if attempt >= self.max_retries:
                    raise last_error from exc

        raise last_error or AIServiceError("AI provider call failed for an unknown reason.")

    def complete_json(self, system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> dict | list:
        """Same as complete(), but instructs the model to return ONLY JSON
        and parses it. Raises AIServiceError if the reply isn't valid JSON —
        callers should not attempt to salvage a malformed response, since
        that's how fabricated/garbled data sneaks into the pipeline."""
        strict_system = (
            f"{system_prompt}\n\n"
            "Respond with ONLY valid JSON. No prose, no explanation, no markdown code fences — "
            "just the JSON value itself."
        )
        raw = self.complete(strict_system, user_prompt, max_tokens=max_tokens)
        cleaned = _strip_code_fences(raw)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as exc:
            logger.error("AI response was not valid JSON: %s", cleaned[:500])
            raise AIServiceError("AI provider returned a response the pipeline couldn't parse.") from exc


ai_service = AIService()
