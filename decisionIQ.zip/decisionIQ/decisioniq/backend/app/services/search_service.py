"""
The only place in the backend allowed to call an external search provider.
Returns real {title, url, snippet} results, or raises SearchUnavailableError
if no provider is configured — the research agent must never fall back to
inventing sources when this fails.

Default implementation targets a Tavily-compatible API (POST /search with
{api_key, query} -> {results: [{title, url, content}]}), since that's a
common, cheap option for this kind of grounded research. If you use a
different provider (Serper, Bing Search, Exa, etc.), adjust `search()`
below to match its request/response shape — everything else in the
pipeline only depends on the SearchResult objects this returns.
"""

import logging
from dataclasses import dataclass

import httpx

from ..config import settings

logger = logging.getLogger("decisioniq.search_service")


class SearchServiceError(Exception):
    """Raised when a configured search provider fails (network error, bad
    response, etc)."""


class SearchUnavailableError(SearchServiceError):
    """Raised when no search provider is configured at all. The orchestrator
    treats this as a hard stop for the decision — it will NOT proceed to
    fabricate options or evidence without real sources."""


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str


class SearchService:
    def __init__(self):
        self.api_key = settings.search_api_key
        self.base_url = settings.search_api_base_url.rstrip("/") if settings.search_api_base_url else ""
        self.timeout = settings.search_timeout_seconds

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key and self.base_url)

    def search(self, query: str, max_results: int = 5) -> list[SearchResult]:
        if not self.is_configured:
            raise SearchUnavailableError(
                "No web research provider is configured. Set SEARCH_API_KEY and "
                "SEARCH_API_BASE_URL in backend/.env to enable real evidence gathering."
            )

        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(
                    f"{self.base_url}/search",
                    json={"api_key": self.api_key, "query": query, "max_results": max_results},
                )
            if response.status_code >= 400:
                logger.error("Search provider error %s: %s", response.status_code, response.text[:500])
                raise SearchServiceError(f"Search provider returned an error ({response.status_code}).")

            data = response.json()
            raw_results = data.get("results", [])
            results = [
                SearchResult(
                    title=r.get("title", "Untitled source"),
                    url=r.get("url", ""),
                    snippet=(r.get("content") or r.get("snippet") or "").strip(),
                )
                for r in raw_results
                if r.get("url")
            ]
            return [r for r in results if r.snippet]

        except httpx.HTTPError as exc:
            raise SearchServiceError(f"Could not reach search provider: {exc}") from exc


search_service = SearchService()
