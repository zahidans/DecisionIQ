import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import Base, engine
from .routers import auth, decisions, categories, evidence, saved, insights, research, sources, claims, comparison, result, feedback

logging.basicConfig(level=logging.INFO)

# Base.metadata.create_all() is kept ONLY as a convenience for local/dev
# setups with an empty database. It is not idempotent against schema
# CHANGES (renamed/dropped columns, new constraints) — real schema changes
# must go through Alembic migrations (see backend/alembic/). Run
# `alembic upgrade head` for any real deployment; this call becomes a no-op
# once the tables already exist with the right shape.
if not settings.is_production:
    Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="DecisionIQ API",
    description="Backend for DecisionIQ — Research less. Decide better.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(decisions.router)
app.include_router(categories.router)
app.include_router(evidence.router)
app.include_router(saved.router)
app.include_router(insights.router)
app.include_router(research.router)
app.include_router(sources.router)
app.include_router(claims.router)
app.include_router(comparison.router)
app.include_router(result.router)
app.include_router(feedback.router)


@app.get("/health")
def health():
    return {"status": "ok"}
