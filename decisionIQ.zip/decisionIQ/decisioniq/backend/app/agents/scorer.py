"""Stage 7: score each option against the decision's criteria, weighted by
the user's stated priorities (or equal weights if they didn't specify any).
The point of storing a breakdown per criterion — not just a single number —
is so the UI can show *why* an option scored the way it did instead of
presenting a magic number."""

from ..services.ai_service import ai_service

DEFAULT_WEIGHT = 1.0


def _normalize_weights(criteria: list[str], priorities: dict | None) -> dict[str, float]:
    if not criteria:
        criteria = ["overall fit"]
    weights = {c: float(priorities.get(c, DEFAULT_WEIGHT)) if priorities else DEFAULT_WEIGHT for c in criteria}
    total = sum(weights.values()) or 1.0
    return {c: w / total for c, w in weights.items()}


SYSTEM_PROMPT = """You are the scoring stage of a decision-support pipeline.
You'll be given an option, its pros/cons, its evidence, and a list of
criteria to rate it on. Rate the option from 0 to 10 on EACH criterion,
based only on the evidence and pros/cons given. Briefly justify each score
in one short phrase.

Return a JSON array, one entry per criterion, in the same order given:
[{"criterion": "price", "score": 7.5, "note": "mid-range for the category"}, ...]"""


def score(option_name: str, pros: list[str], cons: list[str], evidence: list[dict], criteria: list[str], priorities: dict | None) -> dict:
    weights = _normalize_weights(criteria, priorities)
    evidence_text = "\n".join(f"- ({e['stance']}) {e['snippet'][:200]}" for e in evidence)

    user_prompt = (
        f"Option: {option_name}\n"
        f"Pros: {pros}\n"
        f"Cons: {cons}\n"
        f"Evidence:\n{evidence_text}\n"
        f"Criteria to rate (in order): {list(weights.keys())}\n\n"
        "Rate this option on each criterion."
    )
    result = ai_service.complete_json(SYSTEM_PROMPT, user_prompt, max_tokens=500)
    if not isinstance(result, list) or not result:
        raise ValueError("Scorer expected a non-empty JSON array")

    breakdown = []
    weighted_total = 0.0
    for item in result:
        criterion = str(item.get("criterion", "")).strip()
        if criterion not in weights:
            continue
        raw_score = float(item.get("score", 0))
        raw_score = max(0.0, min(10.0, raw_score))
        weight = weights[criterion]
        weighted_total += raw_score * weight
        breakdown.append(
            {"criterion": criterion, "weight": round(weight, 3), "score": raw_score, "note": str(item.get("note", ""))}
        )

    if not breakdown:
        raise ValueError("Scorer produced no valid criterion scores.")

    score_value = round(weighted_total, 2)
    return {"score_value": score_value, "score_label": f"{score_value}/10", "breakdown": breakdown}
