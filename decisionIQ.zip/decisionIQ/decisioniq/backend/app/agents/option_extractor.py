"""Stage 4: from the real sources gathered, identify the concrete,
named options actually being compared (e.g. specific laptop models, not
"a laptop"). Each option is grounded in which sources mentioned it — later
stages only attach evidence from sources an option was actually linked to
here, so nothing gets invented."""

from ..services.ai_service import ai_service
from ..services.search_service import SearchResult

SYSTEM_PROMPT = """You are the option-extraction stage of a decision-support
pipeline. You'll be given a decision question and a numbered list of real
web sources (title, url, snippet). Identify 2 to 5 concrete, specific,
named options that are actually discussed in these sources as candidates
for this decision. Do NOT invent an option that isn't grounded in at least
one of the sources. Normalize near-duplicate names (e.g. "MacBook Air M2"
and "Apple MacBook Air (M2, 2022)") into a single option.

Return a JSON array like:
[{"name": "Exact Option Name", "source_indices": [0, 2, 5]}, ...]
where source_indices refers to the numbered sources that mention this option."""


def extract(normalized_query: str, option_type: str, sources: list[SearchResult]) -> list[dict]:
    numbered = "\n".join(f"[{i}] {s.title} — {s.url}\n    {s.snippet[:300]}" for i, s in enumerate(sources))
    user_prompt = (
        f"Decision: {normalized_query}\n"
        f"What's being compared: {option_type}\n\n"
        f"Sources:\n{numbered}\n\n"
        "Extract the concrete options."
    )
    result = ai_service.complete_json(SYSTEM_PROMPT, user_prompt, max_tokens=800)
    if not isinstance(result, list) or not result:
        raise ValueError("Option extractor expected a non-empty JSON array")

    cleaned = []
    for item in result:
        name = str(item.get("name", "")).strip()
        indices = [i for i in item.get("source_indices", []) if isinstance(i, int) and 0 <= i < len(sources)]
        if name and indices:
            cleaned.append({"name": name, "source_indices": indices})

    if not cleaned:
        raise ValueError("Option extractor found no options grounded in the retrieved sources.")

    return cleaned[:5]
