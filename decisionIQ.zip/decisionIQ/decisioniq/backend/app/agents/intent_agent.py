"""IntentAgent — determines the user's true decision intent and derives
a structured question, appropriate category, and priority weights.

This agent wraps the question_analyzer and adds intent-specific logic:
resolving ambiguities, surfacing hidden tradeoffs, and proposing
priority weights when the user hasn't supplied any.
"""

from __future__ import annotations

from typing import Optional

from .. import models
from ..agents import question_analyzer
from ..schemas import DecisionCreate


def determine_intent(
    question: str,
    category: Optional[str] = None,
    priorities: Optional[dict[str, float]] = None,
) -> dict:
    """Analyze the user's question and return a structured intent record.

    Returns a dict with keys:
    - normalized_query: clean one-line restatement
    - constraints: list of explicit constraints
    - criteria: list of criteria that matter
    - option_type: noun phrase for what's being compared
    - suggested_priorities: normalized weight dict (sums to ~1.0)
    - confidence: how confident we are in this interpretation
    """
    base = question_analyzer.analyze(question, category or "general", priorities)

    # If no priorities supplied, propose reasonable defaults based on
    # the option type and detected constraints
    suggested_priorities: dict[str, float] = {}
    if not priorities and base.get("criteria"):
        # Simple default: distribute weight evenly across criteria
        n = len(base["criteria"])
        suggested_priorities = {c: 1.0 / n for c in base["criteria"]}

    confidence = 0.9 if base.get("normalized_query") else 0.5

    return {
        "normalized_query": base.get("normalized_query", question),
        "constraints": base.get("constraints", []),
        "criteria": base.get("criteria", []),
        "option_type": base.get("option_type", "option"),
        "suggested_priorities": suggested_priorities,
        "confidence": confidence,
    }


def create_decision_payload(
    question: str,
    category: Optional[str] = None,
    priorities: Optional[dict[str, float]] = None,
) -> DecisionCreate:
    """Build a DecisionCreate payload from raw user input, using intent
    analysis to fill in missing category or normalize priorities."""
    intent = determine_intent(question, category, priorities)

    # If no category was given but we have a strong signal, suggest one
    final_category = category or intent["option_type"].replace(" ", "").title()[:50] or "general"

    return DecisionCreate(
        title=intent["normalized_query"][:200],
        category=final_category,
        question=question,
        priorities=intent["suggested_priorities"] if intent["suggested_priorities"] else priorities,
    )