"""Stage 2: turn the structured analysis into a short list of concrete web
search queries. Kept as its own stage (rather than folded into research_agent)
so the query strategy can be inspected/tuned independently of how search
results get fetched."""

from ..services.ai_service import ai_service

SYSTEM_PROMPT = """You are the research-planning stage of a decision-support
pipeline. Given a structured analysis of a user's decision question, produce
3 to 5 concrete, specific web search queries that would surface real,
current information to help answer it. Favor queries that would return
comparison articles, reviews, or authoritative pricing/spec pages over vague
queries.

Return a JSON array of strings, e.g.:
["best laptops for programming under 80000 rupees 2026", "..."]"""


def plan(normalized_query: str, criteria: list[str], constraints: list[str], option_type: str) -> list[str]:
    user_prompt = (
        f"Decision: {normalized_query}\n"
        f"What's being compared: {option_type}\n"
        f"Criteria that matter: {criteria}\n"
        f"Constraints: {constraints}\n\n"
        "Produce the search queries."
    )
    result = ai_service.complete_json(SYSTEM_PROMPT, user_prompt, max_tokens=300)
    if not isinstance(result, list) or not result:
        raise ValueError("Research planner expected a non-empty JSON array")
    return [str(q) for q in result[:5]]
