"""Stage 3: run each planned query through the real search provider and
collect deduplicated sources. This is the ONLY stage that talks to
SearchService — every later stage works from the SearchResult list this
returns, so there's exactly one place fabricated sources could sneak in,
and it's the one place that only ever returns what the provider actually
sent back."""

from ..services.search_service import search_service, SearchResult


def gather(queries: list[str], max_results_per_query: int = 5) -> list[SearchResult]:
    seen_urls: set[str] = set()
    all_results: list[SearchResult] = []

    for query in queries:
        results = search_service.search(query, max_results=max_results_per_query)
        for r in results:
            if r.url in seen_urls:
                continue
            seen_urls.add(r.url)
            all_results.append(r)

    if not all_results:
        raise ValueError("Web research returned no usable sources for this question.")

    return all_results
