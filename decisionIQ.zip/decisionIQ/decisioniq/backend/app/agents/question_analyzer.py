"""Stage 1: understand what's actually being asked before researching
anything. Turns the free-text question (+ category + optional priorities)
into a structured brief the rest of the pipeline can work from."""

from ..services.ai_service import ai_service


SYSTEM_PROMPT = """You are the question-analysis stage of a decision-support
pipeline called DecisionIQ. Given a user's decision question, extract a
structured understanding of it. Be concrete and specific to what the user
actually wrote — do not invent constraints they didn't mention.

Return a JSON object with exactly these keys:
{
  "normalized_query": "a clean one-line restatement of what they're deciding",
  "constraints": ["budget, deadline, or other hard limits explicitly mentioned"],
  "criteria": ["the things that matter for comparing options, e.g. price, performance, location"],
  "option_type": "a short noun phrase for what kind of thing is being compared, e.g. 'laptop', 'job offer', 'university'"
}"""


def analyze(question: str, category: str, priorities: dict | None = None) -> dict:
    user_prompt = (
        f"Category: {category}\n"
        f"Question: {question}\n"
        f"User-supplied priority weights (may be empty): {priorities or {}}\n\n"
        "Analyze this decision question."
    )
    result = ai_service.complete_json(SYSTEM_PROMPT, user_prompt, max_tokens=500)
    if not isinstance(result, dict):
        raise ValueError("Question analyzer expected a JSON object")
    result.setdefault("constraints", [])
    result.setdefault("criteria", [])
    result.setdefault("normalized_query", question)
    result.setdefault("option_type", "option")
    return result
