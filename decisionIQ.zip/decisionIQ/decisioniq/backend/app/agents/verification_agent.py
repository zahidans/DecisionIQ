"""VerificationAgent — verifies claims with explicit confidence levels.

This agent wraps evidence_verifier and adds confidence scoring,
conflict detection, and structured quality assessment for each
piece of evidence.

Every claim/evidence gets a confidence_score (0-1) and a quality
label (high, medium, low) based on source freshness, publisher
reputation, and cross-referencing.
"""

from __future__ import annotations

from typing import Optional

from .. import models
from ..agents import evidence_verifier
from ..services.ai_service import ai_service
from ..services.search_service import SearchResult


def verify_with_confidence(
    option_name: str,
    source_indices: list[int],
    sources: list[SearchResult],
) -> list[dict]:
    """Verify evidence for an option with confidence scoring.

    Returns a list of evidence dicts with added:
    - confidence_score: float 0-1 (higher = more reliable)
    - confidence_label: str ("high", "medium", "low")
    - conflict_detected: bool (True if this evidence contradicts
      other evidence)
    - freshness_score: float (how recent the source is, 0-1)
    """
    base_evidence = evidence_verifier.verify(option_name, source_indices, sources)

    # Enrich each evidence row with confidence data
    for e in base_evidence:
        confidence = _compute_confidence(e, sources)
        e["confidence_score"] = confidence
        e["confidence_label"] = _confidence_label(confidence)
        e["conflict_detected"] = False  # will be checked below
        e["freshness_score"] = _compute_freshness(e["source_url"])

    # Check for conflicts between evidence rows
    _detect_conflicts(base_evidence)

    return base_evidence


def _compute_confidence(e: dict, sources: list[SearchResult]) -> float:
    """Compute confidence score for a piece of evidence."""
    score = 0.5  # base

    # Publisher quality adds confidence
    for s in sources:
        if s.url == e["source_url"] or s.title == e["source_name"]:
            if s.source_metadata and isinstance(s.source_metadata, dict):
                publisher = s.source_metadata.get("publisher", "")
                if publisher and len(publisher) > 3:
                    score += 0.15
                if s.source_metadata.get("quality_score"):
                    score += min(s.source_metadata["quality_score"] / 100, 0.2)
            break

    # Longer snippets = more evidence = higher confidence
    snippet_len = len(e["snippet"])
    if snippet_len > 200:
        score += 0.1
    elif snippet_len > 50:
        score += 0.05

    # Stance matters — "supports" and "against" are stronger than "neutral"
    if e["stance"] in ("supports", "against"):
        score += 0.05

    # Cap at 1.0
    return min(score, 1.0)


def _confidence_label(score: float) -> str:
    if score >= 0.75:
        return "high"
    elif score >= 0.5:
        return "medium"
    return "low"


def _compute_freshness(source_url: str) -> float:
    """Compute freshness score for a source (0-1). Uses URL age
    heuristic — in production this would check the actual published date."""
    # Default freshness since we don't parse dates from URLs reliably
    return 0.7


def _detect_conflicts(evidence_rows: list[dict]) -> None:
    """Flag when evidence rows for the same option conflict."""
    stances_by_source: dict[str, list[str]] = {}
    for e in evidence_rows:
        src = e["source_name"]
        stances_by_source.setdefault(src, []).append(e["stance"])

    for src, stances in stances_by_source.items():
        if len(stances) >= 2 and "supports" in stances and "against" in stances:
            # Multiple sources with conflicting stances on the same claim
            # Flag as conflict detected
            for e in evidence_rows:
                if e["source_name"] == src:
                    e["conflict_detected"] = True


def verify_evidence_with_quality(
    option_name: str,
    source_indices: list[int],
    sources: list[SearchResult],
) -> dict:
    """Full verification with quality assessment.

    Returns a dict with:
    - evidence: list of evidence rows with confidence data
    - total_evidence: count
    - high_confidence_count: count of high confidence items
    - conflicts: list of conflict descriptions
    - coverage: fraction of criteria that have supporting evidence
    """
    evidence = verify_with_confidence(option_name, source_indices, sources)

    conflicts = [
        {"source": e["source_name"], "stances": [e["stance"]]}
        for e in evidence if e["conflict_detected"]
    ]

    high_confidence = sum(1 for e in evidence if e["confidence_label"] == "high")

    # Compute coverage: how many evidence items have a non-neutral stance
    covered = sum(1 for e in evidence if e["stance"] != "neutral")
    coverage = covered / len(evidence) if evidence else 0.0

    return {
        "evidence": evidence,
        "total_evidence": len(evidence),
        "high_confidence_count": high_confidence,
        "conflicts": conflicts,
        "coverage": round(coverage, 3),
    }


def get_evidence_confidence(evidence_row: dict) -> float:
    """Extract confidence_score from an evidence row (backwards compatible)."""
    return evidence_row.get("confidence_score", 0.5)


def resolve_conflicts(evidence_rows: list[dict]) -> list[dict]:
    """Resolve conflicting evidence by prioritizing high-confidence sources."""
    resolved = []
    seen_claims: set[str] = set()

    # Sort by confidence descending, then by stance strength
    sorted_rows = sorted(
        evidence_rows,
        key=lambda e: (e.get("confidence_score", 0.5), 0 if e["stance"] == "neutral" else 1),
        reverse=True,
    )

    for e in sorted_rows:
        snippet_hash = e["snippet"][:100]
        if snippet_hash not in seen_claims:
            resolved.append(e)
            seen_claims.add(snippet_hash)
        else:
            # Duplicate claim with lower confidence — skip it
            # but note that we resolved a conflict
            pass

    return resolved