"""DecisionPlanner — translates the intent analysis into a concrete
research plan with search queries, expected source types, and
verification strategy.

This agent wraps research_planner and adds planning-specific logic:
query diversification, source-type targeting, and confidence scoring.
"""

from __future__ import annotations

from typing import Optional

from .. import models
from ..agents import research_planner
from ..services.search_service import SearchResult


def build_plan(
    normalized_query: str,
    criteria: list[str],
    constraints: list[str],
    option_type: str,
    max_queries: int = 5,
) -> dict:
    """Generate a structured research plan.

    Returns a dict with:
    - queries: list of search query strings (max max_queries)
    - source_types: list of expected source types (e.g., "review", "spec", "comparison")
    - verification_strategy: how evidence will be verified
    - confidence: confidence in this plan
    """
    queries = research_planner.plan(
        normalized_query, criteria, constraints, option_type
    )

    # Determine expected source types based on option_type and criteria
    source_types = _infer_source_types(option_type, criteria)
    verification_strategy = _determine_verification_strategy(criteria)

    # Limit queries
    queries = queries[:max_queries]

    return {
        "queries": queries,
        "source_types": source_types,
        "verification_strategy": verification_strategy,
        "confidence": 0.85 if queries else 0.3,
    }


def _infer_source_types(option_type: str, criteria: list[str]) -> list[str]:
    """Infer what types of sources we should prioritize."""
    types = ["review", "comparison"]
    criteria_lower = [c.lower() for c in criteria]

    if any(k in " ".join(criteria_lower) for k in ["price", "cost", "budget", "value"]):
        types.append("pricing")
    if any(k in " ".join(criteria_lower) for k in ["spec", "specification", "performance", "feature"]):
        types.append("spec")
    if "academic" in option_type.lower() or "university" in option_type.lower() or "college" in option_type.lower():
        types.append("academic")
    if "job" in option_type.lower() or "career" in option_type.lower():
        types.append("company")
    if "product" in option_type.lower() or "laptop" in option_type.lower() or "phone" in option_type.lower():
        types.append("retail")

    return list(dict.fromkeys(types))  # dedupe, preserve order


def _determine_verification_strategy(criteria: list[str]) -> str:
    """Determine how we'll verify evidence."""
    criteria_lower = [c.lower() for c in criteria]

    if any("price" in c or "cost" in c for c in criteria_lower):
        return "cross-reference pricing across multiple retailers"
    if any("spec" in c for c in criteria_lower):
        return "verify specs against manufacturer pages"
    if any("review" in c or "rating" in c for c in criteria_lower):
        return "aggregate multiple independent reviews"
    return "standard source verification"


def plan_research(
    normalized_query: str,
    criteria: list[str],
    constraints: list[str],
    option_type: str,
) -> list[str]:
    """Simple wrapper for backwards compatibility — returns just the queries."""
    return build_plan(normalized_query, criteria, constraints, option_type)["queries"]