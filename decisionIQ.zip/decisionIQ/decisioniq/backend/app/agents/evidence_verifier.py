"""Stage 5: for each option, look at the real sources it was grounded in
(from option_extractor) and produce evidence entries — snippet text that
came directly from the source, plus an AI-judged stance (supports/against/
neutral) toward that option being a good choice. The snippet stored is
always a substring of what the source actually returned, never AI-generated
text, so evidence can't drift from what the source said."""

from ..services.ai_service import ai_service
from ..services.search_service import SearchResult

SYSTEM_PROMPT = """You are the evidence-verification stage of a
decision-support pipeline. You'll be given one option and a numbered list of
real source snippets that mention it. For each source, judge whether it
supports choosing this option, argues against it, or is neutral/purely
informational. Do not add information that isn't in the snippet.

Return a JSON array, one entry per source index given, like:
[{"source_index": 0, "stance": "supports"}, {"source_index": 2, "stance": "against"}, ...]
stance must be exactly one of: "supports", "against", "neutral"."""


def verify(option_name: str, source_indices: list[int], sources: list[SearchResult]) -> list[dict]:
    numbered = "\n".join(f"[{i}] {sources[i].title}\n    {sources[i].snippet[:400]}" for i in source_indices)
    user_prompt = f"Option: {option_name}\n\nSources:\n{numbered}\n\nJudge each source's stance."

    result = ai_service.complete_json(SYSTEM_PROMPT, user_prompt, max_tokens=400)
    if not isinstance(result, list):
        raise ValueError("Evidence verifier expected a JSON array")

    valid_stances = {"supports", "against", "neutral"}
    evidence_rows = []
    for item in result:
        idx = item.get("source_index")
        stance = item.get("stance", "neutral")
        if not isinstance(idx, int) or idx not in source_indices or stance not in valid_stances:
            continue
        source = sources[idx]
        evidence_rows.append(
            {
                "source_name": source.title,
                "source_url": source.url,
                # Always the source's own text, truncated — never AI-authored.
                "snippet": source.snippet[:400],
                "stance": stance,
            }
        )
    return evidence_rows
