"""QualityChecker — assesses the overall quality of a decision's research
output and provides a quality rating + recommendations for improvement.

This agent wraps the pipeline's final checks and adds:
- overall_quality_score (0-100)
- coverage_gaps: what evidence is missing
- improvement_suggestions: actionable items
- ready_to_recommend: bool
"""

from __future__ import annotations

from typing import Optional

from .. import models
from ..services.ai_service import AIServiceError
from ..schemas import DecisionOut


class QualityRating:
    EXCELLENT = "excellent"  # 85-100
    GOOD = "good"  # 70-84
    FAIR = "fair"  # 55-69
    POOR = "poor"  # 0-54


def assess_quality(
    decision: models.Decision,
    evidence_by_option: dict[str, list[dict]],
    criteria: list[str],
    priorities: dict[str, float] | None,
) -> dict:
    """Assess the quality of a decision's research output.

    Returns a dict with:
    - overall_quality_score: float 0-100
    - quality_rating: str (QualityRating.*)
    - coverage_gaps: list of criteria with little/no evidence
    - improvement_suggestions: list of actionable suggestions
    - ready_to_recommend: bool
    - high_evidence_fraction: fraction of evidence with high confidence
    """
    total_evidence = 0
    high_confidence = 0
    criteria_with_evidence: set[str] = set()
    all_conflicts = []

    # Gather stats across all options
    for option_name, evidence_rows in evidence_by_option.items():
        for e in evidence_rows:
            total_evidence += 1
            if e.get("confidence_score", 0.5) >= 0.75:
                high_confidence += 1
            if e["stance"] != "neutral":
                criteria_with_evidence.add(option_name)

    # Check for conflicts across evidence
    for option_name, evidence_rows in evidence_by_option.items():
        for e in evidence_rows:
            if e.get("conflict_detected", False):
                all_conflicts.append(
                    {"option": option_name, "source": e["source_name"], "stances": [e["stance"]]}
                )

    # Compute overall quality score
    # Base: 40 points for having evidence, 30 for confidence, 30 for coverage
    evidence_score = min(40, total_evidence * 2)
    confidence_score = min(30, high_confidence * 3)
    coverage_score = min(30, len(criteria_with_evidence) / max(len(criteria), 1) * 30)

    overall = round(evidence_score + confidence_score + coverage_score)

    # Determine rating
    if overall >= 85:
        rating = QualityRating.EXCELLENT
    elif overall >= 70:
        rating = QualityRating.GOOD
    elif overall >= 55:
        rating = QualityRating.FAIR
    else:
        rating = QualityRating.POOR

    # Generate improvement suggestions
    suggestions: list[str] = []

    if total_evidence < 3:
        suggestions.append(
            "Gather more sources to strengthen evidence coverage."
        )
    if high_confidence / max(total_evidence, 1) < 0.4:
        suggestions.append(
            "Prioritize higher-quality sources (reputable publishers, recent articles)."
        )
    if all_conflicts:
        suggestions.append(
            "Resolve conflicting evidence by seeking clarifying sources."
        )
    if len(criteria_with_evidence) < len(criteria):
        missing = [c for c in criteria if c not in criteria_with_evidence]
        suggestions.append(
            f"Find evidence for missing criteria: {', '.join(missing)}."
        )
    if not suggestions:
        suggestions.append("Decision research is complete and well-supported.")

    # Ready to recommend if we have decent evidence and no unresolvable conflicts
    ready = (
        overall >= 55
        and total_evidence >= 3
        and len(all_conflicts) < 3
        and len(criteria_with_evidence) >= len(criteria) * 0.6
    )

    return {
        "overall_quality_score": overall,
        "quality_rating": rating,
        "coverage_gaps": sorted(criteria_with_evidence) if criteria_with_evidence else [],
        "improvement_suggestions": suggestions,
        "ready_to_recommend": ready,
        "high_evidence_fraction": round(high_confidence / max(total_evidence, 1), 3),
        "conflicts_detected": len(all_conflicts),
    }


def check_ready_to_recommend(
    decision: models.Decision,
    criteria: list[str],
    priorities: dict[str, float] | None,
    evidence_by_option: dict[str, list[dict]],
) -> bool:
    """Convenience wrapper: return True if the decision is ready for
    recommendation based on quality assessment."""
    result = assess_quality(decision, evidence_by_option, criteria, priorities)
    return result["ready_to_recommend"]