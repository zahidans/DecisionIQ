"""Stage 6: turn each option's collected evidence into a short pros/cons
list. Explicitly told to only use what the evidence actually supports, so
the comparison stays traceable back to real sources rather than the model's
general knowledge."""

from ..services.ai_service import ai_service

SYSTEM_PROMPT = """You are the comparison stage of a decision-support
pipeline. You'll be given an option and its supporting evidence (source
snippets with a stance). Write 2-4 pros and 2-4 cons for this option,
based ONLY on what the evidence says — do not add general knowledge claims
that aren't backed by the evidence given.

Return a JSON object: {"pros": ["...", "..."], "cons": ["...", "..."]}"""


def compare(option_name: str, evidence: list[dict]) -> dict:
    evidence_text = "\n".join(f"- ({e['stance']}) {e['source_name']}: {e['snippet'][:300]}" for e in evidence)
    user_prompt = f"Option: {option_name}\n\nEvidence:\n{evidence_text}\n\nWrite the pros and cons."

    result = ai_service.complete_json(SYSTEM_PROMPT, user_prompt, max_tokens=400)
    if not isinstance(result, dict):
        raise ValueError("Comparator expected a JSON object")

    pros = [str(p) for p in result.get("pros", [])][:4]
    cons = [str(c) for c in result.get("cons", [])][:4]
    return {"pros": pros, "cons": cons}
