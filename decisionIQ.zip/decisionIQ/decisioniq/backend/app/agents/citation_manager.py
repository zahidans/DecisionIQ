"""CitationManager — manages source citations and evidence traceability.

This agent handles:
- Generating proper citations for sources
- Tracing evidence back to original sources
- Building the evidence tree for the decision report
- Detecting and flagging missing citations
"""

from __future__ import annotations

from typing import Optional
from datetime import datetime

from .. import models
from ..services.search_service import SearchResult
from ..schemas import EvidenceOut, SourceOut, ClaimOut


def generate_citation(source: models.Source) -> str:
    """Generate a proper citation string for a source."""
    parts = []

    if source.publisher:
        parts.append(source.publisher)

    parts.append(f"({source.title[:100]})")

    if source.url:
        parts.append(f"[Available from: {source.url}]")

    if source.retrieved_at:
        when = source.retrieved_at.strftime("%Y-%m-%d")
        parts.append(f"Retrieved: {when}")

    return " ".join(parts)


def generate_claim_citation(claim: models.Claim) -> str:
    """Generate citation for a claim, including source link."""
    source_stmt = ""
    if claim.source:
        source_stmt = f"[Source: {claim.source.title}] "

    return f"{source_stmt}{claim.claim_text[:150]}"


def trace_evidence_to_source(
    evidence: models.Evidence,
    include_claims: bool = False,
) -> dict:
    """Trace an evidence record back to its source and optionally claims.

    Returns a dict with:
    - evidence_snippet: the evidence text
    - source_citation: formatted citation for the source
    - source_url: the source URL
    - stance: supports/against/neutral
    - confidence_score: if available
    - linked_claims: list of claim texts if include_claims
    """
    source_citation = "Source not available"
    source_url = ""

    if evidence.source:
        source_citation = generate_citation(evidence.source)
        source_url = evidence.source.url

    result = {
        "evidence_snippet": evidence.snippet[:300],
        "source_citation": source_citation,
        "source_url": source_url,
        "stance": evidence.stance.value if evidence.stance else "neutral",
        "confidence_score": getattr(evidence, "confidence_score", None),
        "linked_claims": [],
    }

    if include_claims and evidence.claim:
        result["linked_claims"].append({
            "text": evidence.claim.claim_text,
            "id": evidence.claim.id,
        })

    return result


def build_evidence_trace(
    decision: models.Decision,
) -> dict:
    """Build the full evidence trace for a decision.

    Returns a dict with:
    - sources: list of source info dicts
    - evidence_tree: nested structure linking sources -> claims -> evidence
    - total_evidence: count
    - unique_sources: count
    """
    sources_list = []
    evidence_tree = []
    seen_urls: set[str] = set()

    # Build source records
    for source in decision.sources:
        if source.url in seen_urls:
            continue
        seen_urls.add(source.url)
        sources_list.append({
            "id": str(source.id),
            "title": source.title,
            "url": source.url,
            "citation": generate_citation(source),
            "publisher": source.publisher,
            "quality_score": source.quality_score,
            "freshness_score": source.freshness_score,
        })

    # Build evidence tree
    for source in decision.sources:
        source_node = {
            "id": str(source.id),
            "title": source.title,
            "claims": [],
            "evidence_count": 0,
        }
        for claim in source.claims:
            claim_node = {
                "id": str(claim.id),
                "text": claim.claim_text[:200],
                "claim_type": claim.claim_type,
                "evidence_count": 0,
            }
            for e in claim.evidence:
                claim_node.setdefault("evidence", []).append({
                    "id": str(e.id),
                    "snippet": e.snippet[:150],
                    "stance": e.stance.value if e.stance else "neutral",
                    "option_id": str(e.option_id) if e.option_id else None,
                })
                claim_node["evidence_count"] += 1
                source_node["evidence_count"] += 1
            source_node["claims"].append(claim_node)
        if source_node["claims"] or source_node["evidence_count"] > 0:
            evidence_tree.append(source_node)

    return {
        "sources": sources_list,
        "evidence_tree": evidence_tree,
        "total_evidence": sum(s.get("evidence_count", 0) for s in sources_list),
        "unique_sources": len(sources_list),
    }


def check_missing_citations(
    evidence_items: list[models.Evidence],
) -> list[dict]:
    """Find evidence items that lack proper source linkage."""
    missing = []

    for e in evidence_items:
        reasons = []
        if not e.source_id:
            reasons.append("no source_id")
        if not e.source:
            reasons.append("source not found")

        if reasons:
            missing.append({
                "evidence_id": str(e.id),
                "snippet_preview": e.snippet[:80],
                "reasons": reasons,
                "severity": "high" if not e.source_id else "medium",
            })

    return missing


def format_bibliography(
    sources: list[models.Source],
    style: str = "apa",
) -> str:
    """Format a bibliography string for all sources."""
    citations = [generate_citation(s) for s in sources]
    return "\n\n".join(f"{i+1}. {c}" for i, c in enumerate(citations))


def get_source_credibility(source: models.Source) -> dict:
    """Assess the credibility of a source based on various factors.

    Returns a dict with:
    - score: 0-100
    - factors: list of contributing factors
    - warnings: any red flags
    """
    score = 50  # base
    factors = []
    warnings = []

    if source.publisher:
        factors.append(f"Publisher: {source.publisher}")
        known_publishers = ["reuters", "associated press", "associatedpress", "bbc", "cnn", "npr", "sciencedirect", "nature", "ieee", "acm"]
        if any(kw in source.publisher.lower() for kw in known_publishers):
            score += 20
            factors.append("Reputable publisher")

    if source.quality_score:
        quality = source.quality_score
        if quality >= 80:
            score += 15
            factors.append("High quality score")
        elif quality < 40:
            warnings.append(f"Low quality score: {quality}")
            score -= 10

    if source.freshness_score:
        freshness = source.freshness_score
        if freshness >= 70:
            score += 10
            factors.append("Fresh source")
        elif freshness < 30:
            warnings.append("Possibly outdated source")
            score -= 10

    # URL checks
    if source.url:
        if ".pdf" in source.url.lower():
            factors.append("PDF source")
        if "scholar" in source.url or "academia" in source.url:
            score += 10
            factors.append("Academic source")

    return {
        "score": min(100, max(0, score)),
        "factors": factors,
        "warnings": warnings,
    }