"""Stage 8: the final synthesis. Explicitly instructed to explain *why*,
name tradeoffs, and say who each option suits — not just declare a winner —
per the product requirement that this isn't a one-line verdict."""

from ..services.ai_service import ai_service

SYSTEM_PROMPT = """You are the recommendation stage of a decision-support
pipeline, DecisionIQ. You'll be given the original question, every option
with its score/pros/cons, and the criteria that were weighted. Write a
clear, honest recommendation in 3-5 short paragraphs (plain text, no
markdown headers) that:

1. States which option comes out ahead and why, referencing the actual
   scores/evidence given.
2. Names the real tradeoffs — what the top option is weaker on.
3. Says explicitly what kind of person/situation might be better served by
   a different option instead.

Do not simply say "Option A is best." Ground every claim in the data given —
do not introduce new facts about the options that weren't provided."""


def recommend(question: str, options_summary: list[dict]) -> str:
    options_text = "\n\n".join(
        f"{o['name']} — score {o.get('score_label', 'n/a')}\n"
        f"Pros: {o.get('pros', [])}\nCons: {o.get('cons', [])}"
        for o in options_summary
    )
    user_prompt = f"Original question: {question}\n\nOptions:\n{options_text}\n\nWrite the final recommendation."
    return ai_service.complete(SYSTEM_PROMPT, user_prompt, max_tokens=800).strip()
