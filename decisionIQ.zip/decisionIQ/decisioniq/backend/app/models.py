import uuid
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import Column, String, DateTime, ForeignKey, Text, Enum, JSON, UniqueConstraint, Float
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .database import Base


def gen_uuid():
    return str(uuid.uuid4())


class PlanTier(PyEnum):
    free = "free"
    plus = "plus"
    pro = "pro"
    enterprise = "enterprise"


class DecisionStatus(PyEnum):
    created = "created"
    researching = "researching"
    comparing = "comparing"
    ready = "ready"
    failed = "failed"


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    full_name = Column(String(120), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    plan = Column(Enum(PlanTier), default=PlanTier.free, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    decisions = relationship("Decision", back_populates="owner", cascade="all, delete-orphan")
    saved = relationship("SavedDecision", back_populates="user", cascade="all, delete-orphan")


class Decision(Base):
    __tablename__ = "decisions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(200), nullable=False)
    category = Column(String(50), nullable=False, index=True)
    question = Column(Text, nullable=False)

    # Optional structured priorities the user supplied, e.g.
    # {"performance": 0.4, "price": 0.3, "battery": 0.2, "portability": 0.1}
    # Used by the scoring agent as criteria weights. Free-form JSON so the
    # frontend can evolve the priority picker without a migration.
    priorities = Column(JSON, nullable=True)

    status = Column(Enum(DecisionStatus), default=DecisionStatus.created, nullable=False, index=True)
    # Short human-readable status for the frontend to poll and display,
    # e.g. "Finding relevant sources...". Updated by the orchestrator at
    # each pipeline stage.
    progress_message = Column(String(300), nullable=True)
    # Populated only when status == failed, with a message safe to show
    # the user (never a raw stack trace).
    error_message = Column(String(500), nullable=True)

    result_summary = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    owner = relationship("User", back_populates="decisions")
    options = relationship("Option", back_populates="decision", cascade="all, delete-orphan")
    evidence = relationship("Evidence", back_populates="decision", cascade="all, delete-orphan")
    sources = relationship("Source", back_populates="decision", cascade="all, delete-orphan")
    saved_by = relationship("SavedDecision", back_populates="decision", cascade="all, delete-orphan")


class Source(Base):
    """A research source for a decision, e.g. a website article, PDF, or document.
    Every piece of research becomes a Source record first. Evidence links to it.
    Fields match what the existing SearchService returns plus added metadata."""

    __tablename__ = "sources"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    decision_id = Column(UUID(as_uuid=False), ForeignKey("decisions.id"), nullable=False, index=True)

    title = Column(String(500), nullable=False)
    url = Column(String(1000), nullable=False)
    publisher = Column(String(200), nullable=True)
    source_type = Column(String(50), default="web")  # web, academic, government, company, etc.
    published_at = Column(DateTime, nullable=True)
    retrieved_at = Column(DateTime, default=datetime.utcnow)

    # Quality and freshness scores (0-100) may be set by verification agents
    quality_score = Column(Float, nullable=True)
    freshness_score = Column(Float, nullable=True)

    source_metadata = Column("metadata", JSON, nullable=True)

    decision = relationship("Decision")
    claims = relationship("Claim", back_populates="source", cascade="all, delete-orphan")
    evidence = relationship("Evidence", back_populates="source", cascade="all, delete-orphan")


class Claim(Base):
    """A structured claim extracted from a source, e.g. "Laptop A has 32GB RAM."
    Never fabricated: if the research/search layer can't find a real source,
    no Claim row is created for that claim."""

    __tablename__ = "claims"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    source_id = Column(UUID(as_uuid=False), ForeignKey("sources.id"), nullable=False, index=True)

    claim_text = Column(Text, nullable=False)
    claim_type = Column(String(50), nullable=True)  # fact, specification, comparison, etc.

    # Optional: link to an option if the claim refers to a specific option being evaluated
    option_id = Column(UUID(as_uuid=False), ForeignKey("options.id"), nullable=True, index=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    source = relationship("Source", back_populates="claims")
    option = relationship("Option", back_populates="claims")
    evidence = relationship("Evidence", back_populates="claim", cascade="all, delete-orphan")


class Option(Base):
    """One of the choices being compared for a decision (e.g. a specific
    laptop, job offer, or college). Populated by the option-extraction,
    comparison, and scoring agents in the research pipeline."""

    __tablename__ = "options"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    decision_id = Column(UUID(as_uuid=False), ForeignKey("decisions.id"), nullable=False, index=True)
    name = Column(String(200), nullable=False)

    # Human-readable score label kept for backward compatibility with the
    # existing UI (e.g. "8.4/10").
    score = Column(String(10), nullable=True)
    # Numeric score (0-10) used for sorting/comparison so the UI doesn't have
    # to parse the label string.
    score_value = Column(Float, nullable=True)
    # Per-criterion breakdown that produced score_value, e.g.
    # [{"criterion": "performance", "weight": 0.4, "score": 8.5, "note": "..."}]
    # This is what makes the score explainable rather than a magic number.
    score_breakdown = Column(JSON, nullable=True)

    pros = Column(Text, nullable=True)  # newline-separated bullet points
    cons = Column(Text, nullable=True)  # newline-separated bullet points
    created_at = Column(DateTime, default=datetime.utcnow)

    decision = relationship("Decision", back_populates="options")
    evidence = relationship("Evidence", back_populates="option", cascade="all, delete-orphan")
    claims = relationship("Claim", back_populates="option")


class EvidenceStance(PyEnum):
    supports = "supports"
    against = "against"
    neutral = "neutral"


class Evidence(Base):
    """A single piece of supporting evidence — a real source, a quote or
    paraphrase, and whether it supports, argues against, or is neutral
    toward an option or the decision overall. Never fabricated: if the
    research/search layer can't find a real source, no Evidence row is
    created for that claim."""

    __tablename__ = "evidence"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    decision_id = Column(UUID(as_uuid=False), ForeignKey("decisions.id"), nullable=False, index=True)
    option_id = Column(UUID(as_uuid=False), ForeignKey("options.id"), nullable=True, index=True)
    source_id = Column(UUID(as_uuid=False), ForeignKey("sources.id"), nullable=True, index=True)
    claim_id = Column(UUID(as_uuid=False), ForeignKey("claims.id"), nullable=True, index=True)

    source_name = Column(String(200), nullable=False)
    source_url = Column(String(500), nullable=True)
    snippet = Column(Text, nullable=False)
    stance = Column(Enum(EvidenceStance), default=EvidenceStance.neutral, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    decision = relationship("Decision", back_populates="evidence")
    option = relationship("Option", back_populates="evidence")
    source = relationship("Source", back_populates="evidence")
    claim = relationship("Claim", back_populates="evidence")


class SavedDecision(Base):
    """A user bookmarking a decision (their own, or eventually a shared
    one). Kept as its own table rather than a boolean flag on Decision so a
    decision can be saved/unsaved without mutating decision history, and so
    "saved by other users" is possible later without a schema change."""

    __tablename__ = "saved_decisions"
    __table_args__ = (UniqueConstraint("user_id", "decision_id", name="uq_saved_user_decision"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    decision_id = Column(UUID(as_uuid=False), ForeignKey("decisions.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="saved")
    decision = relationship("Decision", back_populates="saved_by")