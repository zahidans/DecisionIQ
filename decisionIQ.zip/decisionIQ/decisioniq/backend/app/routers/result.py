from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, auth
from ..database import get_db


router = APIRouter(prefix="/result", tags=["result"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


@router.get("/{decision_id}")
def get_result(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Get the final recommendation result for a decision."""
    decision = _get_owned_decision(decision_id, db, current_user)

    options = sorted(
        decision.options,
        key=lambda o: (o.score_value is None, -(o.score_value or 0)),
    )

    return {
        "decision_id": decision.id,
        "title": decision.title,
        "question": decision.question,
        "recommendation": decision.result_summary,
        "top_option": {
            "id": str(options[0].id),
            "name": options[0].name,
            "score": options[0].score_value,
            "pros": (options[0].pros or "").split("\n") if options[0].pros else [],
            "cons": (options[0].cons or "").split("\n") if options[0].cons else [],
        } if options else None,
        "all_options": [
            {
                "id": str(o.id),
                "name": o.name,
                "score": o.score_value,
                "pros": (o.pros or "").split("\n") if o.pros else [],
                "cons": (o.cons or "").split("\n") if o.cons else [],
                "score_breakdown": o.score_breakdown,
            }
            for o in options
        ],
        "status": decision.status.value if decision.status else None,
        "error_message": decision.error_message,
        "created_at": decision.created_at.isoformat() if decision.created_at else None,
        "updated_at": decision.updated_at.isoformat() if decision.updated_at else None,
    }