from fastapi import APIRouter

router = APIRouter(prefix="/categories", tags=["categories"])

CATEGORIES = [
    {"slug": "education", "name": "Education"},
    {"slug": "career", "name": "Career"},
    {"slug": "technology", "name": "Technology"},
    {"slug": "finance", "name": "Finance"},
    {"slug": "lifestyle", "name": "Lifestyle"},
    {"slug": "travel", "name": "Travel"},
    {"slug": "business", "name": "Business"},
]


@router.get("")
def list_categories():
    return CATEGORIES
