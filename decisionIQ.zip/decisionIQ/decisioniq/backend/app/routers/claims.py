from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, auth
from ..schemas import ClaimOut, EvidenceOut
from ..database import get_db


router = APIRouter(prefix="/claims", tags=["claims"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


@router.get("/{decision_id}", response_model=list[ClaimOut])
def list_claims(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """List all claims extracted from sources for a decision."""
    _get_owned_decision(decision_id, db, current_user)
    claims = (
        db.query(models.Claim)
        .join(models.Source, models.Source.id == models.Claim.source_id)
        .filter(models.Source.decision_id == decision_id)
        .all()
    )
    return claims


@router.get("/{decision_id}/{claim_id}", response_model=ClaimOut)
def get_claim(
    decision_id: str,
    claim_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Get a specific claim with its source context."""
    _get_owned_decision(decision_id, db, current_user)
    claim = (
        db.query(models.Claim)
        .join(models.Source, models.Source.id == models.Claim.source_id)
        .filter(models.Claim.id == claim_id, models.Source.decision_id == decision_id)
        .first()
    )
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    return claim


@router.get("/{decision_id}/{claim_id}/evidence", response_model=list[EvidenceOut])
def get_claim_evidence(
    decision_id: str,
    claim_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Get all evidence linked to a specific claim."""
    _get_owned_decision(decision_id, db, current_user)
    claim = (
        db.query(models.Claim)
        .join(models.Source, models.Source.id == models.Claim.source_id)
        .filter(models.Claim.id == claim_id, models.Source.decision_id == decision_id)
        .first()
    )
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    return claim.evidence