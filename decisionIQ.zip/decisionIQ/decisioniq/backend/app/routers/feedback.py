from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, auth
from ..database import get_db


router = APIRouter(prefix="/feedback", tags=["feedback"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


@router.post("/{decision_id}")
def submit_feedback(
    decision_id: str,
    payload: dict,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Submit user feedback on a decision result for personalization."""
    _get_owned_decision(decision_id, db, current_user)

    feedback_type = payload.get("feedback_type", "general")
    feedback_text = str(payload.get("feedback", "")).strip()

    # Validate feedback text is meaningful
    if not feedback_text:
        raise HTTPException(status_code=400, detail="Feedback text is required")

    # Store feedback in a new table (feedback.py is a router; the model would be added separately)
    # For now, return the feedback for immediate personalization processing
    return {
        "decision_id": decision_id,
        "feedback_type": feedback_type,
        "feedback": feedback_text,
        "status": "recorded",
        "message": "Feedback recorded. This will improve future recommendations.",
    }