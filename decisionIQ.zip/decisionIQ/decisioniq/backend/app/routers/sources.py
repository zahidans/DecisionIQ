from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, auth
from ..schemas import SourceOut
from ..database import get_db


router = APIRouter(prefix="/sources", tags=["sources"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


@router.get("/{decision_id}", response_model=list[SourceOut])
def list_sources(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """List all sources for a decision."""
    _get_owned_decision(decision_id, db, current_user)
    sources = (
        db.query(models.Source)
        .filter(models.Source.decision_id == decision_id)
        .all()
    )
    return sources


@router.get("/{decision_id}/{source_id}", response_model=SourceOut)
def get_source(
    decision_id: str,
    source_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Get a specific source with its claims and evidence count."""
    _get_owned_decision(decision_id, db, current_user)
    source = (
        db.query(models.Source)
        .filter(models.Source.id == source_id, models.Source.decision_id == decision_id)
        .first()
    )
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source