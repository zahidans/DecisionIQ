from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, auth
from ..database import get_db


router = APIRouter(prefix="/comparison", tags=["comparison"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


@router.get("/{decision_id}")
def get_comparison(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Get a structured comparison of all options for a decision."""
    decision = _get_owned_decision(decision_id, db, current_user)

    options = sorted(
        decision.options,
        key=lambda o: (o.score_value is None, -(o.score_value or 0)),
    )

    comparison = {
        "decision_id": decision.id,
        "title": decision.title,
        "question": decision.question,
        "options": [
            {
                "id": str(o.id),
                "name": o.name,
                "score": o.score,
                "score_value": o.score_value,
                "score_breakdown": o.score_breakdown,
                "pros": (o.pros or "").split("\n") if o.pros else [],
                "cons": (o.cons or "").split("\n") if o.cons else [],
                "evidence_count": len(o.evidence),
            }
            for o in options
        ],
        "total_options": len(options),
        "top_option": options[0].name if options else None,
        "recommendation": decision.result_summary,
    }

    return comparison


@router.get("/{decision_id}/matrix")
def get_comparison_matrix(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Get a matrix view of options vs criteria for side-by-side comparison."""
    decision = _get_owned_decision(decision_id, db, current_user)

    options = sorted(
        decision.options,
        key=lambda o: (o.score_value is None, -(o.score_value or 0)),
    )

    # Collect all criteria from score breakdowns
    all_criteria: list[str] = []
    seen_criteria: set[str] = set()
    for o in options:
        if o.score_breakdown:
            for item in o.score_breakdown:
                c = item.get("criterion", "")
                if c and c not in seen_criteria:
                    seen_criteria.add(c)
                    all_criteria.append(c)

    matrix = {
        "decision_id": decision.id,
        "criteria": all_criteria,
        "options": [
            {
                "name": o.name,
                "scores": {
                    item.get("criterion", ""): item.get("score", 0)
                    for item in (o.score_breakdown or [])
                },
                "overall": o.score_value,
            }
            for o in options
        ],
    }

    return matrix