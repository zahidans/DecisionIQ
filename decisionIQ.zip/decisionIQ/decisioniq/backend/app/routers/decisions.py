from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db, SessionLocal
from ..services.orchestrator import run_decision_pipeline

router = APIRouter(prefix="/decisions", tags=["decisions"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


def _is_saved(db: Session, user_id: str, decision_id: str) -> bool:
    return (
        db.query(models.SavedDecision)
        .filter(models.SavedDecision.user_id == user_id, models.SavedDecision.decision_id == decision_id)
        .first()
        is not None
    )


def _serialize(decision: models.Decision, db: Session, user_id: str) -> schemas.DecisionOut:
    """Split evidence into decision-level vs per-option (same `evidence`
    table backs both), and attach whether the current user has saved it."""
    out = schemas.DecisionOut.model_validate(decision)
    out.evidence = [
        schemas.EvidenceOut.model_validate(e) for e in decision.evidence if e.option_id is None
    ]
    out.options = sorted(
        [schemas.OptionOut.model_validate(o) for o in decision.options],
        key=lambda o: (o.score_value is None, -(o.score_value or 0)),
    )
    out.is_saved = _is_saved(db, user_id, decision.id)
    return out


@router.get("", response_model=list[schemas.DecisionOut])
def list_decisions(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    decisions = (
        db.query(models.Decision)
        .filter(models.Decision.user_id == current_user.id)
        .order_by(models.Decision.created_at.desc())
        .all()
    )
    return [_serialize(d, db, current_user.id) for d in decisions]


@router.post("", response_model=schemas.DecisionOut, status_code=201)
def create_decision(
    payload: schemas.DecisionCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    decision = models.Decision(
        user_id=current_user.id,
        title=payload.title,
        category=payload.category,
        question=payload.question,
        priorities=payload.priorities,
        status=models.DecisionStatus.created,
    )
    db.add(decision)
    db.commit()
    db.refresh(decision)

    # Runs after the response is sent, with its own DB session (SessionLocal)
    # since this request's session closes as soon as we return below. Swap
    # this for a real task queue in production — see orchestrator.py.
    background_tasks.add_task(run_decision_pipeline, decision.id, SessionLocal)

    return _serialize(decision, db, current_user.id)


@router.post("/{decision_id}/retry", response_model=schemas.DecisionOut)
def retry_decision(
    decision_id: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    decision = _get_owned_decision(decision_id, db, current_user)
    if decision.status != models.DecisionStatus.failed:
        raise HTTPException(status_code=400, detail="Only a failed decision can be retried")

    # Clear any partial results from the failed attempt before re-running.
    for option in list(decision.options):
        db.delete(option)
    for e in list(decision.evidence):
        db.delete(e)
    decision.result_summary = None
    decision.error_message = None
    decision.status = models.DecisionStatus.created
    db.commit()

    background_tasks.add_task(run_decision_pipeline, decision.id, SessionLocal)
    return _serialize(decision, db, current_user.id)


@router.get("/{decision_id}", response_model=schemas.DecisionOut)
def get_decision(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    decision = _get_owned_decision(decision_id, db, current_user)
    return _serialize(decision, db, current_user.id)
