from collections import Counter

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/insights", tags=["insights"])


@router.get("", response_model=schemas.InsightsOut)
def get_insights(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Every number here is computed directly from the current user's own
    rows — nothing is a placeholder statistic."""
    decisions = (
        db.query(models.Decision)
        .filter(models.Decision.user_id == current_user.id)
        .order_by(models.Decision.created_at.desc())
        .all()
    )

    total = len(decisions)
    by_status = Counter(d.status.value for d in decisions)
    by_category = Counter(d.category for d in decisions)

    top_scores = []
    for d in decisions:
        scored = [o.score_value for o in d.options if o.score_value is not None]
        if scored:
            top_scores.append(max(scored))

    average_top_score = round(sum(top_scores) / len(top_scores), 2) if top_scores else None
    most_common_category = by_category.most_common(1)[0][0] if by_category else None

    return schemas.InsightsOut(
        total_decisions=total,
        ready_decisions=by_status.get("ready", 0),
        researching_decisions=by_status.get("researching", 0) + by_status.get("comparing", 0),
        failed_decisions=by_status.get("failed", 0),
        decisions_by_category=dict(by_category),
        average_top_score=average_top_score,
        most_common_category=most_common_category,
        recent_titles=[d.title for d in decisions[:5]],
    )
