from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db
from .decisions import _get_owned_decision, _serialize

router = APIRouter(prefix="/saved", tags=["saved"])


@router.get("", response_model=list[schemas.DecisionOut])
def list_saved(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    saved = (
        db.query(models.SavedDecision)
        .filter(models.SavedDecision.user_id == current_user.id)
        .order_by(models.SavedDecision.created_at.desc())
        .all()
    )
    return [_serialize(s.decision, db, current_user.id) for s in saved]


@router.post("/{decision_id}", response_model=schemas.DecisionOut, status_code=201)
def save_decision(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    decision = _get_owned_decision(decision_id, db, current_user)

    existing = (
        db.query(models.SavedDecision)
        .filter(models.SavedDecision.user_id == current_user.id, models.SavedDecision.decision_id == decision.id)
        .first()
    )
    if not existing:
        db.add(models.SavedDecision(user_id=current_user.id, decision_id=decision.id))
        db.commit()

    return _serialize(decision, db, current_user.id)


@router.delete("/{decision_id}", status_code=204)
def unsave_decision(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    saved = (
        db.query(models.SavedDecision)
        .filter(models.SavedDecision.user_id == current_user.id, models.SavedDecision.decision_id == decision_id)
        .first()
    )
    if not saved:
        raise HTTPException(status_code=404, detail="Not saved")
    db.delete(saved)
    db.commit()
    return None
