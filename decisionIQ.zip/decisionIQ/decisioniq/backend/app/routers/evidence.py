from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, auth
from ..schemas import EvidenceOut
from ..database import get_db


router = APIRouter(prefix="/evidence", tags=["evidence"])


def _get_owned_decision(decision_id: str, db: Session, user: models.User) -> models.Decision:
    decision = (
        db.query(models.Decision)
        .filter(models.Decision.id == decision_id, models.Decision.user_id == user.id)
        .first()
    )
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision


@router.get("/{decision_id}", response_model=list[EvidenceOut])
def list_evidence(
    decision_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """List all evidence for a decision, with source and claim linkage."""
    _get_owned_decision(decision_id, db, current_user)
    evidence = (
        db.query(models.Evidence)
        .filter(models.Evidence.decision_id == decision_id)
        .all()
    )
    return evidence


@router.get("/{decision_id}/option/{option_id}", response_model=list[EvidenceOut])
def list_evidence_by_option(
    decision_id: str,
    option_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """List evidence for a specific option."""
    _get_owned_decision(decision_id, db, current_user)
    evidence = (
        db.query(models.Evidence)
        .filter(models.Evidence.decision_id == decision_id, models.Evidence.option_id == option_id)
        .all()
    )
    return evidence


@router.get("/{decision_id}/source/{source_id}", response_model=list[EvidenceOut])
def list_evidence_by_source(
    decision_id: str,
    source_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """List evidence from a specific source."""
    _get_owned_decision(decision_id, db, current_user)
    evidence = (
        db.query(models.Evidence)
        .filter(models.Evidence.decision_id == decision_id, models.Evidence.source_id == source_id)
        .all()
    )
    return evidence


@router.get("/{decision_id}/claim/{claim_id}", response_model=list[EvidenceOut])
def list_evidence_by_claim(
    decision_id: str,
    claim_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """List evidence linked to a specific claim."""
    _get_owned_decision(decision_id, db, current_user)
    evidence = (
        db.query(models.Evidence)
        .filter(models.Evidence.decision_id == decision_id, models.Evidence.claim_id == claim_id)
        .all()
    )
    return evidence


@router.post("", response_model=EvidenceOut, status_code=201)
def create_evidence(
    payload: dict,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    """Create a new evidence record with optional source_id and claim_id.
    Call this from research agents when attaching evidence to options."""
    _get_owned_decision(payload["decision_id"], db, current_user)
    source_id = payload.get("source_id")
    claim_id = payload.get("claim_id")
    option_id = payload.get("option_id")
    source_name = payload.get("source_name", "")
    source_url = payload.get("source_url")
    snippet = payload.get("snippet", "")
    stance = payload.get("stance", "neutral")

    # Validate source exists if provided
    if source_id:
        source = db.query(models.Source).filter(models.Source.id == source_id).first()
        if not source:
            raise HTTPException(status_code=404, detail="Source not found")

    # Validate claim exists if provided
    if claim_id:
        claim = db.query(models.Claim).filter(models.Claim.id == claim_id).first()
        if not claim:
            raise HTTPException(status_code=404, detail="Claim not found")

    # Validate option exists if provided
    if option_id:
        option = db.query(models.Option).filter(models.Option.id == option_id).first()
        if not option:
            raise HTTPException(status_code=404, detail="Option not found")

    stance_enum = models.EvidenceStance(stance) if stance in ("supports", "against", "neutral") else models.EvidenceStance.neutral

    evidence = models.Evidence(
        decision_id=payload["decision_id"],
        option_id=option_id if option_id else None,
        source_id=source_id,
        claim_id=claim_id if claim_id else None,
        source_name=source_name,
        source_url=source_url,
        snippet=snippet,
        stance=stance_enum,
    )
    db.add(evidence)
    db.commit()
    db.refresh(evidence)
    return evidence