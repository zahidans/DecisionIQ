from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, EmailStr, Field


class UserCreate(BaseModel):
    full_name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: str
    full_name: str
    email: EmailStr
    plan: str

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=1, max_length=120)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class DecisionCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    category: str
    question: str = Field(min_length=1)
    # Optional criteria weights, e.g. {"performance": 0.4, "price": 0.3, ...}
    # Values should sum to ~1.0; the scoring agent normalizes regardless.
    priorities: Optional[Dict[str, float]] = None


class ScoreCriterion(BaseModel):
    criterion: str
    weight: float
    score: float
    note: Optional[str] = None


class EvidenceOut(BaseModel):
    id: str
    option_id: Optional[str] = None
    source_name: str
    source_url: Optional[str] = None
    snippet: str
    stance: str
    created_at: datetime

    class Config:
        from_attributes = True


class OptionOut(BaseModel):
    id: str
    name: str
    score: Optional[str] = None
    score_value: Optional[float] = None
    score_breakdown: Optional[List[ScoreCriterion]] = None
    pros: Optional[str] = None
    cons: Optional[str] = None
    evidence: List[EvidenceOut] = []

    class Config:
        from_attributes = True


class DecisionOut(BaseModel):
    id: str
    title: str
    category: str
    question: str
    priorities: Optional[Dict[str, float]] = None
    status: str
    progress_message: Optional[str] = None
    error_message: Optional[str] = None
    result_summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    options: List[OptionOut] = []
    evidence: List[EvidenceOut] = []  # evidence not tied to a specific option
    is_saved: bool = False

    class Config:
        from_attributes = True


class OptionCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    score: Optional[str] = None
    score_value: Optional[float] = None
    score_breakdown: Optional[List[ScoreCriterion]] = None
    pros: Optional[str] = None
    cons: Optional[str] = None


class EvidenceCreate(BaseModel):
    option_id: Optional[str] = None
    source_id: Optional[str] = None
    claim_id: Optional[str] = None
    source_name: str = Field(min_length=1, max_length=200)
    source_url: Optional[str] = None
    snippet: str = Field(min_length=1)
    stance: str = "neutral"  # "supports" | "against" | "neutral"


class SourceOut(BaseModel):
    id: str
    title: str
    url: str
    publisher: Optional[str] = None
    source_type: Optional[str] = None
    published_at: Optional[datetime] = None
    retrieved_at: Optional[datetime] = None
    quality_score: Optional[float] = None
    freshness_score: Optional[float] = None
    source_metadata: Optional[Dict[str, Any]] = None
    claims_supported: int = 0
    evidence_count: int = 0

    class Config:
        from_attributes = True


class ClaimOut(BaseModel):
    id: str
    claim_text: str
    claim_type: Optional[str] = None
    source_id: str
    option_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class CategoryOut(BaseModel):
    slug: str
    name: str


class SavedDecisionOut(BaseModel):
    id: str
    decision: DecisionOut
    created_at: datetime

    class Config:
        from_attributes = True


class InsightsOut(BaseModel):
    total_decisions: int
    ready_decisions: int
    researching_decisions: int
    failed_decisions: int
    decisions_by_category: Dict[str, int]
    average_top_score: Optional[float] = None
    most_common_category: Optional[str] = None
    recent_titles: List[str] = []
