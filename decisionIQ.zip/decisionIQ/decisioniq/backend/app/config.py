import logging
import warnings

from pydantic_settings import BaseSettings

logger = logging.getLogger("decisioniq")

DEFAULT_JWT_SECRET = "change-this-to-a-long-random-secret"


class Settings(BaseSettings):
    environment: str = "development"  # "development" | "production"

    database_url: str = "postgresql://decisioniq:decisioniq@localhost:5432/decisioniq"

    jwt_secret: str = DEFAULT_JWT_SECRET
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 10080

    cors_origins: str = "http://localhost:3000"

    # AI provider used by AIService (backend-only — never sent to the browser)
    ai_api_key: str = ""
    ai_api_base_url: str = "https://api.anthropic.com"
    ai_model: str = "claude-sonnet-4-6"
    ai_timeout_seconds: int = 60
    ai_max_retries: int = 2

    # Web research provider used by SearchService (backend-only). Any
    # provider that returns {title, url, snippet} results works — set
    # search_api_base_url to match whichever one you sign up for
    # (e.g. Tavily, Serper, Bing Search). Left empty by default: the
    # research agent will mark the decision failed with a clear message
    # rather than inventing sources when no provider is configured.
    search_api_key: str = ""
    search_api_base_url: str = ""
    search_timeout_seconds: int = 20

    class Config:
        env_file = ".env"

    @property
    def cors_origin_list(self):
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


settings = Settings()

if settings.jwt_secret == DEFAULT_JWT_SECRET:
    msg = (
        "JWT_SECRET is still the default placeholder value. Set a long random "
        "secret in your .env before deploying anywhere reachable."
    )
    if settings.is_production:
        raise RuntimeError(msg)
    warnings.warn(msg)
