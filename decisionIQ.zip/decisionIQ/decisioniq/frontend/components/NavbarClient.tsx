"use client";

import Navbar from "./Navbar";
import { useCurrentUser } from "@/lib/useCurrentUser";

/**
 * Server component pages (e.g. app/use-cases/[slug]/page.tsx, which exports
 * generateStaticParams and therefore can't itself have "use client") render
 * this instead of <Navbar> directly, so they can still show the real logged
 * in user without becoming client components themselves.
 */
export default function NavbarClient({ active }: { active?: string }) {
  const { navUser } = useCurrentUser();
  return <Navbar active={active} user={navUser} />;
}
