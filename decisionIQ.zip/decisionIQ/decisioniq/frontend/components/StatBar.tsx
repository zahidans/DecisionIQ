export default function StatBar({ stats }: { stats: { label: string; value: string }[] }) {
  return (
    <div className="flex flex-wrap gap-8 pt-2">
      {stats.map((s) => (
        <div key={s.label}>
          <div className="text-xl font-bold text-white">{s.value}</div>
          <div className="text-xs text-white/50 max-w-[10rem]">{s.label}</div>
        </div>
      ))}
    </div>
  );
}
