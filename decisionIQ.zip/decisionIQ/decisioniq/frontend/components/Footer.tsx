import { ShieldCheck, FileText, User, BarChart3 } from "lucide-react";

const items = [
  { icon: ShieldCheck, label: "Trusted Information" },
  { icon: FileText, label: "Transparent Process" },
  { icon: User, label: "Personalized Recommendations" },
  { icon: BarChart3, label: "Real-World Impact" },
];

export default function Footer({ quote = "\u201cA must-have tool!\u201d \u2014 DecisionIQ User" }: { quote?: string }) {
  return (
    <footer className="border-t border-border/60 bg-base">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-8 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-6">
          {items.map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2 text-sm text-white/70">
              <Icon size={16} className="text-brand-cyan" />
              {label}
            </div>
          ))}
        </div>
        <div className="flex items-center gap-3 text-sm text-white/60">
          <div className="flex -space-x-2">
            {[1, 2, 3].map((i) => (
              <span key={i} className="h-7 w-7 rounded-full border-2 border-base bg-brand-gradient" />
            ))}
          </div>
          <span>{quote}</span>
        </div>
      </div>
    </footer>
  );
}
