"use client";

/**
 * DecisionIQ's mascot: a friendly floating white robot with glowing blue eyes,
 * a small side antenna disc, and a rounded body — matching the reference
 * design used across the marketing site.
 */
export default function RobotMascot({ className = "", floating = true }: { className?: string; floating?: boolean }) {
  return (
    <div className={`${floating ? "animate-[float_5s_ease-in-out_infinite]" : ""} ${className}`}>
      <svg viewBox="0 0 240 260" className="w-full h-full glow-orb" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="bodyShine" cx="35%" cy="25%" r="75%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="60%" stopColor="#E7ECF7" />
            <stop offset="100%" stopColor="#C7D2E6" />
          </radialGradient>
          <radialGradient id="eyeGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#BEE7FF" />
            <stop offset="100%" stopColor="#38BDF8" />
          </radialGradient>
        </defs>

        {/* antenna */}
        <circle cx="120" cy="18" r="8" fill="#38BDF8" />
        <rect x="117" y="24" width="6" height="20" rx="3" fill="#C7D2E6" />

        {/* ear discs */}
        <circle cx="45" cy="110" r="16" fill="#38BDF8" opacity="0.9" />
        <circle cx="195" cy="110" r="16" fill="#38BDF8" opacity="0.9" />

        {/* head */}
        <rect x="55" y="48" width="130" height="110" rx="55" fill="url(#bodyShine)" />

        {/* face visor */}
        <rect x="75" y="75" width="90" height="55" rx="27" fill="#0B1120" />

        {/* eyes */}
        <path d="M100 100 Q108 88 116 100" stroke="url(#eyeGlow)" strokeWidth="6" strokeLinecap="round" fill="none" />
        <path d="M124 100 Q132 88 140 100" stroke="url(#eyeGlow)" strokeWidth="6" strokeLinecap="round" fill="none" />

        {/* smile */}
        <path d="M108 112 Q120 120 132 112" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" fill="none" opacity="0.8" />

        {/* body */}
        <rect x="70" y="160" width="100" height="80" rx="30" fill="url(#bodyShine)" />

        {/* body label pill */}
        <rect x="88" y="188" width="64" height="14" rx="7" fill="#0B1120" />
        <text x="120" y="198" textAnchor="middle" fontSize="9" fontFamily="Sora, sans-serif" fill="#38BDF8" fontWeight="700">
          DecisionIQ
        </text>

        {/* arms */}
        <circle cx="58" cy="185" r="12" fill="#C7D2E6" />
        <circle cx="182" cy="185" r="12" fill="#C7D2E6" />
      </svg>
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-14px); }
        }
      `}</style>
    </div>
  );
}
