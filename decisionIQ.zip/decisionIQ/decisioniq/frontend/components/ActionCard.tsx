import { ArrowRight } from "lucide-react";
import * as Icons from "lucide-react";

export default function ActionCard({
  title,
  description,
  icon = "Sparkles",
}: {
  title: string;
  description: string;
  icon?: keyof typeof Icons;
}) {
  const Icon = (Icons[icon] as any) || Icons.Sparkles;
  return (
    <div className="card p-5 transition hover:border-brand-blue/50">
      <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-brand-gradient-soft text-brand-cyan">
        <Icon size={20} />
      </div>
      <h4 className="mb-1 font-semibold">{title}</h4>
      <p className="mb-3 text-sm text-white/60">{description}</p>
      <ArrowRight size={16} className="text-white/40" />
    </div>
  );
}
