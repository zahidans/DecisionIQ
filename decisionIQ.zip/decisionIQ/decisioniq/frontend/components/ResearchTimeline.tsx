"use client";

import { CheckCircle, Loader2, Circle, Clock } from "lucide-react";

export type Stage = {
  label: string;
  status: "pending" | "in_progress" | "done" | "failed";
  message?: string;
  timestamp?: string;
};

export default function ResearchTimeline({ stages }: { stages: Stage[] }) {
  return (
    <div className="space-y-0">
      {stages.map((stage, i) => {
        const isLast = i === stages.length - 1;
        const Icon =
          stage.status === "done"
            ? CheckCircle
            : stage.status === "in_progress"
            ? Loader2
            : stage.status === "failed"
            ? Circle
            : Circle;
        const iconClass =
          stage.status === "done"
            ? "text-emerald-400"
            : stage.status === "in_progress"
            ? "text-brand-cyan"
            : stage.status === "failed"
            ? "text-rose-400"
            : "text-white/30";

        return (
          <div key={stage.label} className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className={`flex h-8 w-8 items-center justify-center rounded-full bg-panel/60 ${iconClass}`}>
                <Icon size={16} className={stage.status === "in_progress" ? "animate-spin" : ""} />
              </div>
              {!isLast && (
                <div className="mt-1 h-8 w-0.5 bg-white/10" />
              )}
            </div>
            <div className="pb-6">
              <div className="flex items-center gap-2">
                <p className="font-semibold text-white/90">{stage.label}</p>
                {stage.status === "in_progress" && (
                  <span className="rounded-full bg-brand-cyan/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-brand-cyan">
                    In progress
                  </span>
                )}
                {stage.status === "done" && (
                  <span className="rounded-full bg-emerald-400/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-400">
                    Done
                  </span>
                )}
                {stage.status === "failed" && (
                  <span className="rounded-full bg-rose-400/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-rose-400">
                    Failed
                  </span>
                )}
              </div>
              {stage.message && <p className="mt-1 text-sm text-white/60">{stage.message}</p>}
              {stage.timestamp && <p className="mt-1 text-xs text-white/40">{stage.timestamp}</p>}
            </div>
          </div>
        );
      })}
    </div>
  );
}