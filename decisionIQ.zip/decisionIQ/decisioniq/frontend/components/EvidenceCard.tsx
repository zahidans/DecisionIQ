"use client";

import { ShieldCheck, ArrowRight, ArrowLeft, X, ExternalLink } from "lucide-react";

export type EvidenceCardProps = {
  snippet: string;
  stance: "supports" | "against" | "neutral";
  sourceName?: string;
  sourceUrl?: string;
  confidenceScore?: number;
  confidenceLabel?: string;
  conflictDetected?: boolean;
  claimText?: string;
  optionName?: string;
  onOpen?: (evidence: EvidenceCardProps) => void;
};

const stanceConfig: Record<EvidenceCardProps["stance"], { label: string; className: string; icon: any }> = {
  supports: { label: "Supports", className: "bg-emerald-400/15 text-emerald-400", icon: ArrowRight },
  against: { label: "Against", className: "bg-rose-400/15 text-rose-400", icon: ArrowLeft },
  neutral: { label: "Neutral", className: "bg-white/10 text-white/60", icon: X },
};

export default function EvidenceCard({
  snippet,
  stance = "neutral",
  sourceName,
  sourceUrl,
  confidenceScore,
  confidenceLabel = "medium",
  conflictDetected = false,
  claimText,
  optionName,
  onOpen,
}: EvidenceCardProps) {
  const stanceConfigItem = stanceConfig[stance];
  const ConfidenceIcon = stanceConfigItem.icon;

  return (
    <div className="card p-4 hover:border-brand-blue/40 transition">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          {claimText && (
            <div className="rounded-lg bg-violet-500/10 p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-violet-400">Claim</p>
              <p className="mt-1 text-xs text-white/80 leading-relaxed">{claimText}</p>
            </div>
          )}
          <p className="mt-2 text-sm leading-relaxed text-white/80">{snippet}</p>
        </div>
        <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide ${stanceConfigItem.className}`}>
          {stanceConfigItem.label}
        </span>
      </div>

      {sourceName && (
        <div className="mt-3 flex items-center gap-2 text-xs">
          <ShieldCheck size={12} className="text-brand-cyan" />
          <span className="text-white/50">{sourceName}</span>
          {sourceUrl && (
            <a href={sourceUrl} target="_blank" rel="noopener noreferrer" className="text-brand-cyan/80 hover:text-brand-cyan">
              <ExternalLink size={12} />
            </a>
          )}
        </div>
      )}

      <div className="mt-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs text-white/50">Confidence</span>
          <span className={`text-xs font-semibold ${confidenceLabel === "high" ? "text-emerald-400" : confidenceLabel === "low" ? "text-rose-400" : "text-amber-400"}`}>
            {confidenceLabel}
          </span>
          {confidenceScore !== undefined && <span className="text-xs text-white/40">{confidenceScore.toFixed(2)}</span>}
        </div>
        {conflictDetected && (
          <span className="flex items-center gap-1 text-xs text-rose-400">
            <ShieldCheck size={12} /> Conflict detected
          </span>
        )}
      </div>

      {onOpen && (
        <button
          onClick={() => onOpen({
            snippet,
            stance,
            sourceName,
            sourceUrl,
            confidenceScore,
            confidenceLabel,
            conflictDetected,
            claimText,
            optionName,
          })}
          className="btn-outline mt-3 w-full justify-center !py-1.5 text-xs"
        >
          View Evidence Details
        </button>
      )}
    </div>
  );
}

