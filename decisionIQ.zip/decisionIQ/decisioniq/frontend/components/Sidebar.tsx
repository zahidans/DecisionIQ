"use client";

import Link from "next/link";
import {
  LayoutDashboard,
  Search,
  PlusCircle,
  ClipboardList,
  Bookmark,
  BarChart2,
  Layers,
  Users,
  Settings,
} from "lucide-react";

const items = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/explore", label: "Explore", icon: Search },
  { href: "/decisions/new", label: "New Decision", icon: PlusCircle },
  { href: "/decisions", label: "My Decisions", icon: ClipboardList },
  { href: "/saved", label: "Saved", icon: Bookmark },
  { href: "/insights", label: "Insights", icon: BarChart2 },
  { href: "/use-cases", label: "Use Cases", icon: Layers },
  { href: "/community", label: "Community", icon: Users },
  { href: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar({ active }: { active?: string }) {
  return (
    <aside className="hidden lg:flex w-56 shrink-0 flex-col justify-between border-r border-border/60 px-4 py-6">
      <nav className="space-y-1">
        {items.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${
              active === href ? "bg-panel2 text-white" : "text-white/60 hover:bg-panel2/60 hover:text-white"
            }`}
          >
            <Icon size={17} />
            {label}
          </Link>
        ))}
      </nav>
      <blockquote className="text-xs italic text-white/40 leading-relaxed border-l-2 border-brand-purple pl-3">
        "Better Decisions.
        <br />A Brighter You."
      </blockquote>
    </aside>
  );
}
