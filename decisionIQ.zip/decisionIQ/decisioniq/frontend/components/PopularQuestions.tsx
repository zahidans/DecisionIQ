"use client";
import { Plus } from "lucide-react";
import { useState } from "react";

export default function PopularQuestions({ questions }: { questions: string[] }) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="card p-5">
      <h3 className="mb-4 font-semibold">Popular Questions</h3>
      <ul className="space-y-3">
        {questions.map((q, i) => (
          <li key={q}>
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="flex w-full items-center justify-between gap-3 text-left text-sm text-white/80 hover:text-white"
            >
              <span className="flex items-center gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-border">
                  <Plus size={12} />
                </span>
                {q}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
