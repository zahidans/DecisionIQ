"use client";

import { ExternalLink, ShieldCheck, RefreshCw } from "lucide-react";

export type SourceCardProps = {
  title: string;
  url?: string;
  publisher?: string;
  sourceType?: string;
  qualityScore?: number;
  freshnessScore?: number;
  citation?: string;
  onOpen?: (source: SourceCardProps) => void;
};

export default function SourceCard({
  title,
  url,
  publisher,
  sourceType = "web",
  qualityScore,
  freshnessScore,
  citation,
  onOpen,
}: SourceCardProps) {
  const quality = qualityScore ?? 0;
  const freshness = freshnessScore ?? 0;

  return (
    <div className="card p-5 hover:border-brand-blue/40 transition group">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="rounded bg-brand-blue/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-brand-blue">{sourceType}</span>
            {publisher && <span className="text-xs text-white/50">{publisher}</span>}
          </div>
          <h3 className="mt-2 font-semibold leading-snug">{title}</h3>
          {citation && <p className="mt-2 text-xs text-white/50 leading-relaxed">{citation}</p>}
        </div>
        {url && (
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Open source: ${title}`}
            className="shrink-0 rounded-full p-2 text-white/40 transition group-hover:bg-brand-blue/20 group-hover:text-brand-cyan"
          >
            <ExternalLink size={16} />
          </a>
        )}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-lg bg-panel/60 p-3">
          <div className="flex items-center gap-1 text-xs text-white/50">
            <ShieldCheck size={12} /> Source quality
          </div>
          <div className="mt-1 flex items-center gap-2">
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-brand-cyan" style={{ width: `${quality}%` }} />
            </div>
            <span className="text-xs text-brand-cyan">{quality}%</span>
          </div>
        </div>
        <div className="rounded-lg bg-panel/60 p-3">
          <div className="flex items-center gap-1 text-xs text-white/50">
            <RefreshCw size={12} /> Freshness
          </div>
          <div className="mt-1 flex items-center gap-2">
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-brand-purple/80" style={{ width: `${freshness}%` }} />
            </div>
            <span className="text-xs text-brand-purple">{freshness}%</span>
          </div>
        </div>
      </div>

      {onOpen && (
        <button onClick={() => onOpen({ title, url, publisher, sourceType, qualityScore, freshnessScore, citation })} className="btn-outline mt-4 w-full justify-center !py-2 text-xs">
          View Source Details
        </button>
      )}
    </div>
  );
}
