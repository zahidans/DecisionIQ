"use client";

import Link from "next/link";
import { useState } from "react";
import { Search, Bell, ChevronDown, Menu, X } from "lucide-react";

const links = [
  { href: "/", label: "Home" },
  { href: "/explore", label: "Explore" },
  { href: "/how-it-works", label: "How It Works" },
  { href: "/use-cases", label: "Use Cases" },
  { href: "/pricing", label: "Pricing" },
  { href: "/about", label: "About" },
];

export default function Navbar({
  active,
  user,
}: {
  active?: string;
  user?: { name: string; initials: string } | null;
}) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-base/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2">
          <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
            <rect width="34" height="34" rx="10" fill="url(#navLogo)" />
            <path d="M9 20c0-6 4-10 8-10s8 4 8 10-4 6-8 6-8 0-8-6Z" stroke="white" strokeWidth="1.6" />
            <defs>
              <linearGradient id="navLogo" x1="0" y1="0" x2="34" y2="34">
                <stop stopColor="#6D5DF6" />
                <stop offset="1" stopColor="#38BDF8" />
              </linearGradient>
            </defs>
          </svg>
          <div className="leading-none">
            <div className="text-lg font-bold">
              Decision<span className="gradient-text">IQ</span>
            </div>
            <div className="text-[10px] text-white/50">Research less. Decide better.</div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-white/80">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`relative pb-1 transition hover:text-white ${
                active === l.href ? "text-white after:absolute after:-bottom-[17px] after:left-0 after:h-[2px] after:w-full after:bg-brand-gradient" : ""
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <button aria-label="Search" className="text-white/70 hover:text-white">
            <Search size={18} />
          </button>
          {user ? (
            <>
              <button aria-label="Notifications" className="relative text-white/70 hover:text-white">
                <Bell size={18} />
                <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-pink-500" />
              </button>
              <button className="flex items-center gap-2 text-sm font-medium">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient text-xs font-bold">
                  {user.initials}
                </span>
                {user.name}
                <ChevronDown size={14} />
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-medium text-white/80 hover:text-white">
                Log in
              </Link>
              <Link href="/signup" className="btn-primary !py-2 !px-5 text-sm">
                Get Started &rarr;
              </Link>
            </>
          )}
        </div>

        <button className="lg:hidden text-white" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border/60 px-6 py-4 space-y-3">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="block text-white/80" onClick={() => setOpen(false)}>
              {l.label}
            </Link>
          ))}
          <div className="flex gap-3 pt-2">
            <Link href="/login" className="btn-outline flex-1 justify-center !py-2">Log in</Link>
            <Link href="/signup" className="btn-primary flex-1 justify-center !py-2">Get Started</Link>
          </div>
        </div>
      )}
    </header>
  );
}
