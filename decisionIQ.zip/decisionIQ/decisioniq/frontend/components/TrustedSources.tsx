export default function TrustedSources({ sources }: { sources: string[] }) {
  return (
    <div className="card p-5">
      <h3 className="mb-4 font-semibold">Trusted Sources</h3>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {sources.map((s) => (
          <div key={s} className="flex items-center justify-center rounded-lg border border-border py-4 text-center text-sm text-white/70">
            {s}
          </div>
        ))}
      </div>
    </div>
  );
}
