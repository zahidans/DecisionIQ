export type Category = {
  slug: string;
  name: string;
  eyebrow: string;
  title: string;
  titleAccent: string;
  description: string;
  stats: { label: string; value: string }[];
  actions: { title: string; description: string }[];
  popularQuestions: string[];
  trustedSources: string[];
  testimonial: { quote: string; author: string };
  accent: string; // tailwind color class stem
  image: string;
};

export const categories: Category[] = [
  {
    slug: "technology",
    name: "Technology",
    eyebrow: "Use Cases > Technology",
    title: "Smarter Tech Decisions",
    titleAccent: "for a Brighter Tomorrow.",
    description:
      "From choosing the right gadgets to understanding new technologies — DecisionIQ helps you make smarter tech decisions with trusted data, expert insights, and AI-powered recommendations.",
    stats: [
      { label: "Tech Enthusiasts Helped", value: "1M+" },
      { label: "Tech Categories Covered", value: "500+" },
      { label: "Product & Innovation Insights", value: "Global" },
      { label: "by Students & Professionals", value: "Trusted" },
    ],
    actions: [
      { title: "Compare Products", description: "Compare laptops, phones, gadgets and more with real user reviews." },
      { title: "Explore Software Tools", description: "Find the best software for your needs — from productivity to design." },
      { title: "Understand New Technologies", description: "Get simple explanations on AI, blockchain, cloud computing and more." },
      { title: "Buying Guidance", description: "Make confident purchase decisions with expert insights and price analysis." },
      { title: "Industry Trends", description: "Stay updated with the latest tech trends and innovations across the world." },
      { title: "Troubleshooting & Support", description: "Get solutions to common tech problems with step-by-step guidance." },
    ],
    popularQuestions: [
      "Which laptop is best for students in 2026?",
      "Is it worth buying an iPhone or Android in 2026?",
      "What are the best AI tools for productivity?",
      "How do I choose the right graphics card?",
      "What is cloud computing and why is it important?",
    ],
    trustedSources: ["TechRadar", "CNET", "The Verge", "GSMArena", "MIT Technology Review"],
    testimonial: {
      quote:
        "DecisionIQ helped me choose the right laptop for my coding and college needs. The comparison and insights were super helpful. I feel much more confident in my purchase!",
      author: "A College Student",
    },
    accent: "brand-blue",
    image: "/hero/technology.png",
  },
  {
    slug: "lifestyle",
    name: "Lifestyle",
    eyebrow: "Use Cases > Lifestyle",
    title: "A Better You,",
    titleAccent: "Every Day.",
    description:
      "From fitness and nutrition to mental well-being and daily routines — DecisionIQ helps you make smarter lifestyle choices with trusted data, personalized insights, and AI-powered recommendations.",
    stats: [
      { label: "People Building Healthier Lives", value: "1M+" },
      { label: "Lifestyle Categories", value: "7+" },
      { label: "Recommendations", value: "Personalized" },
      { label: "User Satisfaction", value: "95%" },
    ],
    actions: [
      { title: "Fitness Guidance", description: "Get personalized workout plans, exercise tips and fitness goals." },
      { title: "Nutrition & Diet", description: "Find healthy meal plans, diet options and nutrition guidance." },
      { title: "Mental Well-being", description: "Explore stress management, mindfulness and mental health resources." },
      { title: "Daily Routines", description: "Build productive habits and balanced daily routines." },
      { title: "Hobbies & Personal Growth", description: "Discover hobbies, learn new skills and become a better version of yourself." },
    ],
    popularQuestions: [
      "What is the best workout routine for beginners?",
      "What foods are best for weight loss?",
      "How can I improve my sleep quality?",
      "What are effective ways to reduce stress?",
      "How do I build a productive daily routine?",
    ],
    trustedSources: ["WHO Health Guidelines", "Harvard Health", "Mayo Clinic", "National Institutes of Health", "WebMD"],
    testimonial: {
      quote:
        "DecisionIQ helped me create a balanced routine with workout, healthy diet and better sleep. I feel more energetic and focused now!",
      author: "A Happy User",
    },
    accent: "pink-500",
    image: "/hero/lifestyle.png",
  },
  {
    slug: "finance",
    name: "Finance",
    eyebrow: "Use Cases > Finance",
    title: "Smarter Financial Decisions.",
    titleAccent: "A Brighter Tomorrow.",
    description:
      "From investments and savings to loans and taxes — DecisionIQ helps you make confident financial decisions with trusted data, real-time insights, and AI-powered analysis.",
    stats: [
      { label: "People Making Smarter Money Decisions", value: "1M+" },
      { label: "Trusted Financial Sources", value: "500+" },
      { label: "Financial Categories", value: "7+" },
      { label: "User Satisfaction", value: "95%" },
    ],
    actions: [
      { title: "Investment Options", description: "Compare mutual funds, stocks, bonds and more with unbiased insights." },
      { title: "Savings Plans", description: "Find the best savings accounts, FDs and recurring deposit options." },
      { title: "Loan Comparison", description: "Compare personal, home, education and car loans with real rates and terms." },
      { title: "Tax Information", description: "Get simplified guidance on tax saving options and filing requirements." },
      { title: "Personal Finance Tips", description: "Learn budgeting, expense tracking and wealth building strategies." },
      { title: "Retirement Planning", description: "Plan for your future with smart retirement and pension options." },
    ],
    popularQuestions: [
      "Which investment option is best for beginners?",
      "How can I save more money every month?",
      "Should I take a home loan or continue renting?",
      "What are the latest tax saving options in 2026?",
      "How do I plan for retirement early?",
    ],
    trustedSources: ["Reserve Bank of India", "SEBI", "Moneycontrol", "Economic Times", "Tata Capital"],
    testimonial: {
      quote:
        "DecisionIQ helped me compare mutual funds and plan my investments better. I feel much more confident about my financial future now!",
      author: "A Working Professional",
    },
    accent: "brand-cyan",
    image: "/hero/finance.png",
  },
  {
    slug: "education",
    name: "Education",
    eyebrow: "Use Cases > Education",
    title: "Smarter Education",
    titleAccent: "Brighter Futures.",
    description:
      "From choosing the right college to comparing courses and finding scholarships — DecisionIQ helps you make informed education decisions with trusted data and AI-powered insights.",
    stats: [
      { label: "Universities & Colleges", value: "1000+" },
      { label: "Courses & Programs", value: "500+" },
      { label: "Global Sources", value: "Trusted" },
      { label: "Recommendations", value: "Personalized" },
    ],
    actions: [
      { title: "Compare Colleges", description: "Compare top universities based on rankings, fees, placements and more." },
      { title: "Explore Courses", description: "Find the right course that matches your interests and career goals." },
      { title: "Find Scholarships", description: "Discover scholarships, eligibility criteria and deadlines." },
      { title: "Check Rankings", description: "View global and national rankings with detailed insights." },
      { title: "Admission Guidance", description: "Get step-by-step admission process, required documents and important dates." },
      { title: "Study Abroad", description: "Explore opportunities in top countries with visa, cost and living insights." },
    ],
    popularQuestions: [
      "Which college is best for Computer Science?",
      "What are the admission requirements for top universities?",
      "Which course has better career opportunities?",
      "How can I apply for scholarships?",
      "Compare IITs vs NITs vs private universities.",
    ],
    trustedSources: ["NIRF Rankings", "QS World Rankings", "Times Higher Education", "Google Scholar", "University Websites"],
    testimonial: {
      quote:
        "DecisionIQ helped me compare universities, check placements and find the right course. It saved me weeks of research!",
      author: "A Engineering Student",
    },
    accent: "brand-blue",
    image: "/hero/education.png",
  },
  {
    slug: "career",
    name: "Career",
    eyebrow: "Use Cases > Career",
    title: "Grow Your Career",
    titleAccent: "with Smarter Decisions.",
    description:
      "Explore job opportunities, in-demand skills, career paths and industry insights — all in one place. DecisionIQ helps you make confident career decisions with trusted data and AI.",
    stats: [
      { label: "Professionals Helped", value: "1M+" },
      { label: "Job Roles Covered", value: "500+" },
      { label: "Career Market Data", value: "Global" },
      { label: "by Students & Professionals", value: "Trusted" },
    ],
    actions: [
      { title: "Explore Job Opportunities", description: "Discover job openings across industries, locations and experience levels." },
      { title: "In-Demand Skills", description: "Find the skills employers are looking for and how to learn them." },
      { title: "Career Path Guidance", description: "Explore different career paths based on your interests, background and goals." },
      { title: "Certifications & Courses", description: "Get recommendations for certifications and courses to boost your profile." },
      { title: "Industry Insights", description: "Access trends, salary data and growth opportunities in various industries." },
      { title: "Resume & Interview Tips", description: "Get AI-powered tips to improve your resume and prepare for interviews." },
    ],
    popularQuestions: [
      "What are the best jobs for my skills?",
      "Which skills are in high demand in 2026?",
      "Should I do an MBA or gain work experience?",
      "What certifications can boost my career?",
      "How do I switch to a different career field?",
    ],
    trustedSources: ["LinkedIn", "Naukri", "Indeed", "Glassdoor", "Unstop"],
    testimonial: {
      quote:
        "DecisionIQ helped me understand the skills I needed and guided me towards the right career path. Today, I'm working at a company I always dreamed of!",
      author: "A Working Professional",
    },
    accent: "brand-purple",
    image: "/hero/career.png",
  },
  {
    slug: "travel",
    name: "Travel",
    eyebrow: "Use Cases > Travel",
    title: "Plan Better Trips,",
    titleAccent: "Explore More.",
    description:
      "From finding the best destinations to comparing costs, visas, and itineraries — DecisionIQ helps you plan smarter trips with real data, trusted sources, and AI-powered insights.",
    stats: [
      { label: "Destinations Covered", value: "1000+" },
      { label: "Travel Information", value: "Real-Time" },
      { label: "Travel Planning Decisions", value: "1M+" },
      { label: "User Satisfaction", value: "95%" },
    ],
    actions: [
      { title: "Find Destinations", description: "Discover the best places to visit based on your interests, budget and season." },
      { title: "Compare Travel Options", description: "Compare flights, hotels, transport and itineraries across multiple sources." },
      { title: "Visa & Entry Guidance", description: "Get the latest visa requirements, document checklists and travel restrictions." },
      { title: "Plan Your Itinerary", description: "Create personalized day-wise travel plans with top attractions, food and experiences." },
      { title: "Budget Your Trip", description: "Estimate and compare costs for flights, stay, food and activities to plan within your budget." },
      { title: "Travel Tips & Safety", description: "Get local tips, safety advice and cultural insights for a hassle-free journey." },
    ],
    popularQuestions: [
      "What are the best countries to visit in Europe?",
      "How much does a 7-day trip to Japan cost?",
      "Do I need a visa for Germany from India?",
      "What is the best time to visit Switzerland?",
      "How can I create a cost-effective travel itinerary?",
    ],
    trustedSources: ["TripAdvisor", "Booking.com", "Skyscanner", "Google Maps", "Lonely Planet"],
    testimonial: {
      quote:
        "DecisionIQ helped me plan my Europe trip in just a few hours. I got the best itinerary, budget estimate and visa details — all in one place!",
      author: "A Happy Traveller",
    },
    accent: "brand-cyan",
    image: "/hero/travel.png",
  },
  {
    slug: "business",
    name: "Business",
    eyebrow: "Use Cases > Business",
    title: "Smarter Business",
    titleAccent: "Decisions. Bigger Impact.",
    description:
      "From market research and competitor analysis to business expansion and risk assessment — DecisionIQ helps you make smarter business decisions with real data, AI-powered insights, and trusted sources.",
    stats: [
      { label: "Entrepreneurs & Business Professionals", value: "1M+" },
      { label: "Industries Covered", value: "100+" },
      { label: "Market Insights", value: "Global" },
      { label: "by Professionals", value: "Trusted" },
    ],
    actions: [
      { title: "Market Research", description: "Understand market size, trends and customer demands." },
      { title: "Competitor Analysis", description: "Compare competitors, find gaps and identify opportunities." },
      { title: "Business Idea Validation", description: "Validate your ideas with real data and market insights." },
      { title: "Strategic Planning", description: "Get data-driven insights for short-term and long-term strategy." },
      { title: "Risk Assessment", description: "Identify potential risks and make informed decisions." },
      { title: "Growth & Expansion", description: "Discover new markets, partnerships and scaling opportunities." },
    ],
    popularQuestions: [
      "Is this a good market for my business idea?",
      "Who are my main competitors?",
      "What are the latest industry trends?",
      "How can I expand my business internationally?",
      "What are the risks in this market?",
    ],
    trustedSources: ["Statista", "World Bank", "McKinsey", "Forbes", "Harvard Business Review"],
    testimonial: {
      quote:
        "DecisionIQ helped me analyze my competitors and find a new market opportunity. It gave me the confidence to expand my business, and today we're in 3 new cities!",
      author: "A Startup Founder",
    },
    accent: "brand-purple",
    image: "/hero/business.png",
  },
  {
    slug: "products",
    name: "Products",
    eyebrow: "Use Cases > Products",
    title: "Smarter Product",
    titleAccent: "Choices, Every Time.",
    description:
      "From electronics and gadgets to everyday essentials — DecisionIQ compares specs, prices, and real reviews so you can pick the right product with confidence, backed by real sources.",
    stats: [
      { label: "Products Compared", value: "1M+" },
      { label: "Product Categories", value: "500+" },
      { label: "Price & Spec Sources", value: "Global" },
      { label: "by Shoppers Worldwide", value: "Trusted" },
    ],
    actions: [
      { title: "Compare Specifications", description: "Line up specs side-by-side across brands and models." },
      { title: "Price Comparison", description: "Track prices across sellers to find the best real deal." },
      { title: "Real Reviews", description: "See what verified buyers actually say, not just marketing copy." },
      { title: "Alternatives", description: "Discover similar products at different price points." },
      { title: "Pros & Cons", description: "Get a clear, evidence-backed breakdown before you buy." },
      { title: "Use-Case Matching", description: "Find the product that actually fits what you'll use it for." },
    ],
    popularQuestions: [
      "Which product is best for my budget?",
      "What are the top alternatives to this product?",
      "Is this product worth the price?",
      "What do verified buyers say about this?",
      "Which model has the best value for money?",
    ],
    trustedSources: ["Amazon Reviews", "Consumer Reports", "RTINGS", "PriceHistory", "Manufacturer Specs"],
    testimonial: {
      quote:
        "DecisionIQ compared three headphones for me in minutes and told me exactly which one fit my use case. Saved me from a bad purchase.",
      author: "A Careful Shopper",
    },
    accent: "brand-blue",
    image: "/hero/technology.png",
  },
];

export function getCategory(slug: string) {
  return categories.find((c) => c.slug === slug);
}
