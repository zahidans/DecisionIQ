const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function request(path: string, options: RequestInit = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("diq_token") : null;
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed: ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  register: (data: { full_name: string; email: string; password: string }) =>
    request("/auth/register", { method: "POST", body: JSON.stringify(data) }),

  login: (data: { email: string; password: string }) =>
    request("/auth/login", { method: "POST", body: JSON.stringify(data) }),

  me: () => request("/auth/me"),

  updateMe: (data: { full_name?: string }) =>
    request("/auth/me", { method: "PATCH", body: JSON.stringify(data) }),

  listCategories: () => request("/categories"),

  listDecisions: () => request("/decisions"),

  createDecision: (data: { title: string; category: string; question: string; priorities?: Record<string, number> }) =>
    request("/decisions", { method: "POST", body: JSON.stringify(data) }),

  getDecision: (id: string) => request(`/decisions/${id}`),

  retryDecision: (id: string) => request(`/decisions/${id}/retry`, { method: "POST" }),

  addOption: (decisionId: string, data: { name: string; score?: string; pros?: string; cons?: string }) =>
    request(`/decisions/${decisionId}/options`, { method: "POST", body: JSON.stringify(data) }),

  listSaved: () => request("/saved"),

  saveDecision: (id: string) => request(`/saved/${id}`, { method: "POST" }),

  unsaveDecision: (id: string) => request(`/saved/${id}`, { method: "DELETE" }),

  getInsights: () => request("/insights"),

  // Research status
  getResearchStatus: (id: string) => request(`/research/${id}/status`),

  // Sources
  listSources: (decisionId: string) => request(`/sources/${decisionId}`),
  getSource: (decisionId: string, sourceId: string) => request(`/sources/${decisionId}/${sourceId}`),

  // Claims
  listClaims: (decisionId: string) => request(`/claims/${decisionId}`),
  getClaim: (decisionId: string, claimId: string) => request(`/claims/${decisionId}/${claimId}`),
  getClaimEvidence: (decisionId: string, claimId: string) => request(`/claims/${decisionId}/${claimId}/evidence`),

  // Evidence
  listEvidence: (decisionId: string) => request(`/evidence/${decisionId}`),
  listEvidenceByOption: (decisionId: string, optionId: string) => request(`/evidence/${decisionId}/option/${optionId}`),
  listEvidenceBySource: (decisionId: string, sourceId: string) => request(`/evidence/${decisionId}/source/${sourceId}`),
  listEvidenceByClaim: (decisionId: string, claimId: string) => request(`/evidence/${decisionId}/${claimId}`),
  addEvidence: (
    decisionId: string,
    data: { option_id?: string; source_id?: string; claim_id?: string; source_name: string; source_url?: string; snippet: string; stance?: string }
  ) => request(`/evidence`, { method: "POST", body: JSON.stringify({ decision_id: decisionId, ...data }) }),

  // Comparison
  getComparison: (decisionId: string) => request(`/comparison/${decisionId}`),
  getComparisonMatrix: (decisionId: string) => request(`/comparison/${decisionId}/matrix`),

  // Result
  getResult: (decisionId: string) => request(`/result/${decisionId}`),

  // Feedback
  submitFeedback: (decisionId: string, data: { feedback_type: string; feedback: string }) =>
    request(`/feedback/${decisionId}`, { method: "POST", body: JSON.stringify(data) }),
};
