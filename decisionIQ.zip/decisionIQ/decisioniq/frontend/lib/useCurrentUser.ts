"use client";

import { useEffect, useState } from "react";
import { api } from "./api";

export type CurrentUser = {
  id: string;
  full_name: string;
  email: string;
  plan: string;
};

function initialsOf(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/**
 * Fetches /auth/me once and returns { name, initials } shaped for the
 * Navbar/Sidebar `user` prop, plus the full user object and loading/error
 * state for pages that need more. Replaces every hardcoded
 * `{ name: "You", initials: "Y" }` placeholder in the app.
 */
export function useCurrentUser() {
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api
      .me()
      .then((u) => {
        if (!cancelled) setUser(u);
      })
      .catch((e) => {
        if (!cancelled) setError(e.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const navUser = user ? { name: user.full_name.split(" ")[0], initials: initialsOf(user.full_name) } : null;

  return { user, navUser, loading, error };
}
