"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import { Bookmark, BookmarkX } from "lucide-react";

type Decision = { id: string; title: string; category: string; status: string };

export default function SavedPage() {
  const { navUser } = useCurrentUser();
  const [saved, setSaved] = useState<Decision[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listSaved()
      .then(setSaved)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  async function unsave(id: string) {
    await api.unsaveDecision(id);
    setSaved((prev) => prev.filter((d) => d.id !== id));
  }

  return (
    <div className="min-h-screen">
      <Navbar active="/saved" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/saved" />
        <main className="flex-1 px-6 py-8">
          <h1 className="text-2xl font-bold">Saved Decisions</h1>
          <p className="mt-1 text-white/60">Decisions you've bookmarked for later.</p>

          {loading && <p className="mt-6 text-white/50">Loading...</p>}
          {error && <p className="mt-6 text-red-400">{error}</p>}

          {!loading && saved.length === 0 && (
            <div className="card mt-6 p-8 text-center text-white/60">
              Nothing saved yet — open any decision and use the bookmark button to keep it here.
            </div>
          )}

          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {saved.map((d, i) => (
              <Reveal key={d.id} delay={i * 0.05}>
                <div className="card relative p-5">
                  <button
                    onClick={() => unsave(d.id)}
                    aria-label="Remove from saved"
                    className="absolute right-4 top-4 text-white/40 transition hover:text-red-400"
                  >
                    <BookmarkX size={16} />
                  </button>
                  <Link href={`/decisions/${d.id}`}>
                    <span className="flex items-center gap-1 text-xs text-brand-cyan">
                      <Bookmark size={12} /> {d.category}
                    </span>
                    <h3 className="mt-1 pr-6 font-semibold">{d.title}</h3>
                    <p className="mt-2 text-xs text-white/40">{d.status}</p>
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
