"use client";
import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import { Save } from "lucide-react";

export default function SettingsPage() {
  const { user, navUser, loading, error } = useCurrentUser();
  const [fullName, setFullName] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (user) setFullName(user.full_name);
  }, [user]);

  async function onSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      await api.updateMe({ full_name: fullName });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar active="/settings" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/settings" />
        <main className="flex-1 px-6 py-8">
          <h1 className="text-2xl font-bold">Settings</h1>

          {loading && <p className="mt-6 text-white/50">Loading your profile...</p>}
          {error && <p className="mt-6 text-red-400">{error}</p>}

          {user && (
            <Reveal>
              <form onSubmit={onSave} className="card mt-6 max-w-lg space-y-4 p-6">
                <div>
                  <label className="mb-1 block text-xs text-white/50">Full Name</label>
                  <input
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full rounded-lg border border-border bg-transparent px-3 py-2.5 text-sm focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-white/50">Email</label>
                  <input
                    disabled
                    value={user.email}
                    className="w-full cursor-not-allowed rounded-lg border border-border bg-panel2 px-3 py-2.5 text-sm text-white/50"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-white/50">Plan</label>
                  <span className="inline-block rounded-full bg-brand-gradient-soft px-3 py-1 text-xs font-semibold capitalize text-brand-cyan">
                    {user.plan}
                  </span>
                </div>
                <button disabled={saving} className="btn-primary transition hover:scale-105">
                  <Save size={16} /> {saving ? "Saving..." : "Save Changes"}
                </button>
                {saved && <p className="text-sm text-emerald-400">Saved.</p>}
              </form>
            </Reveal>
          )}
        </main>
      </div>
      <Footer />
    </div>
  );
}
