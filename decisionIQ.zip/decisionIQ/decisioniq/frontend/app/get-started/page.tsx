"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import RobotMascot from "@/components/RobotMascot";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import { categories } from "@/lib/categories";
import Sidebar from "@/components/Sidebar";
import { ArrowRight } from "lucide-react";

export default function GetStartedPage() {
  const { navUser } = useCurrentUser();
  const [question, setQuestion] = useState("");
  const [category, setCategory] = useState(categories[0].slug);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!question.trim()) {
      setError("Please describe the decision you want to make.");
      return;
    }
    setLoading(true);
    try {
      const decision = await api.createDecision({
        title: question.trim(),
        category,
        question: question.trim(),
      });
      router.push(`/decisions/${decision.id}`);
    } catch (err: any) {
      setError(err.message || "Could not start decision");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar active="/get-started" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/get-started" />
        <main className="flex-1 px-6 py-8">
          <div className="mx-auto max-w-2xl">
            <div className="mb-8 flex items-center gap-4">
              <div className="w-16"><RobotMascot /></div>
              <div>
                <h1 className="text-3xl font-bold">Get Started</h1>
                <p className="text-sm text-white/60">Tell us what you're deciding — we'll handle the research, comparison and insights.</p>
              </div>
            </div>

            {error && <p className="mb-4 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}

            <form onSubmit={onSubmit} className="card space-y-4 p-6">
              <div>
                <label className="mb-1 block text-xs text-white/50">Category (optional)</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full rounded-lg border border-border bg-panel px-3 py-2.5 text-sm focus:outline-none">
                  {categories.map((c) => (
                    <option key={c.slug} value={c.slug}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs text-white/50">What are you trying to decide?</label>
                <textarea
                  required
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  rows={5}
                  placeholder="Budget, priorities, deadline, anything that matters to you..."
                  className="w-full rounded-lg border border-border bg-transparent px-3 py-2.5 text-sm focus:outline-none"
                />
              </div>
              <button disabled={loading} className="btn-primary w-full justify-center transition hover:scale-105">
                {loading ? "Starting research…" : (<>Start My Decision <ArrowRight size={16} /></>)}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-white/50">
              Already have an account? <Link href="/login" className="text-brand-cyan">Log in</Link>
            </p>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}