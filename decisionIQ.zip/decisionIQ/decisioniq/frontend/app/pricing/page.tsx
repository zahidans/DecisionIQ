"use client";
import { useState } from "react";
import Image from "next/image";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { Check, X, ShieldCheck, Headphones, RefreshCcw, Star } from "lucide-react";

const plans = [
  {
    name: "Free",
    tag: "Get started with the basics",
    price: "₹0",
    cta: "Get Started",
    note: "A great way to explore DecisionIQ.",
    features: [
      ["5 searches per day", true],
      ["Access to basic sources", true],
      ["Standard AI insights", true],
      ["Save up to 5 decisions", true],
      ["Advanced analysis", false],
      ["Priority support", false],
    ],
  },
  {
    name: "Plus",
    tag: "For curious minds and students",
    price: "₹499",
    cta: "Get Plus",
    popular: true,
    note: "Perfect for students and lifelong learners.",
    features: [
      ["100 searches per day", true],
      ["Access to premium sources", true],
      ["Advanced AI analysis", true],
      ["Save unlimited decisions", true],
      ["Compare multiple options", true],
      ["Email support", true],
    ],
  },
  {
    name: "Pro",
    tag: "For professionals and researchers",
    price: "₹999",
    cta: "Get Pro",
    note: "Built for professionals who need deeper insights.",
    features: [
      ["500 searches per day", true],
      ["Access to all premium sources", true],
      ["Deep analysis & insights", true],
      ["Save unlimited decisions", true],
      ["Export reports (PDF/Excel)", true],
      ["Priority support", true],
      ["Early access to new features", true],
    ],
  },
  {
    name: "Enterprise",
    tag: "For teams and organizations",
    price: "Custom",
    cta: "Contact Sales",
    note: "Empower your team with better decisions, at scale.",
    features: [
      ["Unlimited searches", true],
      ["Custom data sources", true],
      ["Team collaboration", true],
      ["Advanced analytics & reporting", true],
      ["API access", true],
      ["Dedicated account manager", true],
      ["24/7 priority support", true],
    ],
  },
];

export default function PricingPage() {
  const [yearly, setYearly] = useState(false);
  const { navUser } = useCurrentUser();
  return (
    <div className="min-h-screen">
      <Navbar active="/pricing" user={navUser} />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-8 lg:grid-cols-[1.2fr,0.8fr] lg:items-center">
          <Reveal>
            <p className="text-xs font-semibold tracking-wide text-brand-cyan">PRICING PLANS</p>
            <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">
              Choose a Plan for a<br /><span className="gradient-text">Smarter Tomorrow.</span>
            </h1>
            <p className="mt-3 max-w-lg text-white/70">
              Flexible plans for learners, professionals, and decision-makers. Get the right insights, at the right time, for what matters to you.
            </p>
            <div className="mt-6 inline-flex items-center gap-3 rounded-full border border-border p-1">
              <button onClick={() => setYearly(false)} className={`rounded-full px-4 py-1.5 text-sm transition ${!yearly ? "bg-brand-gradient" : "text-white/60"}`}>Monthly</button>
              <button onClick={() => setYearly(true)} className={`rounded-full px-4 py-1.5 text-sm transition ${yearly ? "bg-brand-gradient" : "text-white/60"}`}>Yearly</button>
              <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs text-emerald-400">Save up to 40%</span>
            </div>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="overflow-hidden rounded-2xl border border-border animate-[floaty_6s_ease-in-out_infinite]">
              <Image src="/hero/pricing.png" alt="Knowledge pays the best interest — Benjamin Franklin" width={510} height={270} className="h-auto w-full object-cover" priority />
            </div>
          </Reveal>
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-4">
          {plans.map((p, i) => {
            const price = yearly && p.price.startsWith("₹") ? `₹${Math.round(parseInt(p.price.slice(1)) * 0.6)}` : p.price;
            return (
              <Reveal key={p.name} delay={i * 0.08} className={`card relative flex flex-col p-6 transition hover:-translate-y-1 ${p.popular ? "border-brand-purple ring-1 ring-brand-purple/50" : ""}`}>
                {p.popular && (
                  <span className="absolute -top-3 right-6 rounded-full bg-brand-gradient px-3 py-1 text-xs font-semibold">Most Popular</span>
                )}
                <h3 className="text-lg font-bold">{p.name}</h3>
                <p className="text-sm text-white/50">{p.tag}</p>
                <div className="mt-4 text-3xl font-extrabold">
                  {price}
                  {p.price !== "Custom" && <span className="text-sm font-medium text-white/50"> / month</span>}
                </div>
                <button className={p.popular ? "btn-primary mt-5 justify-center" : "btn-outline mt-5 justify-center"}>{p.cta} &rarr;</button>
                <ul className="mt-6 space-y-3 text-sm">
                  {p.features.map(([f, included]) => (
                    <li key={f as string} className={`flex items-center gap-2 ${included ? "text-white/80" : "text-white/30"}`}>
                      {included ? <Check size={14} className="text-emerald-400" /> : <X size={14} />}
                      {f}
                    </li>
                  ))}
                </ul>
                <p className="mt-6 rounded-lg bg-panel2 p-3 text-xs text-white/50">{p.note}</p>
              </Reveal>
            );
          })}
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          <div className="card p-5 lg:col-span-2">
            <h3 className="font-semibold">Frequently Asked Questions</h3>
            <ul className="mt-3 space-y-2 text-sm text-white/70">
              <li>Can I change my plan later?</li>
              <li>Is there a discount for yearly billing?</li>
              <li>Do you offer refunds?</li>
            </ul>
          </div>
          <div className="card flex flex-col justify-center gap-3 p-5 text-sm text-white/70">
            <span className="flex items-center gap-2"><ShieldCheck size={16} className="text-brand-cyan" /> Secure Payments</span>
            <span className="flex items-center gap-2"><Headphones size={16} className="text-brand-cyan" /> 24/7 Support</span>
            <span className="flex items-center gap-2"><RefreshCcw size={16} className="text-brand-cyan" /> Cancel Anytime</span>
            <span className="flex items-center gap-2"><Star size={16} className="text-brand-cyan" /> Trusted by 1M+ Users</span>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
