"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { api } from "@/lib/api";
import {
  Sparkles,
  Mic,
  ArrowRight,
  ShieldCheck,
  Search as SearchIcon,
  Sliders,
  Wand2,
} from "lucide-react";

const stats = [
  { value: "10+", label: "Decision Types" },
  { value: "1000+", label: "Trusted Sources" },
  { value: "95%", label: "User Satisfaction" },
  { value: "1M+", label: "Smarter Decisions" },
];

const steps = [
  { icon: SearchIcon, title: "Understand your problem", desc: "We analyze your needs" },
  { icon: Wand2, title: "Research real information", desc: "From trusted sources" },
  { icon: ShieldCheck, title: "Verify and find evidence", desc: "Filter what truly matters" },
  { icon: Sliders, title: "Compare your options", desc: "Side-by-side analysis" },
  { icon: Sparkles, title: "Generate insights", desc: "Personalized to you" },
  { icon: ArrowRight, title: "You decide", desc: "With clarity and confidence" },
];

const suggestions = [
  "Which laptop should I buy?",
  "Which job offer should I accept?",
  "Which course should I take?",
  "Which city is better to live in?",
];

const suggestionCategories: Record<string, string> = {
  "Which laptop should I buy?": "technology",
  "Which job offer should I accept?": "career",
  "Which course should I take?": "education",
  "Which city is better to live in?": "lifestyle",
};

// Approximate percentage positions of each category chip baked into
// /hero/home.png (630x640 source), so real navigation can sit invisibly
// on top of the reference illustration without altering it visually.
const categoryHotspots = [
  { label: "Education", href: "/use-cases/education", x: 27, y: 41, w: 26, h: 12 },
  { label: "Career", href: "/use-cases/career", x: 75, y: 31, w: 26, h: 12 },
  { label: "Products", href: "/use-cases/products", x: 19, y: 57, w: 26, h: 12 },
  { label: "Finance", href: "/use-cases/finance", x: 90, y: 48, w: 26, h: 12 },
  { label: "Travel", href: "/use-cases/travel", x: 24, y: 72, w: 26, h: 12 },
  { label: "Lifestyle", href: "/use-cases/lifestyle", x: 91, y: 65, w: 26, h: 12 },
  { label: "Business", href: "/use-cases/business", x: 38, y: 83, w: 26, h: 12 },
  { label: "Anything You Decide", href: "/decisions/new", x: 82, y: 80, w: 30, h: 12 },
];

export default function HomePage() {
  const [question, setQuestion] = useState("");
  const [category, setCategory] = useState("technology");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const normalized = question.trim();
    if (!normalized) {
      setError("Please describe the decision you want to make.");
      return;
    }
    setLoading(true);
    try {
      const decision = await api.createDecision({
        title: normalized,
        category,
        question: normalized,
      });
      router.push(`/decisions/${decision.id}`);
    } catch (err: any) {
      setError(err.message || "Could not create decision");
    } finally {
      setLoading(false);
    }
  }

  function useSuggestion(suggestion: string) {
    setQuestion(suggestion);
    setCategory(suggestionCategories[suggestion] || "technology");
  }

  return (
    <div className="min-h-screen">
      <Navbar active="/" />

      <section className="relative overflow-hidden border-b border-border/60">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(109,93,246,0.18),transparent_45%),radial-gradient(circle_at_80%_10%,rgba(56,189,248,0.15),transparent_40%)]" />
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-16 lg:grid-cols-2 lg:items-center">
          <Reveal>
            <p className="mb-4 text-sm font-medium text-brand-cyan">Your personal decision partner</p>
            <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl">
              Better Questions
              <br />
              <span className="text-shimmer">Brighter Decisions</span>
            </h1>
            <p className="mt-5 max-w-md text-white/70">
              DecisionIQ researches, verifies, compares and explains your options — for any decision in life.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/decisions/new" className="btn-primary transition hover:scale-105">
                Make a Decision <ArrowRight size={16} />
              </Link>
              <Link href="/how-it-works" className="btn-outline transition hover:scale-105">
                See How It Works
              </Link>
            </div>

            <form onSubmit={handleSubmit} className="mt-10 flex max-w-lg items-center gap-2 rounded-full border border-border bg-panel px-4 py-3 transition focus-within:border-brand-blue/60" noValidate>
              <Mic size={16} className="text-white/40" />
              <input
                required
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="flex-1 bg-transparent text-sm placeholder:text-white/40 focus:outline-none"
                placeholder="What are you trying to decide?"
              />
              <button
                type="submit"
                disabled={loading}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-gradient transition hover:scale-110 disabled:opacity-60"
                aria-label="Make a decision"
              >
                <ArrowRight size={16} />
              </button>
            </form>
            {error && <p className="mt-2 text-sm text-red-400">{error}</p>}

            <div className="mt-3 flex flex-wrap gap-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => useSuggestion(s)}
                  aria-label={`Use suggestion: ${s}`}
                  className="rounded-full border border-border px-3 py-1 text-xs text-white/60 transition hover:border-brand-blue/50 hover:text-white"
                >
                  {s}
                </button>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.15} className="relative flex flex-col items-center justify-center gap-8 lg:flex-row">
            <div className="relative flex h-80 w-80 items-center justify-center">
              <div className="absolute inset-0 rounded-full border border-brand-blue/30 animate-spin-slow" />
              <div className="absolute inset-6 rounded-full border border-dashed border-brand-purple/20 animate-[spinSlow_60s_linear_infinite_reverse]" />
              <div className="relative w-64 animate-[floaty_6s_ease-in-out_infinite] drop-shadow-[0_0_40px_rgba(62,139,255,0.35)]">
                <Image src="/hero/home.png" alt="DecisionIQ — Any Decision, A Smarter You" width={630} height={640} className="h-auto w-full" priority />
                {categoryHotspots.map((h) => (
                  <Link
                    key={h.label}
                    href={h.href}
                    aria-label={h.label}
                    title={h.label}
                    className="absolute -translate-x-1/2 -translate-y-1/2 rounded-lg transition hover:bg-white/10 hover:ring-2 hover:ring-brand-cyan/60"
                    style={{ left: `${h.x}%`, top: `${h.y}%`, width: `${h.w}%`, height: `${h.h}%` }}
                  />
                ))}
              </div>
            </div>

            <div className="card w-full max-w-xs p-5 transition hover:border-brand-blue/40">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-semibold">How DecisionIQ Works?</h3>
                <span className="flex items-center gap-1 text-xs text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-[pulseGlow_1.6s_ease-in-out_infinite]" /> Live
                </span>
              </div>
              <ol className="space-y-3">
                {steps.map((s) => (
                  <li key={s.title} className="flex items-start gap-3 text-sm">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-gradient-soft text-xs font-bold text-brand-cyan">
                      {steps.indexOf(s) + 1}
                    </span>
                    <div>
                      <p className="text-white/90">{s.title}</p>
                      <p className="text-xs text-white/40">{s.desc}</p>
                    </div>
                  </li>
                ))}
              </ol>
              <Link href="/decisions/new" className="btn-primary mt-5 w-full justify-center !py-2.5 text-sm transition hover:scale-105">
                Start Your Decision Journey
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      <Footer quote="“DecisionIQ helped me make a confident choice when I was completely confused.” — A Happy User" />
    </div>
  );
}
