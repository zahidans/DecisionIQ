"use client";
import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { User, Mail, Lock } from "lucide-react";
import Reveal from "@/components/Reveal";

export default function SignupPage() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agree, setAgree] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!agree) {
      setError("Please agree to the Terms of Service and Privacy Policy.");
      return;
    }
    setLoading(true);
    try {
      await api.register({ full_name: fullName, email, password });
      const res = await api.login({ email, password });
      localStorage.setItem("diq_token", res.access_token);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message || "Sign up failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex items-center justify-center p-8">
        <Reveal>
        <form onSubmit={onSubmit} className="card w-full max-w-sm p-8">
          <h2 className="text-2xl font-bold">Get Started</h2>
          <p className="mt-1 text-sm text-white/50">Create your account and begin your journey towards smarter decisions.</p>

          {error && <p className="mt-4 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}

          <label className="mt-6 block text-xs text-white/50">Full Name</label>
          <div className="mt-1 flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
            <User size={16} className="text-white/40" />
            <input required value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Enter your full name" className="w-full bg-transparent text-sm focus:outline-none" />
          </div>

          <label className="mt-4 block text-xs text-white/50">Email Address</label>
          <div className="mt-1 flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
            <Mail size={16} className="text-white/40" />
            <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email address" className="w-full bg-transparent text-sm focus:outline-none" />
          </div>

          <label className="mt-4 block text-xs text-white/50">Create Password</label>
          <div className="mt-1 flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
            <Lock size={16} className="text-white/40" />
            <input required type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters" className="w-full bg-transparent text-sm focus:outline-none" />
          </div>

          <label className="mt-4 flex items-center gap-2 text-xs text-white/60">
            <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            I agree to the Terms of Service and Privacy Policy
          </label>

          <button disabled={loading} type="submit" className="btn-primary mt-6 w-full justify-center">
            {loading ? "Creating account..." : "Create Account \u2192"}
          </button>

          <p className="mt-6 text-center text-sm text-white/50">
            Already have an account? <Link href="/login" className="text-brand-cyan">Log in</Link>
          </p>
        </form>
        </Reveal>
      </div>

      <Link href="/" className="relative hidden min-h-screen overflow-hidden lg:block">
        <Image
          src="/hero/signup-panel.png"
          alt="Let's Build A Smarter You — DecisionIQ"
          fill
          className="object-cover object-top"
          priority
        />
      </Link>
    </div>
  );
}
