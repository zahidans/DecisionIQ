import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import NavbarClient from "@/components/NavbarClient";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import StatBar from "@/components/StatBar";
import ActionCard from "@/components/ActionCard";
import TrustedSources from "@/components/TrustedSources";
import PopularQuestions from "@/components/PopularQuestions";
import Reveal from "@/components/Reveal";
import { categories, getCategory } from "@/lib/categories";
import { PlayCircle, ArrowRight, Quote } from "lucide-react";

export function generateStaticParams() {
  return categories.map((c) => ({ slug: c.slug }));
}

export default function UseCasePage({ params }: { params: { slug: string } }) {
  const category = getCategory(params.slug);
  if (!category) return notFound();

  
  return (
    <div className="min-h-screen">
      <NavbarClient active="/use-cases" />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/use-cases" />

        <main className="flex-1 px-6 py-8">
          <p className="mb-4 text-sm text-white/50">{category.eyebrow}</p>

          <div className="grid gap-10 lg:grid-cols-[1.1fr,0.9fr] lg:items-center">
            <Reveal>
              <p className="mb-2 text-xs font-semibold tracking-wide text-brand-cyan">USE CASES</p>
              <h1 className="text-3xl font-extrabold leading-tight sm:text-4xl">
                {category.title}
                <br />
                <span className="gradient-text">{category.titleAccent}</span>
              </h1>
              <p className="mt-4 max-w-lg text-white/70">{category.description}</p>
              <div className="mt-6 flex flex-wrap gap-4">
                <Link href="/decisions/new" className="btn-primary transition hover:scale-105">
                  Explore {category.name} Insights <ArrowRight size={16} />
                </Link>
                <button className="btn-outline transition hover:scale-105">
                  <PlayCircle size={18} /> Watch Video
                </button>
              </div>
              <StatBar stats={category.stats} />
            </Reveal>

            <Reveal delay={0.15} className="relative">
              <div className="overflow-hidden rounded-2xl border border-border shadow-[0_0_60px_rgba(62,139,255,0.15)] animate-[floaty_6s_ease-in-out_infinite]">
                <Image
                  src={category.image}
                  alt={`${category.name} — DecisionIQ`}
                  width={906}
                  height={392}
                  className="h-auto w-full object-cover"
                  priority
                />
              </div>
            </Reveal>
          </div>

          <section className="mt-14">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-xl font-bold">What You Can Do</h2>
              <Link href="/explore" className="text-sm text-brand-cyan">
                Explore All {category.name} Tools &rarr;
              </Link>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {category.actions.map((a, i) => (
                <Reveal key={a.title} delay={i * 0.06}>
                  <ActionCard title={a.title} description={a.description} />
                </Reveal>
              ))}
            </div>
          </section>

          <section className="mt-10 grid gap-6 lg:grid-cols-3">
            <Reveal><PopularQuestions questions={category.popularQuestions} /></Reveal>
            <Reveal delay={0.1}><TrustedSources sources={category.trustedSources} /></Reveal>
            <Reveal delay={0.2}>
              <div className="card p-5">
                <h3 className="mb-4 font-semibold">Real Impact</h3>
                <Quote className="mb-2 text-brand-purple" size={20} />
                <p className="text-sm text-white/70">{category.testimonial.quote}</p>
                <p className="mt-3 text-sm text-white/50">— {category.testimonial.author}</p>
              </div>
            </Reveal>
          </section>

          <Reveal>
            <section className="mt-10 flex flex-wrap items-center justify-between gap-6 rounded-2xl border border-border bg-brand-gradient-soft p-6">
              <div>
                <h3 className="text-lg font-bold">
                  Explore {category.name} <span className="gradient-text">with Confidence.</span>
                </h3>
                <p className="text-sm text-white/60">Make smarter {category.name.toLowerCase()} decisions with trusted insights and real-world data.</p>
              </div>
              <Link href="/signup" className="btn-primary transition hover:scale-105">
                Get Started Free <ArrowRight size={16} />
              </Link>
            </section>
          </Reveal>
        </main>
      </div>
      <Footer />
    </div>
  );
}
