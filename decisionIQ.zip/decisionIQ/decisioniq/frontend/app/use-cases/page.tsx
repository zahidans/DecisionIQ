"use client";
import Link from "next/link";
import { useCurrentUser } from "@/lib/useCurrentUser";
import Image from "next/image";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { categories } from "@/lib/categories";
import * as Icons from "lucide-react";

const iconFor: Record<string, keyof typeof Icons> = {
  education: "GraduationCap",
  career: "Briefcase",
  technology: "Cpu",
  finance: "LineChart",
  lifestyle: "Heart",
  travel: "Plane",
  business: "BarChart3",
};

export default function UseCasesHub() {
  const { navUser } = useCurrentUser();
  return (
    <div className="min-h-screen">
      <Navbar active="/use-cases" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/use-cases" />
        <main className="flex-1 px-6 py-8">
          <div className="grid gap-10 lg:grid-cols-[1.1fr,0.9fr] lg:items-center">
            <Reveal>
              <p className="text-xs font-semibold tracking-wide text-brand-cyan">USE CASES</p>
              <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">
                Real Questions. Real Life.
                <br />
                <span className="gradient-text">Smarter Decisions.</span>
              </h1>
              <p className="mt-4 max-w-xl text-white/70">
                Explore how DecisionIQ helps people make confident decisions in different areas of life — with real
                research, real evidence, and real clarity.
              </p>

              <div className="mt-8 flex flex-wrap gap-2">
                <span className="rounded-full bg-brand-gradient px-4 py-1.5 text-sm font-semibold">All</span>
                {categories.map((c) => (
                  <Link key={c.slug} href={`/use-cases/${c.slug}`} className="rounded-full border border-border px-4 py-1.5 text-sm text-white/70 transition hover:border-brand-blue/50 hover:text-white">
                    {c.name}
                  </Link>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.15}>
              <div className="overflow-hidden rounded-2xl border border-border shadow-[0_0_60px_rgba(62,139,255,0.15)] animate-[floaty_6s_ease-in-out_infinite]">
                <Image src="/hero/use-cases-hub.png" alt="DecisionIQ use cases" width={906} height={392} className="h-auto w-full object-cover" priority />
              </div>
            </Reveal>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {categories.map((c, i) => {
              const Icon = (Icons[iconFor[c.slug]] as any) || Icons.Sparkles;
              return (
                <Reveal key={c.slug} delay={i * 0.05}>
                  <Link href={`/use-cases/${c.slug}`} className="card group block p-6 transition hover:border-brand-blue/50 hover:-translate-y-1">
                    <Icon className="mb-4 text-brand-cyan" size={22} />
                    <p className="text-xs text-white/40">{c.name}</p>
                    <h3 className="mt-1 text-lg font-semibold">{c.title.replace(/,$/, "")}</h3>
                    <p className="mt-2 text-sm text-white/60">{c.description.slice(0, 90)}...</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-sm text-brand-cyan transition group-hover:gap-2">
                      Explore <Icons.ArrowRight size={14} />
                    </span>
                  </Link>
                </Reveal>
              );
            })}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
