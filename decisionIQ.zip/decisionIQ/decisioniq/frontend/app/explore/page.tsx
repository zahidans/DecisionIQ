"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { Search, GraduationCap, Briefcase, ShoppingCart, LineChart, Plane, Heart, Building2, Cpu, Flame, Sparkles } from "lucide-react";

const cats = [
  { icon: GraduationCap, label: "Education", desc: "Colleges, Courses, Scholarships" },
  { icon: Briefcase, label: "Career", desc: "Jobs, Growth, Opportunities" },
  { icon: ShoppingCart, label: "Products", desc: "Electronics, Gear, Daily Essentials" },
  { icon: LineChart, label: "Finance", desc: "Investments, Savings, Planning" },
  { icon: Plane, label: "Travel", desc: "Trips, Itineraries, Destinations" },
  { icon: Heart, label: "Lifestyle", desc: "Health, Home, Daily Living" },
  { icon: Building2, label: "Business", desc: "Startups, Ideas, Market Insights" },
  { icon: Cpu, label: "Technology", desc: "Tools, Software, Innovation" },
];

const featured = [
  { tag: "Education", badge: "Trending", title: "Top 10 Universities for MS in Germany (2025)", desc: "Compare fees, curriculum, job opportunities and more.", views: "1.2M views", saved: "12k saved" },
  { tag: "Products", badge: "Popular", title: "Best Laptops for Students Under ₹70,000", desc: "Compare performance, battery, build quality and real user reviews.", views: "980k views", saved: "9k saved" },
  { tag: "Career", badge: "Popular", title: "How to Choose Between Two Job Offers?", desc: "Compare salary, growth, work culture, location and long-term opportunities.", views: "750k views", saved: "7k saved" },
  { tag: "Travel", badge: "Trending", title: "Best International Destinations for Students", desc: "Compare cost, safety, weather, opportunities and more.", views: "640k views", saved: "5k saved" },
];

const trending = [
  "Best AI Tools for Students",
  "Highest Paying Jobs in 2025",
  "Study in Germany vs USA",
  "Best Smartphones Under ₹30K",
  "Remote Jobs for Freshers",
];

export default function ExplorePage() {
  const { navUser } = useCurrentUser();
  const [query, setQuery] = useState("");
  const [decisions, setDecisions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listDecisions().then((dec: any) => setDecisions(dec || [])).catch(() => setDecisions([])).finally(() => setLoading(false));
  }, []);

  const results = query.trim()
    ? decisions.filter(
        (d: any) =>
          (d.title || "").toLowerCase().includes(query.toLowerCase()) ||
          (d.question || "").toLowerCase().includes(query.toLowerCase()) ||
          (d.category || "").toLowerCase().includes(query.toLowerCase())
      )
    : decisions;

  return (
    <div className="min-h-screen">
      <Navbar active="/explore" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/explore" />
        <main className="flex-1 px-6 py-8">
          <div className="grid gap-8 lg:grid-cols-[1fr,300px]">
            <div>
              <p className="text-xs font-semibold tracking-wide text-brand-cyan">EXPLORE POSSIBILITIES</p>
              <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">
                Discover <span className="gradient-text">Smarter Decisions</span>
              </h1>
              <p className="mt-3 text-white/70">Explore real-world decisions, insights, and guidance across every area of life.</p>

              <form onSubmit={(e) => e.preventDefault()} className="mt-6 flex items-center gap-2 rounded-full border border-border bg-panel px-4 py-3">
                <Search size={16} className="text-white/40" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="flex-1 bg-transparent text-sm placeholder:text-white/40 focus:outline-none"
                  placeholder="Search decisions, categories, or questions..."
                />
                <button type="submit" className="btn-primary !py-2 !px-5 text-sm">Search</button>
              </form>
              <div className="mt-3 flex flex-wrap gap-2">
                {["Best laptops 2025", "Top universities for MS", "Remote job opportunities", "Best online courses", "Travel destinations"].map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setQuery(p)}
                    className="rounded-full border border-border px-3 py-1 text-xs text-white/60 transition hover:border-brand-blue/50 hover:text-white"
                  >
                    {p}
                  </button>
                ))}
              </div>

              <div className="mt-10 flex items-center justify-between">
                <h2 className="text-lg font-bold">{query ? "Search Results" : "Explore by Category"}</h2>
                <span className="text-sm text-brand-cyan">{query ? `${results.length} found` : "View All &rarr;"}</span>
              </div>

              {query ? (
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  {results.length === 0 ? (
                    <p className="col-span-2 text-white/50">No decisions match your search.</p>
                  ) : (
                    results.map((d: any) => (
                      <Link key={d.id} href={`/decisions/${d.id}`} className="card block p-5 transition hover:-translate-y-1 hover:border-brand-blue/40">
                        <span className="text-xs text-brand-cyan">{d.category}</span>
                        <h3 className="mt-1 font-semibold">{d.title}</h3>
                        <p className="mt-1 text-sm text-white/60 line-clamp-2">{d.question || d.title}</p>
                      </Link>
                    ))
                  )}
                </div>
              ) : (
                <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {cats.map((c) => (
                    <div key={c.label} className="card p-4 text-center">
                      <c.icon className="mx-auto mb-2 text-brand-cyan" size={20} />
                      <p className="text-sm font-medium">{c.label}</p>
                      <p className="text-[11px] text-white/40">{c.desc}</p>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-10 flex items-center justify-between">
                <h2 className="text-lg font-bold">Featured Decisions</h2>
                <span className="text-sm text-brand-cyan">See Trending &rarr;</span>
              </div>
              <div className="mt-4 grid gap-5 sm:grid-cols-2">
                {featured.map((f) => (
                  <div key={f.title} className="card overflow-hidden">
                    <div className="flex h-32 items-center justify-center bg-brand-gradient-soft">
                      <Sparkles size={28} className="text-brand-purple/50" />
                    </div>
                    <div className="p-4">
                      <div className="mb-2 flex gap-2 text-[10px]">
                        <span className="rounded bg-brand-blue/20 px-2 py-0.5 text-brand-blue">{f.tag}</span>
                        <span className="rounded bg-pink-500/20 px-2 py-0.5 text-pink-400">{f.badge}</span>
                      </div>
                      <h3 className="font-semibold">{f.title}</h3>
                      <p className="mt-1 text-sm text-white/60">{f.desc}</p>
                      <div className="mt-3 flex gap-4 text-xs text-white/40">
                        <span>{f.views}</span>
                        <span>{f.saved}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <aside className="space-y-6">
              <Reveal>
                <div className="card overflow-hidden text-center transition hover:border-brand-blue/40">
                  <div className="w-full animate-[floaty_6s_ease-in-out_infinite]">
                    <Image src="/hero/explore-card.png" alt="Need Help Exploring?" width={246} height={330} className="h-auto w-full object-cover" />
                  </div>
                  <div className="p-5 pt-0">
                    <button className="btn-primary mt-2 w-full justify-center !py-2 text-sm transition hover:scale-105">Ask DecisionIQ &rarr;</button>
                  </div>
                </div>
              </Reveal>
              <Reveal delay={0.1}>
                <div className="card p-5">
                  <h3 className="mb-3 flex items-center gap-2 font-semibold"><Flame size={16} className="text-orange-400" /> Trending Topics</h3>
                  <ol className="space-y-2 text-sm text-white/70">
                    {trending.map((t, i) => (
                      <li key={t} className="flex gap-2"><span className="text-white/30">{i + 1}</span>{t}</li>
                    ))}
                  </ol>
                </div>
              </Reveal>
            </aside>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
