"use client";
import Image from "next/image";
import { useCurrentUser } from "@/lib/useCurrentUser";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { Search, ScanSearch, BarChart3, Lightbulb, CheckCircle2 } from "lucide-react";

const steps = [
  {
    icon: Search,
    title: "Tell Us Your Question",
    desc: "Type your question or choose a category — from education and careers to travel, finance, lifestyle and more.",
    note: "Your curiosity is the start of a smarter decision.",
  },
  {
    icon: ScanSearch,
    title: "We Research for You",
    desc: "Our AI scans trusted sources, real data, and expert insights relevant to your question.",
    note: "Millions of sources. One clear answer for you.",
  },
  {
    icon: BarChart3,
    title: "Analyze & Compare",
    desc: "We organize the information, compare your options, and highlight key pros, cons, and insights.",
    note: "Facts, not confusion.",
  },
  {
    icon: Lightbulb,
    title: "Get Clear Insights",
    desc: "Receive easy-to-understand summaries, key takeaways, and personalized recommendations.",
    note: "Complex information. Simple insights.",
  },
  {
    icon: CheckCircle2,
    title: "Make a Confident Decision",
    desc: "Take action with clarity and confidence — and save or share your results for future reference.",
    note: "Better decisions. A brighter you.",
  },
];

const stats = [
  { value: "10+", label: "Use Case Categories" },
  { value: "1000+", label: "Trusted Sources" },
  { value: "95%", label: "User Satisfaction" },
  { value: "1M+", label: "Smarter Decisions" },
];

export default function HowItWorksPage() {
  const { navUser } = useCurrentUser();
  return (
    <div className="min-h-screen">
      <Navbar active="/how-it-works" user={navUser} />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-8 lg:grid-cols-[1.1fr,0.9fr] lg:items-center">
          <Reveal>
            <p className="text-xs font-semibold tracking-wide text-brand-cyan">HOW IT WORKS</p>
            <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">
              From Question to Clarity
              <br /><span className="gradient-text">in Just a Few Steps.</span>
            </h1>
            <p className="mt-3 max-w-lg text-white/70">
              DecisionIQ simplifies complex choices using AI, trusted sources, and structured analysis — so you can make confident decisions, faster.
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="overflow-hidden rounded-2xl border border-border animate-[floaty_6s_ease-in-out_infinite]">
              <Image src="/hero/how-it-works.png" alt="You Ask. We Research. You Decide." width={400} height={320} className="h-auto w-full object-cover" priority />
            </div>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-5">
          {steps.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.08}>
              <div className="card h-full p-5 transition hover:-translate-y-1 hover:border-brand-blue/40">
                <span className="mb-3 flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient text-sm font-bold">{i + 1}</span>
                <h3 className="font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-white/60">{s.desc}</p>
                <div className="mt-4 flex items-center gap-2 text-xs text-white/40">
                  <s.icon size={14} /> {s.note}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="mt-12 flex flex-wrap items-center justify-between gap-8 rounded-2xl border border-border bg-brand-gradient-soft p-8">
            <div>
              <p className="text-sm text-white/50">A simpler process. A brighter tomorrow.</p>
              <h2 className="mt-1 text-2xl font-extrabold">
                Smarter Steps. <span className="gradient-text">Brighter Futures.</span>
              </h2>
            </div>
            <div className="flex flex-wrap gap-8">
              {stats.map((s) => (
                <div key={s.label}>
                  <div className="text-xl font-bold">{s.value}</div>
                  <div className="text-xs text-white/50">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </main>
      <Footer />
    </div>
  );
}
