"use client";
import Image from "next/image";
import { useCurrentUser } from "@/lib/useCurrentUser";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { PlayCircle, Target, Eye, Gem, GraduationCap, Briefcase, Users, BarChart3, Plane } from "lucide-react";

const stats = [
  { value: "10+", label: "Use Case Categories" },
  { value: "1000+", label: "Trusted Sources" },
  { value: "1M+", label: "Smarter Decisions" },
  { value: "95%", label: "User Satisfaction" },
];

const journey = [
  { year: "2024", title: "The Idea", desc: "Identified the need for a smarter, more unbiased way to make decisions." },
  { year: "2025", title: "Built & Launched", desc: "Developed DecisionIQ with powerful AI and trusted data sources." },
  { year: "2026+", title: "Growing Together", desc: "Expanding to more use cases and helping millions make better decisions." },
];

const audiences = [
  { icon: GraduationCap, label: "Students" },
  { icon: Briefcase, label: "Professionals" },
  { icon: Users, label: "Families" },
  { icon: BarChart3, label: "Researchers" },
  { icon: Plane, label: "Dreamers" },
];

export default function AboutPage() {
  const { navUser } = useCurrentUser();
  return (
    <div className="min-h-screen">
      <Navbar active="/about" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/about" />
        <main className="flex-1 px-6 py-8">
          <div className="grid gap-8 lg:grid-cols-[1.1fr,0.9fr] lg:items-center">
            <Reveal>
              <p className="text-xs font-semibold tracking-wide text-brand-cyan">ABOUT DECISIONIQ</p>
              <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">
                A Smarter Tomorrow
                <br /><span className="gradient-text">Through Better Decisions.</span>
              </h1>
              <p className="mt-3 max-w-xl text-white/70">
                DecisionIQ is an AI-powered decision intelligence platform designed to help you research, compare, and choose with confidence — in every important area of life.
              </p>
              <div className="mt-6 flex flex-wrap gap-4">
                <button className="btn-primary transition hover:scale-105">Our Mission &rarr;</button>
                <button className="btn-outline transition hover:scale-105"><PlayCircle size={18} /> Watch Our Story</button>
              </div>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="overflow-hidden rounded-2xl border border-border animate-[floaty_6s_ease-in-out_infinite]">
                <Image src="/hero/about.png" alt="Better Decisions. A Brighter You." width={570} height={360} className="h-auto w-full object-cover" priority />
              </div>
            </Reveal>
          </div>

          <Reveal>
            <div className="mt-8 flex flex-wrap gap-10 rounded-2xl border border-border p-5">
              {stats.map((s) => (
                <div key={s.label}>
                  <div className="text-xl font-bold">{s.value}</div>
                  <div className="text-xs text-white/50">{s.label}</div>
                </div>
              ))}
            </div>
          </Reveal>

          <section className="mt-12 grid gap-6 lg:grid-cols-2">
            <div>
              <p className="text-xs font-semibold tracking-wide text-brand-cyan">OUR PURPOSE</p>
              <h2 className="mt-2 text-2xl font-bold">Why We Exist</h2>
              <p className="mt-3 text-white/70">
                In a world full of information, people often feel overwhelmed, confused, and uncertain. DecisionIQ exists to turn that confusion into clarity — by combining the power of AI, trusted sources, and unbiased analysis.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="card p-5">
                <Target className="mb-2 text-brand-cyan" size={20} />
                <h3 className="font-semibold">Our Mission</h3>
                <p className="mt-1 text-sm text-white/60">To empower every individual with clear, reliable, and personalized insights for smarter life decisions.</p>
              </div>
              <div className="card p-5">
                <Eye className="mb-2 text-brand-cyan" size={20} />
                <h3 className="font-semibold">Our Vision</h3>
                <p className="mt-1 text-sm text-white/60">A world where everyone makes confident decisions and creates a better tomorrow for themselves.</p>
              </div>
              <div className="card p-5 sm:col-span-2">
                <Gem className="mb-2 text-brand-cyan" size={20} />
                <h3 className="font-semibold">Our Values</h3>
                <ul className="mt-1 grid grid-cols-2 gap-1 text-sm text-white/60">
                  <li>User-First Approach</li>
                  <li>Transparency & Trust</li>
                  <li>Continuous Innovation</li>
                  <li>Real-World Impact</li>
                  <li>Accessibility for All</li>
                </ul>
              </div>
            </div>
          </section>

          <section className="mt-12">
            <h2 className="text-2xl font-bold">Our Journey</h2>
            <div className="mt-6 space-y-6 border-l border-border pl-6">
              {journey.map((j) => (
                <div key={j.year} className="relative">
                  <span className="absolute -left-[29px] h-3 w-3 rounded-full bg-brand-gradient" />
                  <p className="text-sm font-bold text-brand-cyan">{j.year}</p>
                  <h3 className="font-semibold">{j.title}</h3>
                  <p className="text-sm text-white/60">{j.desc}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="mt-12">
            <h2 className="text-xl font-bold">Built for Everyone</h2>
            <p className="mt-1 text-sm text-white/60">Students, professionals, families, and dreamers — DecisionIQ is for anyone who wants to make a better choice.</p>
            <div className="mt-5 flex flex-wrap gap-8">
              {audiences.map((a) => (
                <div key={a.label} className="flex flex-col items-center gap-2 text-sm text-white/70">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-gradient-soft text-brand-cyan">
                    <a.icon size={20} />
                  </span>
                  {a.label}
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
      <Footer />
    </div>
  );
}
