"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { api } from "@/lib/api";
import { useCurrentUser } from "@/lib/useCurrentUser";

type DecisionHist = {
  id: string;
  title: string;
  category: string;
  question: string | null;
  created_at: string;
  status: string;
  result_summary: string | null;
  is_saved: boolean;
};

export default function HistoryPage() {
  const { navUser } = useCurrentUser();
  const [decisions, setDecisions] = useState<DecisionHist[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listDecisions().then((dec: any) => {
      const out = dec.map((d: any) => ({
        id: d.id,
        title: d.title,
        category: d.category,
        question: d.question || null,
        created_at: d.created_at || new Date().toISOString(),
        status: d.status || "unknown",
        result_summary: d.result_summary || null,
        is_saved: d.is_saved || false,
      }));
      setDecisions(out);
    }).catch(() => setDecisions([])).finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar active="/history" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/history" />
        <main className="flex-1 px-6 py-8">
          <div className="mx-auto max-w-3xl">
            <h1 className="text-2xl font-bold mb-6">Decision History</h1>

            {loading ? (
              <p className="text-white/50">Loading decisions...</p>
            ) : decisions.length === 0 ? (
              <p className="text-white/50 mt-10">No decisions yet. Start one from the <a href="/decisions/new" className="text-brand-cyan">New Decision</a> page.</p>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {decisions.map((d) => (
                  <Reveal key={d.id} delay={0.05}>
                    <div className="card p-5 hover:border-brand-blue/40 transition">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{d.title}</h3>
                          <p className="text-xs text-white/60">{d.category}</p>
                          {d.question && (
                            <p className="mt-1 text-sm text-white/70 truncate max-w-xs">{d.question}</p>
                          )}
                        </div>
                        <div className="text-sm">
                          <span className={`inline-flex items-center gap-1 rounded-full ${d.status === "ready" ? "bg-emerald-400/20 text-emerald-400" : d.status === "failed" ? "bg-red-400/20 text-red-400" : "bg-brand-blue/20 text-brand-cyan"}`}>
                            {d.status}
                          </span>
                          {d.result_summary && (
                            <p className="mt-1 text-xs text-white/60 line-clamp-2">{d.result_summary}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </Reveal>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}