"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import {
  CheckCircle2,
  XCircle,
  ShieldCheck,
  AlertTriangle,
  Minus,
  ExternalLink,
  Trophy,
  Loader2,
  Bookmark,
  BookmarkCheck,
  RefreshCcw,
} from "lucide-react";

type Evidence = {
  id: string;
  option_id?: string | null;
  source_name: string;
  source_url?: string | null;
  snippet: string;
  stance: "supports" | "against" | "neutral";
};

type ScoreCriterion = { criterion: string; weight: number; score: number; note?: string };

type Option = {
  id: string;
  name: string;
  score?: string | null;
  score_value?: number | null;
  score_breakdown?: ScoreCriterion[] | null;
  pros?: string | null;
  cons?: string | null;
  evidence: Evidence[];
};

type Decision = {
  id: string;
  title: string;
  category: string;
  question: string;
  priorities?: Record<string, number> | null;
  status: string;
  progress_message?: string | null;
  error_message?: string | null;
  result_summary?: string | null;
  options: Option[];
  evidence: Evidence[];
  is_saved: boolean;
};

const IN_PROGRESS = new Set(["created", "researching", "comparing"]);

const stanceStyle: Record<Evidence["stance"], { icon: any; color: string; label: string }> = {
  supports: { icon: ShieldCheck, color: "text-emerald-400 border-emerald-400/30 bg-emerald-400/10", label: "Supports" },
  against: { icon: AlertTriangle, color: "text-red-400 border-red-400/30 bg-red-400/10", label: "Against" },
  neutral: { icon: Minus, color: "text-white/50 border-border bg-panel2", label: "Neutral" },
};

function EvidenceChip({ e }: { e: Evidence }) {
  const s = stanceStyle[e.stance] || stanceStyle.neutral;
  const Icon = s.icon;
  const content = (
    <div className={`flex items-start gap-2 rounded-lg border px-3 py-2 text-xs ${s.color}`}>
      <Icon size={14} className="mt-0.5 shrink-0" />
      <div>
        <p className="font-semibold">
          {e.source_name} <span className="font-normal opacity-70">— {s.label}</span>
        </p>
        <p className="mt-0.5 text-white/70">{e.snippet}</p>
      </div>
      {e.source_url && <ExternalLink size={12} className="ml-auto mt-0.5 shrink-0 opacity-60" />}
    </div>
  );
  return e.source_url ? (
    <a href={e.source_url} target="_blank" rel="noopener noreferrer" className="block transition hover:opacity-80">
      {content}
    </a>
  ) : (
    content
  );
}

function bullets(text?: string | null) {
  return (text || "").split("\n").map((l) => l.trim()).filter(Boolean);
}

export default function DecisionDetailPage({ params }: { params: { id: string } }) {
  const { navUser } = useCurrentUser();
  const [decision, setDecision] = useState<Decision | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savePending, setSavePending] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(() => {
    api
      .getDecision(params.id)
      .then((d) => {
        setDecision(d);
        setError(null);
      })
      .catch((e) => setError(e.message));
  }, [params.id]);

  useEffect(() => {
    load();
  }, [load]);

  // Poll every 3s while the research pipeline is still running, so the page
  // never looks frozen. Stops automatically once the decision resolves.
  useEffect(() => {
    if (decision && IN_PROGRESS.has(decision.status)) {
      pollRef.current = setInterval(load, 3000);
    }
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [decision?.status, load]);

  async function toggleSave() {
    if (!decision) return;
    setSavePending(true);
    try {
      if (decision.is_saved) {
        await api.unsaveDecision(decision.id);
      } else {
        await api.saveDecision(decision.id);
      }
      setDecision({ ...decision, is_saved: !decision.is_saved });
    } finally {
      setSavePending(false);
    }
  }

  async function retry() {
    setRetrying(true);
    try {
      const d = await api.retryDecision(params.id);
      setDecision(d);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setRetrying(false);
    }
  }

  if (error) {
    return (
      <div className="min-h-screen">
        <Navbar active="/decisions" user={navUser} />
        <div className="mx-auto flex max-w-7xl">
          <Sidebar active="/decisions" />
          <main className="flex-1 px-6 py-8">
            <p className="text-red-400">{error}</p>
          </main>
        </div>
        <Footer />
      </div>
    );
  }

  if (!decision) {
    return (
      <div className="min-h-screen">
        <Navbar active="/decisions" user={navUser} />
        <div className="mx-auto flex max-w-7xl">
          <Sidebar active="/decisions" />
          <main className="flex-1 px-6 py-8">
            <p className="text-white/50">Loading decision...</p>
          </main>
        </div>
        <Footer />
      </div>
    );
  }

  const inProgress = IN_PROGRESS.has(decision.status);
  const failed = decision.status === "failed";

  return (
    <div className="min-h-screen">
      <Navbar active="/decisions" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/decisions" />
        <main className="flex-1 px-6 py-8">
          <Reveal>
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs text-brand-cyan">{decision.category}</span>
                <h1 className="mt-1 text-2xl font-bold">{decision.title}</h1>
                <p className="mt-2 text-white/60">{decision.question}</p>
              </div>
              <button
                onClick={toggleSave}
                disabled={savePending}
                aria-label={decision.is_saved ? "Remove from saved" : "Save decision"}
                className="shrink-0 rounded-full border border-border p-2.5 text-white/60 transition hover:border-brand-blue/50 hover:text-brand-cyan"
              >
                {decision.is_saved ? <BookmarkCheck size={18} className="text-brand-cyan" /> : <Bookmark size={18} />}
              </button>
            </div>

            {decision.priorities && Object.keys(decision.priorities).length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {Object.keys(decision.priorities).map((p) => (
                  <span key={p} className="rounded-full border border-border px-3 py-1 text-xs text-white/60">{p}</span>
                ))}
              </div>
            )}

            <span className="mt-3 inline-flex items-center gap-2 rounded-full border border-border px-3 py-1 text-xs text-white/60">
              {inProgress ? (
                <Loader2 size={12} className="animate-spin text-brand-cyan" />
              ) : (
                <span className={`h-1.5 w-1.5 rounded-full ${failed ? "bg-red-400" : "bg-emerald-400"}`} />
              )}
              {inProgress ? decision.progress_message || "Working on it..." : decision.status}
            </span>
          </Reveal>

          {failed && (
            <Reveal delay={0.05}>
              <div className="card mt-6 flex items-center justify-between gap-4 border-red-400/30 bg-red-400/5 p-6">
                <div className="flex items-start gap-3">
                  <XCircle className="mt-0.5 shrink-0 text-red-400" size={20} />
                  <div>
                    <p className="font-semibold text-red-400">This decision couldn't be completed</p>
                    <p className="mt-1 text-sm text-white/60">{decision.error_message || "Something went wrong."}</p>
                  </div>
                </div>
                <button onClick={retry} disabled={retrying} className="btn-outline shrink-0 text-sm transition hover:scale-105">
                  <RefreshCcw size={14} className={retrying ? "animate-spin" : ""} /> {retrying ? "Retrying..." : "Retry"}
                </button>
              </div>
            </Reveal>
          )}

          {inProgress && (
            <Reveal delay={0.1}>
              <div className="card mt-6 p-6 text-center text-white/60">
                <Loader2 className="mx-auto mb-3 animate-spin text-brand-cyan" size={24} />
                {decision.progress_message || "Researching..."} — this page refreshes automatically.
              </div>
            </Reveal>
          )}

          {decision.result_summary && (
            <Reveal delay={0.05}>
              <div className="card mt-6 p-6">
                <h2 className="mb-2 font-semibold">Recommendation</h2>
                <p className="whitespace-pre-line text-sm leading-relaxed text-white/70">{decision.result_summary}</p>
              </div>
            </Reveal>
          )}

          {decision.options.length > 0 && (
            <section className="mt-8">
              <h2 className="mb-4 text-lg font-bold">Comparing Options</h2>
              <div className="grid gap-5 lg:grid-cols-2">
                {decision.options.map((o, i) => (
                  <Reveal key={o.id} delay={i * 0.08}>
                    <div className="card p-5">
                      <div className="mb-3 flex items-center justify-between">
                        <h3 className="font-semibold">{o.name}</h3>
                        {o.score && (
                          <span className="flex items-center gap-1 rounded-full bg-brand-gradient-soft px-3 py-1 text-xs font-bold text-brand-cyan">
                            <Trophy size={12} /> {o.score}
                          </span>
                        )}
                      </div>

                      {(bullets(o.pros).length > 0 || bullets(o.cons).length > 0) && (
                        <div className="grid gap-4 sm:grid-cols-2">
                          <div>
                            <p className="mb-1 text-xs font-semibold text-emerald-400">Pros</p>
                            <ul className="space-y-1 text-sm text-white/70">
                              {bullets(o.pros).map((p) => (
                                <li key={p} className="flex items-start gap-1.5">
                                  <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-emerald-400" /> {p}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="mb-1 text-xs font-semibold text-red-400">Cons</p>
                            <ul className="space-y-1 text-sm text-white/70">
                              {bullets(o.cons).map((c) => (
                                <li key={c} className="flex items-start gap-1.5">
                                  <XCircle size={14} className="mt-0.5 shrink-0 text-red-400" /> {c}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      )}

                      {o.score_breakdown && o.score_breakdown.length > 0 && (
                        <div className="mt-4 space-y-2 border-t border-border pt-4">
                          <p className="text-xs font-semibold text-white/50">Why this score</p>
                          {o.score_breakdown.map((c) => (
                            <div key={c.criterion}>
                              <div className="mb-1 flex justify-between text-xs">
                                <span className="capitalize text-white/70">
                                  {c.criterion} <span className="text-white/40">({Math.round(c.weight * 100)}% weight)</span>
                                </span>
                                <span className="text-white/50">{c.score}/10</span>
                              </div>
                              <div className="h-1.5 rounded-full bg-panel2">
                                <div className="h-1.5 rounded-full bg-brand-gradient" style={{ width: `${c.score * 10}%` }} />
                              </div>
                              {c.note && <p className="mt-0.5 text-[11px] text-white/40">{c.note}</p>}
                            </div>
                          ))}
                        </div>
                      )}

                      {o.evidence.length > 0 && (
                        <div className="mt-4 space-y-2 border-t border-border pt-4">
                          <p className="text-xs font-semibold text-white/50">Evidence for this option</p>
                          {o.evidence.map((e) => (
                            <EvidenceChip key={e.id} e={e} />
                          ))}
                        </div>
                      )}
                    </div>
                  </Reveal>
                ))}
              </div>
            </section>
          )}

          {decision.evidence.length > 0 && (
            <section className="mt-8">
              <h2 className="mb-4 text-lg font-bold">Overall Evidence</h2>
              <div className="space-y-3">
                {decision.evidence.map((e, i) => (
                  <Reveal key={e.id} delay={i * 0.05}>
                    <EvidenceChip e={e} />
                  </Reveal>
                ))}
              </div>
            </section>
          )}
        </main>
      </div>
      <Footer />
    </div>
  );
}
