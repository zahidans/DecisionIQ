"use client";
import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import RobotMascot from "@/components/RobotMascot";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import { categories } from "@/lib/categories";
import ResearchTimeline from "@/components/ResearchTimeline";

export default function NewDecisionPage() {
  const { navUser } = useCurrentUser();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(categories[0].slug);
  const [question, setQuestion] = useState("");
  const [priorityInput, setPriorityInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const criteria = priorityInput
        .split(",")
        .map((c) => c.trim())
        .filter(Boolean);
      const priorities = criteria.length > 0 ? Object.fromEntries(criteria.map((c) => [c, 1])) : undefined;

      const decision = await api.createDecision({ title, category, question, priorities });
      router.push(`/decisions/${decision.id}`);
    } catch (err: any) {
      setError(err.message || "Could not create decision");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar active="/decisions/new" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/decisions/new" />
        <main className="flex-1 px-6 py-8">
          <div className="mx-auto max-w-xl">
            <div className="mb-6 flex items-center gap-4">
              <div className="w-16"><RobotMascot /></div>
              <div>
                <h1 className="text-2xl font-bold">What are you trying to decide?</h1>
                <p className="text-sm text-white/60">Tell us your question — we'll handle the research, comparison and insights.</p>
              </div>
            </div>

            {error && <p className="mb-4 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}

            <form onSubmit={onSubmit} className="card space-y-4 p-6">
              <div>
                <label className="mb-1 block text-xs text-white/50">Give it a short title</label>
                <input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Which laptop should I buy?" className="w-full rounded-lg border border-border bg-transparent px-3 py-2.5 text-sm focus:outline-none" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-white/50">Category</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full rounded-lg border border-border bg-panel px-3 py-2.5 text-sm focus:outline-none">
                  {categories.map((c) => (
                    <option key={c.slug} value={c.slug}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs text-white/50">Describe your situation and constraints</label>
                <textarea required value={question} onChange={(e) => setQuestion(e.target.value)} rows={5} placeholder="Budget, priorities, deadline, anything that matters to you..." className="w-full rounded-lg border border-border bg-transparent px-3 py-2.5 text-sm focus:outline-none" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-white/50">What matters most to you? (optional, comma separated)</label>
                <input
                  value={priorityInput}
                  onChange={(e) => setPriorityInput(e.target.value)}
                  placeholder="e.g. price, performance, battery life"
                  className="w-full rounded-lg border border-border bg-transparent px-3 py-2.5 text-sm focus:outline-none"
                />
                <p className="mt-1 text-xs text-white/40">
                  These become the weighted criteria the scoring stage rates each option against.
                </p>
              </div>
              <button disabled={loading} className="btn-primary w-full justify-center transition hover:scale-105">
                {loading ? "Starting research..." : "Start My Decision \u2192"}
              </button>
            </form>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
