"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";

type Decision = { id: string; title: string; category: string; status: string };

const statusIcon: Record<string, any> = {
  ready: CheckCircle2,
  failed: XCircle,
  researching: Loader2,
  comparing: Loader2,
  created: Loader2,
};

const statusColor: Record<string, string> = {
  ready: "text-emerald-400",
  failed: "text-red-400",
  researching: "text-brand-cyan",
  comparing: "text-brand-cyan",
  created: "text-white/40",
};

export default function DecisionsPage() {
  const { navUser } = useCurrentUser();
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listDecisions().then(setDecisions).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar active="/decisions" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/decisions" />
        <main className="flex-1 px-6 py-8">
          <h1 className="text-2xl font-bold">My Decisions</h1>

          {loading && <p className="mt-6 text-white/50">Loading...</p>}

          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {decisions.map((d, i) => {
              const Icon = statusIcon[d.status] || Loader2;
              return (
                <Reveal key={d.id} delay={i * 0.05}>
                  <Link href={`/decisions/${d.id}`} className="card block p-5 transition hover:-translate-y-1 hover:border-brand-blue/40">
                    <span className="text-xs text-brand-cyan">{d.category}</span>
                    <h3 className="mt-1 font-semibold">{d.title}</h3>
                    <p className={`mt-2 flex items-center gap-1.5 text-xs ${statusColor[d.status] || "text-white/40"}`}>
                      <Icon size={12} className={d.status === "researching" || d.status === "comparing" ? "animate-spin" : ""} />
                      {d.status}
                    </p>
                  </Link>
                </Reveal>
              );
            })}
            {!loading && decisions.length === 0 && (
              <p className="text-white/50">No decisions yet — start one from the sidebar.</p>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
