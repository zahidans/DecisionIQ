"use client";
import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { Mail, Lock } from "lucide-react";
import Reveal from "@/components/Reveal";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.login({ email, password });
      localStorage.setItem("diq_token", res.access_token);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <Link href="/" className="relative hidden min-h-screen overflow-hidden lg:block">
        <Image
          src="/hero/login-panel.png"
          alt="Welcome Back to DecisionIQ — Better questions. Brighter decisions."
          fill
          className="object-cover object-left"
          priority
        />
      </Link>

      <div className="flex items-center justify-center p-8">
        <Reveal>
        <form onSubmit={onSubmit} className="card w-full max-w-sm p-8">
          <h2 className="text-2xl font-bold">Login to DecisionIQ</h2>
          <p className="mt-1 text-sm text-white/50">Continue your journey towards better decisions.</p>

          {error && <p className="mt-4 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}

          <label className="mt-6 block text-xs text-white/50">Email</label>
          <div className="mt-1 flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
            <Mail size={16} className="text-white/40" />
            <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email" className="w-full bg-transparent text-sm focus:outline-none" />
          </div>

          <label className="mt-4 block text-xs text-white/50">Password</label>
          <div className="mt-1 flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
            <Lock size={16} className="text-white/40" />
            <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" className="w-full bg-transparent text-sm focus:outline-none" />
          </div>

          <button disabled={loading} type="submit" className="btn-primary mt-6 w-full justify-center">
            {loading ? "Logging in..." : "Login \u2192"}
          </button>

          <p className="mt-6 text-center text-sm text-white/50">
            Don't have an account? <Link href="/signup" className="text-brand-cyan">Create one</Link>
          </p>
        </form>
        </Reveal>
      </div>
    </div>
  );
}
