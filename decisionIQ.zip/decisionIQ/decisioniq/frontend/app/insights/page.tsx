"use client";
import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import Reveal from "@/components/Reveal";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { api } from "@/lib/api";
import { BarChart3, CheckCircle2, Loader2, XCircle, Trophy } from "lucide-react";

type Insights = {
  total_decisions: number;
  ready_decisions: number;
  researching_decisions: number;
  failed_decisions: number;
  decisions_by_category: Record<string, number>;
  average_top_score: number | null;
  most_common_category: string | null;
  recent_titles: string[];
};

export default function InsightsPage() {
  const { navUser } = useCurrentUser();
  const [data, setData] = useState<Insights | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getInsights().then(setData).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, []);

  const topCategory = data
    ? Object.entries(data.decisions_by_category).sort((a, b) => b[1] - a[1])
    : [];
  const maxCount = topCategory.length > 0 ? topCategory[0][1] : 1;

  return (
    <div className="min-h-screen">
      <Navbar active="/insights" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/insights" />
        <main className="flex-1 px-6 py-8">
          <h1 className="text-2xl font-bold">Insights</h1>
          <p className="mt-1 text-white/60">Patterns from your own decision history — nothing here is a placeholder statistic.</p>

          {loading && <p className="mt-6 text-white/50">Loading insights…</p>}
          {error && <p className="mt-6 text-red-400">{error}</p>}

          {data && data.total_decisions === 0 && (
            <div className="card mt-6 p-8 text-center text-white/60">
              Make a few decisions first — insights will appear here once you have some history.
            </div>
          )}

          {data && data.total_decisions > 0 && (
            <>
              <Reveal>
                <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="card p-5">
                    <BarChart3 className="mb-2 text-brand-cyan" size={20} />
                    <p className="text-2xl font-bold">{data.total_decisions}</p>
                    <p className="text-xs text-white/50">Total Decisions</p>
                  </div>
                  <div className="card p-5">
                    <CheckCircle2 className="mb-2 text-emerald-400" size={20} />
                    <p className="text-2xl font-bold">{data.ready_decisions}</p>
                    <p className="text-xs text-white/50">Completed</p>
                  </div>
                  <div className="card p-5">
                    <Loader2 className="mb-2 text-brand-blue" size={20} />
                    <p className="text-2xl font-bold">{data.researching_decisions}</p>
                    <p className="text-xs text-white/50">In Progress</p>
                  </div>
                  <div className="card p-5">
                    <XCircle className="mb-2 text-red-400" size={20} />
                    <p className="text-2xl font-bold">{data.failed_decisions}</p>
                    <p className="text-xs text-white/50">Failed</p>
                  </div>
                </div>
              </Reveal>

              <div className="mt-6 grid gap-6 lg:grid-cols-2">
                <Reveal delay={0.1}>
                  <div className="card p-5">
                    <h3 className="mb-4 font-semibold">Decisions by Category</h3>
                    <div className="space-y-3">
                      {topCategory.map(([cat, count]) => (
                        <div key={cat}>
                          <div className="mb-1 flex justify-between text-sm">
                            <span className="capitalize text-white/70">{cat}</span>
                            <span className="text-white/50">{count}</span>
                          </div>
                          <div className="h-2 rounded-full bg-panel2">
                            <div
                              className="h-2 rounded-full bg-brand-gradient"
                              style={{ width: `${(count / maxCount) * 100}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </Reveal>

                <Reveal delay={0.15}>
                  <div className="card p-5">
                    <h3 className="mb-4 font-semibold">At a Glance</h3>
                    <ul className="space-y-3 text-sm text-white/70">
                      <li className="flex items-center gap-2">
                        <Trophy size={16} className="text-brand-cyan" />
                        Most common category: <span className="font-semibold capitalize text-white">{data.most_common_category || "—"}</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Trophy size={16} className="text-brand-cyan" />
                        Average top score across decisions: <span className="font-semibold text-white">{data.average_top_score ?? "—"}</span>
                      </li>
                    </ul>
                    <h4 className="mb-2 mt-5 text-xs font-semibold text-white/50">Recent Decisions</h4>
                    <ul className="space-y-1 text-sm text-white/70">
                      {data.recent_titles.map((t) => (
                        <li key={t}>{t}</li>
                      ))}
                    </ul>
                  </div>
                </Reveal>
              </div>
            </>
          )}
        </main>
      </div>
      <Footer />
    </div>
  );
}
