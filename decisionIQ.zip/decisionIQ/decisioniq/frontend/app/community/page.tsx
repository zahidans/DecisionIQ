"use client";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Sidebar from "@/components/Sidebar";
import { useCurrentUser } from "@/lib/useCurrentUser";
import { Users } from "lucide-react";

export default function CommunityPage() {
  const { navUser } = useCurrentUser();
  return (
    <div className="min-h-screen">
      <Navbar active="/community" user={navUser} />
      <div className="mx-auto flex max-w-7xl">
        <Sidebar active="/community" />
        <main className="flex-1 px-6 py-8">
          <h1 className="text-2xl font-bold">Community</h1>
          <div className="card mt-6 p-8 text-center text-white/60">
            <Users className="mx-auto mb-3 text-brand-cyan" size={28} />
            <p>
              Community (public decisions, comments, profiles) is intentionally not built yet — the core
              decision engine (research, evidence, scoring, recommendations) comes first. This page will
              come to life once that's solid.
            </p>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
