import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DecisionIQ — Research less. Decide better.",
  description:
    "DecisionIQ is an AI-powered decision intelligence platform that helps you research, compare, and choose with confidence.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
