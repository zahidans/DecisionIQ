import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: "#080B14",
        panel: "#0E1424",
        panel2: "#111A2E",
        border: "#22304a",
        brand: {
          blue: "#3E8BFF",
          purple: "#8B5CF6",
          pink: "#D946EF",
          cyan: "#22D3EE",
        },
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(90deg, #6D5DF6 0%, #A855F7 50%, #38BDF8 100%)",
        "brand-gradient-soft": "linear-gradient(135deg, rgba(109,93,246,0.18), rgba(56,189,248,0.10))",
      },
      fontFamily: {
        sans: ["Sora", "Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};
export default config;
